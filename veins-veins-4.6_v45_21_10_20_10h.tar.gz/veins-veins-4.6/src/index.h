/**
 * @mainpage %Veins Framework
 *
 * See the %Veins website <a href="http://veins.car2x.org/"> for a tutorial, documentation, and publications </a>.
 *
 * @verbinclude README.txt
 */


