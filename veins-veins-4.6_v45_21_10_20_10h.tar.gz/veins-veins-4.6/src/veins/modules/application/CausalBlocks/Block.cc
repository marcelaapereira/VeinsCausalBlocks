//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/Block.h>
#include<iostream>
#include <string.h>

using namespace std;

#include <time.h>

Block::Block() {
    // TODO Auto-generated constructor stub
  id=0;
  idBlockCount=0;
  idBlockProcessoOrigem = 0;;
  isValid = true;
  isComplete = false;
  contRetransmission = 0;
  //timeDelivery = NULL;


}

Block::Block(int pBlockCount){
    // TODO Auto-generated constructor stub
  id = 0;
  idBlockCount = pBlockCount;
}

MsgByProcess* Block:: addMsg(int pID, char* ptext,char* pStatus,
     int pBlockCount, int pIdproc, bool pIsPrintMSG)
{
  MsgByProcess *msg= NULL;
  if (pIdproc>-1)
  {
    msg = new MsgByProcess();
    msg->id= pID;
    msg->text= ptext;
    msg->status= pStatus;
    msg->idBC= pBlockCount;
    msg->idProcess=pIdproc;
    msg->idRemetente = pIdproc;
    ListMsgByProcess.push_back(msg);

    msg = dynamic_cast<MsgByProcess*>(ListMsgByProcess[ListMsgByProcess.size()-1]);
    countMSGByProcess++;
    if (pIsPrintMSG==true)
    {
       cout<<"\n\n Listagem das Mensagens do bloco";
       printMsgs();

    }
  }
  else
    cout<<"Erro ao criar uma mensagem do Processo! Referência Inválida do Processo";

  return msg;

}

MsgByProcess* Block:: markMsg(int pID, char* ptext,char* pStatus,
     int pBlockCount, int pIdproc, bool pIsPrintMSG)
{
    MsgByProcess *msg= NULL;
    if (pIdproc>-1)
    { msg = getMsg(pIdproc);
      if (msg==NULL)
      { msg = addMsg(pID, ptext,pStatus,pBlockCount, pIdproc, pIsPrintMSG);}
      else
      {
        msg->id= pID;
        msg->text= ptext;
        msg->status= pStatus;
        msg->idBC= pBlockCount;
        cout<<"\n =>mark MSG ("<<msg->text<<") idRemetente="<<msg->idProcess<<
                "\n -idBCRemetente= "<<msg->idBC<<
                "\n BCLocal="<<pBlockCount<<
                "\n MsgRecebidasBloco(Total)="<<ListMsgByProcess.size();

        if (pIsPrintMSG==true)
        {
            cout<<"\n\n Listagem das Mensagens do bloco";
            printMsgs();

        }
      }
    }
    return msg;

}

void  Block:: setIsDelivery(bool pValue)
{
    isDelivery= pValue;
    isValid = not isDelivery;

}

bool Block:: getIsComplete()
{
    return  isComplete;
}

bool Block:: getIsDelivery()
{
    return  isDelivery;
}

MsgByProcess* Block:: getMsg(int pIdProc)
{
  MsgByProcess* msgLocate = NULL;
  unsigned int index = 0;
  bool find=false;

  while ((!find) && (this->ListMsgByProcess.size()> index))
  {
    //c = dynamic_cast<Channel*>(&channels[index]);
    msgLocate = dynamic_cast<MsgByProcess*>(ListMsgByProcess[index]);
    if (msgLocate->idProcess==pIdProc)
      find=true;
    else msgLocate=NULL;
            ++index;
  }
    return msgLocate;


}


MsgByProcess* Block:: getMsg(int pID, int pIdProc)
{
  MsgByProcess* msgLocate = NULL;
  unsigned int index = 0;
  bool find=false;

  while ((!find) && (this->ListMsgByProcess.size()> index))
  {
    //c = dynamic_cast<Channel*>(&channels[index]);
    msgLocate = dynamic_cast<MsgByProcess*>(ListMsgByProcess[index]);
    if (msgLocate->idProcess==pIdProc)
      find=true;
    else msgLocate=NULL;
            ++index;
  }
    return msgLocate;


}

void Block:: printMsgs()
{
    MsgByProcess* msg = NULL;
    unsigned int index = 0;

    while (this->ListMsgByProcess.size()> index)
    {
           //c = dynamic_cast<Channel*>(&channels[index]);
      msg = dynamic_cast<MsgByProcess*>(ListMsgByProcess[index]);
      cout<<"\n Msg = ("<< msg->id <<") BC= "<<msg->idBC
          << " Processo="<<msg->idProcess
          <<"identificador do bloco="<<id<< " status="<<msg->status
          <<"\n  - Texto"<<msg->text;

      if (isDelivery ==true)
        cout <<"TimeDelivery="<<timeDelivery;
      index++;
    }
}


MsgByProcess* Block:: findMsgReceived(int pIdProcess)
{
    MsgByProcess* Msglocated=
    getMsg(pIdProcess);
    if(Msglocated!=NULL &&  strcmp(Msglocated->status,"+")==0)
    {
       return Msglocated;

    }else
    {
       Msglocated = NULL;
      return Msglocated;

    }

}


Block::~Block() {
    // TODO Auto-generated destructor stub
}

