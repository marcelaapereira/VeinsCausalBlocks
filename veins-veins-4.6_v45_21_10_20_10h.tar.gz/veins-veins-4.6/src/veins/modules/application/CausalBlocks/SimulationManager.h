//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_SIMULATIONMANAGER_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_SIMULATIONMANAGER_H_
#include "veins/modules/application/CausalBlocks/Message/MessageBlock_m.h"
#include <vector>


using namespace std;

class SimulationManager {
public:
    int countMsgWithfailure;
    int countMSGsTotalToSend;
    int totalMsgToDisseminate;
    int countMsgToDisseminate;
    int countMsgToDisseminateWithfailure;
    int countpercentageMsgWithfailure;
    int countCar;
    int countMsgAlreadySent;
    int countMSGsByProcesso;
    int countScheduledMSGByProcess;
    char *textMsgToSend;
    double periodMSGSend;
    double intervalSendMSGByProcess;
    double periodWaitingReplay;
    double intervalBeacon = 0;
    bool isComplete;
    vector<MessageBlock*> listMsgBlock;
    vector<MessageBlock*> listMsgWithfailure;
    vector<int> listNumRandomOffailure;
    SimulationManager();
    virtual ~SimulationManager();
    void  LoadListMsgToSendOfApp(int pKind);
    MessageBlock*  nextMsgToSend();
    bool  existsMsgInlistMsgWithfailure(int pIndexMSg);
    void  loadListRandomOfFailure();
    void printListRandomOfFailure();
    bool existsMsgInlistNumRandomOffailure(int pValue);
};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_SIMULATIONMANAGER_H_ */
