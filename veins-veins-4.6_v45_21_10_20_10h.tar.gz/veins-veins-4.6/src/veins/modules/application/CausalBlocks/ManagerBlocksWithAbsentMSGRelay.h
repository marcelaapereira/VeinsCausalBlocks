//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_WITHABSENTMSGRELAY_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_WITHABSENTMSGRELAY_H_
#include <veins/modules/application/CausalBlocks/ManagerBlocks.h>
#include <veins/modules/application/CausalBlocks/Block.h>
#include <veins/modules/application/CausalBlocks/MBV.h>
#include <veins/modules/application/CausalBlocks/MLDV.h>
#include <veins/modules/application/CausalBlocks/ListaLDViByProcess.h>
#include <veins/modules/application/CausalBlocks/Process.h>

class ManagerBlocksWithAbsentMSGRelay: public ManagerBlocks{
public:
    bool relayMsg;
    int countMsgAbsents;
    int countMsgRecovered;

    vector<int> LDVi;
    vector<MBV*> MBVi;
    vector<int> LDViRecoveredMessages;
    bool isChangeMinMBVi = false;

    bool activateTimeSilenceByBlock = false;
    bool activateTimesilencePeriodicOfApllication = false;
    float timesilencePeriodicOfApllication =0;

    enum kindVector {
          vectorLVD = 1,
          vectorLVDReceivedMessages
        };



    ManagerBlocksWithAbsentMSGRelay(int pIdProcessLocal, int pProcessCount);
    virtual ~ManagerBlocksWithAbsentMSGRelay();

    MsgByProcess* MarkBlockPerMsgPerProcess(
       int pIdMsgRemetente,char* pText, int pIdBCRemetente, int pIdProcess,
       Block* pBloco, time_t timeReceive, double timeReceiveSimulator,
       bool pIsUpdateMAxBCInEventReceive,
       bool pDeliveryBlockComplete, bool pPrintBlockDelivery);
    Block* getPreviousBlock(Block *pBlock);
    int getPosVectorOfBlock(Block *pBlock);
    Block* getPreviousBlock(
      Block *pBlock, int pNumBlockCount, int pProcess);
    bool existsMsgOfProcessInBlock(Block *pBlock, int pIDProcess);
    void processaRelay(MsgByProcess *pMsg, Block *pBlock);
    bool checkBlockComplete(Block* pBlock, bool pIsDelivery,double pTimeDeliverySimluador,
       bool updateMaxBlocoInDelivery);
    void checkAllBlocksCompletes(bool pIsDelivey,double pTimeDeliverySimluador,
       bool updateMaxBlocoInDelivery);
    bool isSequentialBlock(Block* pBlock, Block* pBlockPrevious);
    void createLDVi();
    vector<int> createLDVi(bool pInitializeProcess);
    void createMBVi();
    void updateLDV(int pIdProcesso, int pValue);
    void updateLDViRecoveredMessages(int pIdProcesso, int pValue);
    void updateMBVi(int pIdProcesso, int pValue);
    vector<MLDV*>filterLDVIiInMLDV(vector<MLDV*> pMLDVi, int pIdProcesso);
    MLDV* addLDVInMLDV(int pLdvi, int pIdProcesso, int pIdBlockCount, bool pInsetNewItem);
    int getCurrentLDVi();
    int getMinValueMBV();
    MLDV* createMLDVi(Process *pProcess,bool pInsertInList);
    MLDV* getCurrentMLDVi(int pIdProcesso);
    int getMaxBlockCountByProcess(int pIdProcess);
    vector<int> createNewVector(int pTam, int pValue);
    int getValueLDVByPositionInMLDVi(int pPos,int pIdProcessSender);
    int getValueLDVInMLDVi(MLDV *pCurrentMLDV,int pIdProcess);
    void printMLDVi(Process *pProcess);
    Process * getProcess(int pIdProcess);
    MLDV* addLDVInMLDV(vector <int> pLdvi, int pIdProcesso,
      int pIdBlockCount, bool pInsetNewItem, bool pUpdateMLDVOldWithSameBlockCount);
    MLDV* findMLDVByBlock(int pBlockCount, int pProcessSender);
    MLDV* getMLDViByBlockCount(int pIdProcesso, int pBlockCount);
    void createLDViRecoveredMessages();




};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_WITHABSENTMSGRELAY_H_ */
