//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_BLOCK_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_BLOCK_H_
#include <veins/modules/application/CausalBlocks/MsgByProcess.h>
#include <vector>
using namespace std;
#include <time.h>

class Block {

public:
    int id;
    char* msg;
    int idBlockProcessoOrigem;
    bool isValid;
    bool isComplete;
    bool isSendMsg;
    bool isSendMsgNull;
    bool isDelivery;
    int  idBlockCount; //Também chamado BC
    int  countMSGByProcess;
    //  ThreadTimeSilence timeSilence;
    //ListBlocks listBlocks;
    int contRetransmission;
    time_t timeDelivery;
    double timeDeliverySimulator;

    vector<MsgByProcess*> ListMsgByProcess;


    Block();
    Block(int pBlockCount);
    MsgByProcess* addMsg(int pID, char* ptext,char* pStatus, int pBlockCount,
        int pIdProc, bool pIsPrintMSG);
    MsgByProcess* getMsg(int pID, int pIdProc);
    void  setIsDelivery(bool pValue);
    bool getIsComplete();
    bool getIsDelivery();
    MsgByProcess* findMsgReceived(int pIdProc);
    MsgByProcess* getMsg(int pIdProc);
    MsgByProcess* markMsg(int pID, char* ptext,char* pStatus,
         int pBlockCount, int pIdproc, bool pIsPrintMSG);
    void printMsgs();
    virtual ~Block();
};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_BLOCK_H_ */
