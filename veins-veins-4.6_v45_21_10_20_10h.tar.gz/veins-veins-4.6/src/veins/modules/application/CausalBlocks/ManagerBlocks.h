//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_MANAGERBLOCKS_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_MANAGERBLOCKS_H_
#include <veins/modules/application/CausalBlocks/Block.h>
#include <veins/modules/application/CausalBlocks/Process.h>
#include <veins/modules/application/CausalBlocks/LRV.h>
#include<vector>
#include <time.h>

using namespace std;

class ManagerBlocks {
    private:


public:
    enum KindsMessages {
         SHEDULE_SEND_MSG_BLOCK = 2,
         SEND_MSG_BLOCK,
         RECEIVE_MSG_BLOCK,
         SEND_MSG_BLOCK_REQUEST,
         SEND_MSG_BLOCK_REPLY,
         TIME_SILENCE,
         SEND_NULL
       };

    int blockCount;
    int processCount;
    int idProcessLocal;
    vector<Block*> listBlocks;
    vector<Process*> listProcess;
    vector<MsgByProcess*> listMsgAbsent;
    Block *currentPointerBlock;
    Block currentBlock;
    LRV *LRV_;

    ManagerBlocks();
    virtual ~ManagerBlocks();

    ManagerBlocks(int pIdProcessLocal, int pProcessCount);
    void setBlockCount(int pValor);
    void incrementaBlockCount();
    int getMaxBlockCount(int pValue1, int pValue2);
    int getBlockCount();
    void printBlocks();
    int getNewIdMSG();
    int maxValueInLRV;
    int minValueInLRV;
    Block* addBlock();
    Block* addBlock(int pID, int pBlockCount);
    Block* getBlock(int pBlockCount);
    Process* addProcess(int pID, char* pName);
    Process* getProcess(int pID);
    MsgByProcess* addMsg(int pIdMsg, int pBlockCount, int pIdProc,
            char* pNameProc,char* pMsgText, char* pStatus);
    void setEventSendBlockCount();
    virtual bool checkBlockComplete(Block* pBlock, bool pIsDelivery, bool updateMaxBlocoInDelivery,
            double pTimeDeliverySimulator);

    time_t getCurrentTime();
    void orderBlocks();
    void insertProcessInlist(int pCountProcess);
    MsgByProcess* findOrAddNewMSG(int pIdMsgRemetente,char* pText,char* pStatus, int pIdBCRemetente, int pIdProcess, Block* pBloco);
    bool MarkBlockPerMsgPerProcess(int pIdMsgRemetente,char* pText, int pIdBCRemetente, int pIdProcess,
            Block* pBloco, time_t timeReceive,double ptimeReceiveSimulator,
            bool pIsUpdateMAxBCInEventReceive, bool pDeliveryBlockComplete,
            bool pPrintBlockDelivery, MsgByProcess *pMsgMarked);

    void ManagerCheckblockComplete(Block *pCausalBlock, MsgByProcess *pMsgBlock,
      bool pIsDelivery , bool  pPrintMSG, double pTimeDeliverySimulator);
    void  updateMaxBC(int pReceiveValue, int pCurrentvalue);
    Process* findOrAddNewProcess(int pIdProcess, char* pNameProcess);
    Block* findOrAddNewBlock( int pIdBC);
    void deliveryCompleteBlocks(double pTimeDeliverySimulator,bool updateMaxBloco);
    void deliveryBlock(Block* pBlock, double pTimeDeliverySimulator, bool updateMaxBloco,
      bool pDeliveryBlockNotComplete);
    void deliveryBlock(int pBlockCount, double pTimeDeliverySimulator, bool updateMaxBloco,
            bool pDeliveryBlockNotComplete);
    Block* addMsgNullsInBlock(Block * pCurrentBlock, int pBlockCount);
    bool findMSGByBlockCount(int pIdMsgRemetente,int pIdProcess, Block* pBloco);



    vector<Block*>filterBlocksByProcess(int pIdProcess);

};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_MANAGERBLOCKS_H_ */
