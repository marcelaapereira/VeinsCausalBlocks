//

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/ManagerBlocks.h>
#include <vector>
#include<iostream>
#include <time.h>
#include </home/marcela/Simulacao/omnetpp-5.1.1/include/omnetpp/simtime.h>


using namespace std;

ManagerBlocks:: ManagerBlocks() {
    // TODO Auto-generated constructor stub
  blockCount = 0;
}

ManagerBlocks:: ManagerBlocks(int pIdProcessLocal, int pProcessCount)
{
    this->processCount= pProcessCount;
    this->blockCount=0;
    this->idProcessLocal=pIdProcessLocal;
    this->LRV_ = new LRV();

}

Process* ManagerBlocks:: addProcess(int pID, char* pName)
{
  Process *proc = NULL;
  proc = new Process(pID, pName, this->processCount);
  listProcess.push_back(proc);
  proc = dynamic_cast<Process*>(listProcess[listProcess.size()-1]);
  return proc;
}

Process* ManagerBlocks:: getProcess(int pID)
{
  Process* procLocate = NULL;
  unsigned int index = 0;
  bool find=false;

  while ((!find) && (this->listProcess.size()> index))
  {
    //c = dynamic_cast<Channel*>(&channels[index]);
      procLocate = dynamic_cast<Process*>(listProcess[index]);
    if (procLocate->id == pID)
      find=true;
    else procLocate=NULL;
    ++index;
  }
  return procLocate;
}

int ManagerBlocks:: getNewIdMSG()
{
    int static MSGCount=0;
    MSGCount++;
    cout<<"\n======>>>Mensagem gerada num="<<MSGCount;
    return  MSGCount;
}

Block* ManagerBlocks:: addBlock()
{
   Block * blocoatual=NULL;
   currentPointerBlock = new Block();
   currentPointerBlock->id= -1;
   listBlocks.push_back(currentPointerBlock);
   blocoatual = dynamic_cast<Block*>(listBlocks[listBlocks.size()-1]);
   return blocoatual;
}

Block* ManagerBlocks:: addBlock(int pID, int pBlockCount)
{
  Block * blocoatual=NULL;
  currentPointerBlock = new Block();
  currentPointerBlock->id= pID;
  currentPointerBlock->idBlockCount= pBlockCount;
  listBlocks.push_back(currentPointerBlock);
  blocoatual = dynamic_cast<Block*>(listBlocks[listBlocks.size()-1]);
  orderBlocks();
  addMsgNullsInBlock(currentPointerBlock,  pBlockCount);
  return blocoatual;
}

Block* ManagerBlocks:: addMsgNullsInBlock(Block * pCurrentBlock, int pBlockCount)
{
    for (int i=0; i<processCount; i++)
    {  // addMsg(int pID, char* ptext,char* pStatus, int pBlockCount,
         //   int pIdProc, bool pIsPrintMSG);

        if (pCurrentBlock->getMsg(i) ==NULL)
        {
           pCurrentBlock->addMsg(-1, "","",pBlockCount, i, false);
        }
    }


}

void ManagerBlocks::orderBlocks()
{   Block* blocoAtual=NULL;
    Block* blocoAPesquisar = NULL;
    Block* aux = NULL;
    for (int i = 0; i < listBlocks.size(); i++)
    {
      for (int j = 0; j < listBlocks.size(); j++)
      {
          blocoAtual = dynamic_cast<Block*>(listBlocks[i]);
          blocoAPesquisar =dynamic_cast<Block*>(listBlocks[j]);
         if (blocoAtual->idBlockCount < blocoAPesquisar->idBlockCount)
         {
        //aqui acontece a troca, do maior cara  vaia para a direita e o menor para a esquerda
             aux = listBlocks[i];
             listBlocks[i] = listBlocks[j];
             listBlocks[j] = aux;
         }
     }
 }

}

MsgByProcess* ManagerBlocks:: addMsg(int pIdMsg, int pBlockCount, int pIdProc,
     char* pNameProc,char* pMsgText, char* pStatus)
{
    MsgByProcess* msg= NULL;
    Block* blockLocate=NULL;
    Process* process = NULL;
    process = getProcess(pIdProc);
    if (process== NULL)
        process = addProcess(pIdProc,pNameProc);
    blockLocate = getBlock(pBlockCount);

    if (blockLocate== NULL)
    {
        blockLocate = addBlock(listBlocks.size(),pBlockCount);
    }
    msg= blockLocate->getMsg(pIdMsg,process->id);

    if (msg!=NULL)
    {
        cout<< "Msg Localizada/Existente no processo Local! Msg="<< pMsgText;
    }
    else
    {
      blockLocate->addMsg(pIdMsg,pMsgText, pStatus, pBlockCount, process->id, true);
      cout<<" add MSG ("<<msg->text<<") idRemetente="<<msg->idRemetente<<
          " idBCRemetente= "<<msg->idRemetente<< " BCLocal="<<pBlockCount;
    }

  return  msg;


}


void ManagerBlocks::setEventSendBlockCount()
{
  this->blockCount++;

}

Block* ManagerBlocks::getBlock(int pBlockCount)
{
    Block* blockLocate = NULL;
    unsigned int index = 0;
    bool find=false;

    while ((!find) && (this->listBlocks.size()> index))
    {
       //c = dynamic_cast<Channel*>(&channels[index]);
       blockLocate = dynamic_cast<Block*>(listBlocks[index]);
       if (blockLocate->idBlockCount == pBlockCount)
          find=true;
       else blockLocate=NULL;
        ++index;
    }
    return blockLocate;
}



void ManagerBlocks::insertProcessInlist(int pCountProcess)
{
    for(int i=0;i<pCountProcess; i++)
    {
      addProcess(i, "");

    }
    cout<<"\n   => Lista com "<< pCountProcess <<" inserida no processo "<< idProcessLocal;
}

void ManagerBlocks:: printBlocks()
{
    Block* blockCurrent = NULL;
    unsigned int indexb = 0;
    while (this->listBlocks.size()> indexb)
    {
           //c = dynamic_cast<Channel*>(&channels[index]);
      blockCurrent = dynamic_cast<Block*>(listBlocks[indexb]);
      cout<<"\nBlock("<<blockCurrent->id<<") BC= "<<blockCurrent->idBlockCount;
      blockCurrent->printMsgs();
      indexb++;
    }
}

bool ManagerBlocks:: checkBlockComplete(Block* pBlock, bool pIsDelivery,
   bool updateMaxBlocoInDelivery, double pTimeDelivery)
{   cout<< "\n--->Verificando a completude dos blocos numMSG="<<pBlock->ListMsgByProcess.size()
        << " TotalAReceber= "<<processCount;
    pBlock->isComplete =false;
    LRV_->updateLRV(listBlocks, listProcess);
    if (pBlock->ListMsgByProcess.size() >=processCount)
    { pBlock->isComplete=true;
      cout<< "\n--->Completo=True";

      if (pIsDelivery==true)
      {
          deliveryBlock(pBlock->idBlockCount,pTimeDelivery, updateMaxBlocoInDelivery, false);
      }
    }
    else {
      cout<< "\n--->Completo=False";
      pBlock->isDelivery=false;
    }
    return pBlock->isComplete;
}

void ManagerBlocks:: setBlockCount(int pValor)
{
  blockCount = pValor;
}

int ManagerBlocks::getBlockCount()
{
  return this->blockCount;
}

int ManagerBlocks::getMaxBlockCount(int pValue1, int pValue2)
{
  if (pValue1>pValue2)
      return pValue1;
  else
      return pValue2;
}

void ManagerBlocks:: incrementaBlockCount()
{
   int currentValueBC = getBlockCount();
   cout <<"\n Atualização do BC OLD= "<<currentValueBC;

   /*
     * De acordo com as regras dos blocos causais,
     * O blockCaount deve ser incrementado a cada envio
   */
   currentValueBC++;
   setBlockCount(currentValueBC);
   cout << "New= "<<getBlockCount();
}

time_t ManagerBlocks::getCurrentTime()
{
    time_t rawtime;
    time(&rawtime);
    return rawtime;
}



//Pega a lista de blocos e entrega à camada de aplicação apenas os completos.
//um print será realizado para simular a camada de aplicação
void ManagerBlocks::deliveryCompleteBlocks(double pTimeDeliverySimulator,bool updateMaxBloco)
{

    Block* block = NULL;
    for (int i=0;i<listBlocks.size();i++)
    {
        block = dynamic_cast<Block*>(listBlocks[i]);
        if (block->isComplete && !block->isDelivery )
        {
            deliveryBlock(block, pTimeDeliverySimulator, updateMaxBloco, false);

        }
    }

}

void ManagerBlocks::deliveryBlock(Block* pBlock, double pTimeDeliverySimulator,
    bool updateMaxBloco, bool pDeliveryBlockNotComplete)
{
   cout <<"\n---> Efetuando Delivery tempoSimulador = "<< pTimeDeliverySimulator;
   if (!pBlock->isDelivery && (pBlock->isComplete  ||
      pDeliveryBlockNotComplete))
    {

       if (pBlock!= NULL)
       {  cout<< "\nDelivery do IDBloco ="<< pBlock->idBlockCount;

          pBlock->setIsDelivery(true);
          pBlock->isValid = !pBlock->isDelivery;
          pBlock->timeDelivery =getCurrentTime();
          pBlock->timeDeliverySimulator = pTimeDeliverySimulator;

         //Imprime as mensagens na tela simulando entrega à camada de aplicação.
          //pBlock->printMsgs();

          //Atualiza o contador de Blocos
          if (updateMaxBloco)
          {
            setBlockCount(getMaxBlockCount(pBlock->idBlockCount, getBlockCount()));
          }
       }
       else
       cout<< "\n Não foi possivel realizar o Delivery do IDBloco! BlocoNULL";
   }
   else {cout<< "\n Delivery já efetuado anteriormente";}
}


void ManagerBlocks::deliveryBlock(int pBlockCount, double pTimeDeliverySimulator, bool updateMaxBloco,
    bool pDeliveryBlockNotComplete)
{
    Block* blockLocate=NULL;
    blockLocate = getBlock(pBlockCount);
    deliveryBlock(blockLocate, pTimeDeliverySimulator, updateMaxBloco, pDeliveryBlockNotComplete);
}


bool ManagerBlocks:: MarkBlockPerMsgPerProcess(
        int pIdMsgRemetente,char* pText,
        int pIdBCRemetente, int pIdProcess,
        Block* pBloco, time_t timeReceive, double ptimeReceiveSimulator,
        bool pIsUpdateMAxBCInEventReceive, bool pDeliveryBlockComplete,
        bool pPrintBlockDelivery,
        MsgByProcess *pMsgMarked)
{   bool result = false;
    MsgByProcess* msg= NULL;
    if ((!pBloco->getIsComplete()) &&(!pBloco->getIsDelivery()))
    {
      msg=findOrAddNewMSG(pIdMsgRemetente, pText, "+", pIdBCRemetente,pIdProcess, pBloco);
      if (msg!=NULL)
      {
          msg->status="+";
          msg->timeReceive=timeReceive;
          msg->timeReceiveSimulator=ptimeReceiveSimulator;

         //Gerencia o Delivery das Mensagens
         ManagerCheckblockComplete(pBloco, msg,pDeliveryBlockComplete,pPrintBlockDelivery, ptimeReceiveSimulator);
         //Altera o BlockCount(BC) para o maior valor entre o recebido e o atual da base
         if (pIsUpdateMAxBCInEventReceive==true)
         {
            updateMaxBC(getBlockCount(),pIdBCRemetente);
         }

         pMsgMarked = msg;
         result =true;

      }
    }

    return result;
}

void ManagerBlocks::ManagerCheckblockComplete(Block *pCausalBlock, MsgByProcess *pMsgBlock,
  bool pIsDelivery , bool  pPrintMSG, double pTimeDeliverySimulator)
{
    checkBlockComplete(pCausalBlock, true,true,pTimeDeliverySimulator);
    MsgByProcess *msgAtual=NULL;
    if (pCausalBlock->isDelivery)
    {
      //Verificar a possibilidade de vincularas mensagens ao controel estatistico
    }

}

void ManagerBlocks:: updateMaxBC(int pReceiveValue, int pCurrentvalue)
{
    setBlockCount(getMaxBlockCount(
           pReceiveValue,pCurrentvalue));
}

Process* ManagerBlocks::findOrAddNewProcess(int pIdProcess, char* pNameProcess)
{
  Process* process = NULL;
  process = getProcess(pIdProcess);

  if (process== NULL)
  {
    process = addProcess(pIdProcess,pNameProcess);
    cout<<"\n Processo criado com sucesso!";
  }
  else
  { cout<<"\nProcesso já existente na base!"; }

  return process;

}
Block* ManagerBlocks:: findOrAddNewBlock( int pIdBC)
{
    Block* blockLocate=NULL;
    //Localiza um BlocoCausal e se não existri, cria-se um novo
    blockLocate = getBlock(pIdBC);
    if (blockLocate== NULL)
    {
      blockLocate = addBlock(listBlocks.size(),pIdBC);
      blockLocate->isComplete= false;
      blockLocate->isDelivery= false;
      blockLocate->isValid= true;
      //Configura o timesilence
      cout<< "\n => Adicionando um novo Bloco IDBloco ="<< blockLocate->id;
    }
    else
   {cout<<"\n Bloco já existente na base!";}

   return blockLocate;
}

MsgByProcess* ManagerBlocks:: findOrAddNewMSG(int pIdMsgRemetente,char* pText, char* pStatus, int pIdBCRemetente, int pIdProcess, Block* pBloco)
{
    MsgByProcess* msg= NULL;
    msg= pBloco->getMsg(pIdProcess);
    if(msg==NULL)
    {
        msg = pBloco->addMsg(pIdMsgRemetente,pText,pStatus,
        pIdBCRemetente, pIdProcess, true);

   }else { cout<<"\n Mensagem já existente no Bloco!"; }

   return msg;
}

bool ManagerBlocks:: findMSGByBlockCount(int pIdMsgRemetente,int pIdProcess, Block* pBloco)
{
    MsgByProcess* msg= NULL;
    msg= pBloco->getMsg(pIdProcess);
    if(msg!=NULL && msg->status=="+" )
    {
       return true;

   }else { return false; }

}


vector<Block*> ManagerBlocks::filterBlocksByProcess(int pIdProcess)
{
   Block* block = NULL;
   vector<Block*>  listBlocksByProcess;
   for (int i=0;i<listBlocks.size();i++)
   {
      block = dynamic_cast<Block*>(listBlocks[i]);
      if(block->idBlockProcessoOrigem = pIdProcess)
      {
          listBlocksByProcess.push_back(block);

      }
   }
   return listBlocksByProcess;

}




ManagerBlocks::~ManagerBlocks() {
    // TODO Auto-generated destructor stub
}





