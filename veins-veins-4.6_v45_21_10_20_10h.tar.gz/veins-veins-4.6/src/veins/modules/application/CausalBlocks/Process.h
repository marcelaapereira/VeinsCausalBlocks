//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_PROCESS_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_PROCESS_H_
#include <veins/modules/application/CausalBlocks/MLDV.h>
#include <veins/modules/application/CausalBlocks/MLDVWithFaulty.h>
#include <vector>

class Process {
public:
    int id;
    char* name;
    int processCount;
    vector<MLDV*> MLDVi;
    vector<MLDVWithFaulty*>listMLDVWithFaulty;

    Process();
    virtual ~Process();
    Process(int pId, char* pName, int processCount);
    void addMLDVByProcessWithFaulty(int pProcessSender, int pProcessWithFaulty, MLDV *pMldv, int pBlockCount);
    MLDVWithFaulty* findMLDVByProcessWithFaulty(int pProcessSender, int pProcessWithFaulty,
      int pBlockCount);
    bool updateMLDVOfProcessWithFaulty(int pProcessSender,int pProcessWithFaulty, MLDVWithFaulty *MLDVLocated,
      int pBlockCount, int pIdMsg);


    MLDV* getCurrentMLDVi();
    MLDV* createMLDVi(bool pInsertInList, int processCount);
    int getValueLDVByPositionInMLDVi(int pPos,int pIdProcess);
    void printMLDVi();
};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_PROCESS_H_ */
