//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/Process.h>
#include <veins/modules/application/CausalBlocks/MLDV.h>
#include <vector>
#include <string.h>

using namespace std;

Process::Process() {
    // TODO Auto-generated constructor stub
  id = -1;
}
Process:: Process(int pId, char* pName, int processCount){
  this->id = pId;
  this->name = pName;
  this->processCount = processCount;
  createMLDVi(true, processCount);

}

MLDV* Process::getCurrentMLDVi()
{
  int tam = MLDVi.size();
  MLDV *resultMLDV;
  if(tam>0)
      resultMLDV= dynamic_cast<MLDV*>(MLDVi[tam-1]);

  return resultMLDV;

}

int Process::getValueLDVByPositionInMLDVi(int pPos,int pIdProcess)
{
  int returnValue =-1;
  for (int i=0;i<MLDVi.size(); i++)
  {
    if (i==pPos)
      returnValue = MLDVi[i]->LDVi[pIdProcess];
  }

  return returnValue;
}

MLDV* Process:: createMLDVi(bool pInsertInList, int processCount)
{  MLDV* newMLDV = new MLDV();

   for(int i=0; i < processCount;i++)
   {
     newMLDV->LDVi.push_back(i);
     newMLDV->LDVi[i]=0;
     newMLDV->idBlockCount = 1;
   }
   this->MLDVi.push_back(newMLDV);
   return  newMLDV;
}

void Process::addMLDVByProcessWithFaulty(int pProcessSender, int pProcessWithFaulty,
  MLDV *pMldv, int pBlockCount ) {
    MLDVWithFaulty* currentMLDVWithFaulty = new MLDVWithFaulty();

    listMLDVWithFaulty.push_back(currentMLDVWithFaulty);
    currentMLDVWithFaulty->processSender = pProcessSender;
    currentMLDVWithFaulty->processWithFaulty= pProcessWithFaulty;
    currentMLDVWithFaulty->blockCountForventet;
    currentMLDVWithFaulty->currentMLDVI = pMldv;

}


MLDVWithFaulty* Process::findMLDVByProcessWithFaulty(int pProcessSender, int pProcessWithFaulty,
  int pBlockCount) {
  MLDVWithFaulty *currentMLDVWithFaulty = NULL;
   for(int i=0; i<listMLDVWithFaulty.size() ; i++)
    {
        currentMLDVWithFaulty= dynamic_cast<MLDVWithFaulty*>(listMLDVWithFaulty[i]);

       if ((currentMLDVWithFaulty->processSender == pProcessSender) &&
         (currentMLDVWithFaulty->processWithFaulty== pProcessWithFaulty)&&
         (currentMLDVWithFaulty->blockCountForventet==pBlockCount))
       {

           return currentMLDVWithFaulty;
           break;
       }
    }
    return currentMLDVWithFaulty;
}

bool Process::updateMLDVOfProcessWithFaulty(int pProcessSender,int pProcessWithFaulty,
        MLDVWithFaulty *MLDVLocated, int pBlockCount, int pIdMsg) {


    if ((MLDVLocated->processSender == pProcessSender) &&
       (MLDVLocated->processWithFaulty== pProcessWithFaulty)&&
       (MLDVLocated->blockCountForventet==pBlockCount))
    {
        MLDVLocated->currentMLDVI->LDVi[pProcessWithFaulty]= pBlockCount;
        if (MLDVLocated->isReceived)
        {
            MLDVLocated->countReceive++;

        }
        else
            MLDVLocated->isReceived= true;
    }
}


Process::~Process() {
    // TODO Auto-generated destructor stub
}

