//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_STATISTICALCONTROL_CONTROLMESSAGE_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_STATISTICALCONTROL_CONTROLMESSAGE_H_

#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlProcessoSender.h>
#include <vector>
#include <time.h>

using namespace std;

class ControlMessage {
public:
    int idMSGSender;
    int idProcessoSender;
    time_t timeSender;
    double timeSenderOfSimul;

    int size;
    vector<ControlProcessoSender*> listProcess;
    ControlMessage(int pIdMSGSender, int pIdProcessoSender, time_t pTimeSender,  double pTimeSenderOfSimulator, int pSize);

    ControlProcessoSender* getProcesso(int pID);
    ControlProcessoSender* addProcesso(int pIdprocesso, time_t pTimeReceive);
    void addTimeReceiveInProcess(int pIdprocesso, time_t pTimeReceive, int pContReplay, time_t pTimeRequestRelay,
       time_t pTimeEndRelay, double pTimeReceiveSimulator, double pTimepTimeRequestRelaySimulator,
       double pTimeEndRelaySimulator);
    void addTimeDeliveryInProcess(int pIdprocesso, time_t pTimeDelivery, double pTimeDeliverySimulator);
    void incrementRelayInProcess(int pIdprocesso);
    void addtimeStartRelayInProcess(int pIdprocesso, time_t pTime, double pTimeSimulator);
    void addtimeEndRelayInProcess(int pIdprocesso, time_t pTime, double pTimeSimulator);
    void addFaultyMessageInProcess(int pIdprocesso);
    ControlProcessoSender* addProcesso(int pIdprocesso);
    virtual ~ControlMessage();
};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_STATISTICALCONTROL_CONTROLMESSAGE_H_ */
