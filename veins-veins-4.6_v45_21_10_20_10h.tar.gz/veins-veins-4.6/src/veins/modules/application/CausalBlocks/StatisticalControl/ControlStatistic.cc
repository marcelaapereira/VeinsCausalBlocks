//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlStatistic.h>
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlMessage.h>
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlProcessoSender.h>
#include <iostream>

ControlStatistic::ControlStatistic() {
    // TODO Auto-generated constructor stub
    this->countMSG=0;
    this->countCar = 0;
    this->ClickSimulator=false;
    this->clockSistem=false;

}

int ControlStatistic:: incrementCountMSG(){
    return countMSG++;
}

ControlMessage* ControlStatistic:: getMSG(int pID){
   unsigned int index = 0;
   bool find=false;

   ControlMessage* msgAtual = NULL;
   ControlMessage* msgLocate = NULL;
      for(index=0;index < this->listMSGSender.size(); index++)
      {
          msgAtual = dynamic_cast<ControlMessage*>(listMSGSender[index]);
         if (msgAtual->idMSGSender == pID)
         {
   //          cout<<"\nModulo Estatístico: Mensagem encontrada id="<<pID;
             msgLocate = msgAtual;
             break;
         }
      }

      return msgLocate;

}

void ControlStatistic::addMSG(int pID, int pTam, time_t pTimeSender, double pTimeSenderOfSimulator, int pIdProcSender){
    ControlMessage* msg= NULL;

    msg = getMSG(pID);

    if (msg==NULL)
    {   msg = new ControlMessage(pID,pIdProcSender, pTimeSender,pTimeSenderOfSimulator,pTam);
        listMSGSender.push_back(msg);

        msg = dynamic_cast<ControlMessage*>(listMSGSender[listMSGSender.size()-1]);

    }
    else {cout<<"\nModulo Estatístico:Não foi possível adicionar a mensagem! IDMSG="<<pID<<" já existente";}
}

void ControlStatistic::addTimeReceiveInMSG(int pIdMSG, time_t pTime,int pIdProcReceptor, int pContReplay, time_t pTimeRequestRelay,
    time_t pTimeEndRelay, double pTimeReceiveSimulator, double pTimepTimeRequestRelaySimulator,
    double pTimeEndRelaySimulator){
    ControlMessage* msg= NULL;
    msg = getMSG(pIdMSG);
   // cout<<"\nModulo Estatístico:addTimeReceiveInMSG()!";
    if (msg!=NULL)
    {
       // cout<<"\nModulo Estatístico:Mensagem Encontrada!";
        msg->addTimeReceiveInProcess(pIdProcReceptor, pTime, pContReplay, pTimeRequestRelay,pTimeEndRelay, pTimeReceiveSimulator,
                pTimepTimeRequestRelaySimulator, pTimeEndRelaySimulator);
    }
    else {cout<<"\nModulo Estatístico:Mensagem não Encontrada para adicionar o timeReceive!";}
}

void ControlStatistic::addCountRetransmissionReceipt(int pIdMSG,int pIdProcReeptor, double pTimepTime){
    ControlMessage* msg= NULL;
    ControlProcessoSender* proc;
    msg = getMSG(pIdMSG);
   // cout<<"\nModulo Estatístico:addTimeReceiveInMSG()!";
    if (msg!=NULL)
    {
       // cout<<"\nModulo Estatístico:Mensagem Encontrada!";
        proc = msg->getProcesso(pIdProcReeptor);
        if (proc != NULL)
        {
            proc->countRetransmissionReceipt++;
        }
    }
    else {cout<<"\nModulo Estatístico:Mensagem não Encontrada para adicionar o timeReceive!";}
}

void ControlStatistic::addMessageInListControlMessageFailed(int pIdMSG, int pIdProcSender,
    int pIdProcReceptor, int pBC,
    int pNumberDisseminadOnChannel)
{
    ControlMessageFailed  *messageFailed = new ControlMessageFailed();
    messageFailed->idMessage = pIdMSG;
    messageFailed->ProcessSender = pIdProcSender;
    messageFailed->ProcessReceptor= pIdProcReceptor;
    messageFailed->BC= pBC;
    messageFailed->NumberOfMessagedisseminatedOnchannel= pNumberDisseminadOnChannel;

    listControlMessageFailed.push_back(messageFailed);
}

void ControlStatistic::processDataInListControlMessageFailed()
{   ControlMessageFailed  *messageFailed = NULL;
    ControlMessage* msg= NULL;
    ControlProcessoSender* proc=NULL;

    for (int i=0; i<listControlMessageFailed.size(); i++)
    {
        messageFailed = listControlMessageFailed[i];
        msg = getMSG(messageFailed->idMessage);
        if (msg!=NULL)
        {
            proc = msg->getProcesso(messageFailed->ProcessReceptor);
            if(proc != NULL)
            {
                proc->isFault = 1;
            }

        }

    }
}


void ControlStatistic:: addTimeDeliveryInMSG(int pIdMSG, time_t pTime, double pTimeDelivery, int pIdProcReceptor){
    ControlMessage* msg= NULL;
    ControlProcessoSender* proc=NULL;
    msg = getMSG(pIdMSG);

  //  cout<<"\nModulo Estatístico:addTimeDeliveryInMSG(" <<
   //   pTime << ") ProcReceptor= "<< pIdProcReceptor <<"!";
    if (msg!=NULL)
    {  msg->addTimeDeliveryInProcess(pIdProcReceptor, pTime, pTimeDelivery);
    }
  //  else {cout<<"\nModulo Estatístico:Mensagem não Encontrada para adicionar o addTimeDeliveryInMSG!";}
}

void ControlStatistic::addNewRelayInMSG(int pIdMSG, time_t pTime,int pIdProcReceptor){
    ControlMessage* msg= NULL;
    ControlProcessoSender* proc=NULL;
    msg = getMSG(pIdMSG);

    if (msg!=NULL)
    {  msg->incrementRelayInProcess(pIdProcReceptor);
    }
}
void ControlStatistic::addFaultyMessageInProcess(int pIdMSG, int pIdProcReceptor){
  ControlMessage* msg= NULL;
  ControlProcessoSender* proc=NULL;
  msg = getMSG(pIdMSG);

  if (msg!=NULL)
  {  msg->addFaultyMessageInProcess(pIdProcReceptor); }
}

void ControlStatistic::addEndRelayInMSG(int pIdMSG, time_t pTime, double pTimeSimulator,int pIdProcReceptor){
  ControlMessage* msg= NULL;
  msg = getMSG(pIdMSG);

  if (msg!=NULL)
  {  msg->addtimeEndRelayInProcess(pIdProcReceptor,pTime, pTimeSimulator);  }
}

double getTimeInMiliSeconds(time_t pTime)
{ struct tm * timeinfo;
  double valueInMiliseconds;
  timeinfo = localtime(&pTime);
  valueInMiliseconds=timeinfo->tm_hour*3600+timeinfo->tm_min*60+timeinfo->tm_sec;
  return valueInMiliseconds;
}

char * ControlStatistic::generateInfoForTextWithClockSimulator(){
    char* text=NULL;
    char* nameFile = NULL;
     int countMSG=0;
     int countProc = 0;
     int i=0;
     int j=0;
     int index;
     ControlMessage* msgLocate = NULL;
     ControlProcessoSender* procLocate=NULL;
     double timeReceive=-1;
     double timeDelivery=-1;
     double timeBloqueio=-1;
     double timeSender=-1;
     long idProcesso=-1;
     long countRelay=0;
     long timeRequestRelay=0;
     long timeEndRelay = 0;
     double totalReceive=0;
     double totalDelivery=0;
     double totalBloqueio=0;
     int contMedia=countCar+1;
     //Vincula os dados das mensagens com Falhas ao arquivo
     processDataInListControlMessageFailed();
     //sprintf(nameFile, "simulacao_%d_%dsalto_%fbeacon.txt",countCar,numTotalRelay, periodBecon);
     FILE *cfPtr;
     if ( ( cfPtr = fopen( "clients.dat", "w" ) ) == NULL ) {
         puts( "File could not be opened" );
         } // end if


     if ( ( cfPtr = fopen( "simulacao_CSI_4_beacon_0.5_t.txt", "w" ) ) == NULL ) {
         cout<< "File could not be opened";
     }
     else
     {
         //Imprime, no arquivo, as linhas com os parametros da simulação
         fprintf(cfPtr,"%s", "countCar;countMSG;countMSGByCar;generatedBeacons;receivedBeacons;countRetransmission;PeriodBeacon");
         fprintf(cfPtr,"\n%d;%d;%d;%d;%d,%d,%f",
           this->countCar,
           this->countMSG,
           this->countMSGByCar,
           this->generatedBeacons,
           this->receivedBeacons,
           this->numTotalRelay,
           this->periodBecon
         );




         //Imprimi, no arquivo, os parametros com os dados das mensagens
         fprintf(cfPtr,"%s%s", "\nNumCarroRodovia;NumCarroPelotao;Num.MSGVeiculo;Timesilence;TamMensagem;IdMSG;IdRemetente;IdProcessoDestinatario;countRelay;TimeSender;",
           "TimeReceive;Receive(s);TimeDelivery;Delivery(s);TimeBloqueio;CountReceivedRelay;FalhaSimulation;");


         for(i=0; i< this->listMSGSender.size(); i++ )
         {


           msgLocate = dynamic_cast<ControlMessage*>(listMSGSender[i]);
           cout<<"\n=>>>>>>MSGID(dMSGSender)="<< msgLocate->idMSGSender
             << "Processo Remetente="<< msgLocate->idProcessoSender
             <<"Qtd. Processos Destinatarios = "<<msgLocate->listProcess.size()
             <<"TempoEnvio="<<msgLocate->timeSenderOfSimul;

           for(int j=0;j<countCar;j++)
           {
              if (j<msgLocate->listProcess.size())
              {

                        procLocate = dynamic_cast<ControlProcessoSender*>(msgLocate->listProcess[j]);
                        timeReceive=procLocate->timeReceiveOfSimulator;
                        timeDelivery=procLocate->timeDeliveryOfSimulator;
                        timeSender=msgLocate->timeSenderOfSimul;

                        timeBloqueio=procLocate->timeDeliveryOfSimulator - timeReceive;

                        idProcesso = procLocate->id;
                        countRelay =procLocate->countRelay;
                        timeRequestRelay =  procLocate->timeRequestRelayOfSimulator;
                        timeEndRelay = procLocate->timeEndRelayOfSimulator;

                        totalReceive =totalReceive + (timeReceive - timeSender);
                        totalDelivery = totalDelivery + (timeDelivery  - timeSender);
                        totalBloqueio = totalBloqueio + timeBloqueio;
                        if (countRelay==0)
                        {
                            timeRequestRelay=0;
                            timeEndRelay =0;
                        }

               }
              else{
                         timeReceive=-1;
                         timeDelivery=-1;
                         timeBloqueio=-1;
                         timeSender=-1;
                         countRelay =0;
                         timeRequestRelay = 0;
                         timeEndRelay = -1;
                         idProcesso = -1;
              }
              cout<<"\n Processo= "<< idProcesso
                  <<" Sender="<<timeSender<<" Receive="<< timeReceive
                  << " Delivery="<<timeDelivery << " Bloqueio="<<timeBloqueio
                  <<" contRetrans.="<< countRelay<<"timeRequestRelay="<<timeRequestRelay
                  <<" timeEndRelay="<<timeEndRelay
                  <<"CountReceivedRelay="<< procLocate->countRetransmissionReceipt
                  <<"IsFaultSimulation ="<< procLocate->isFault;

              fprintf(cfPtr,"\n%d;%d;%d;%d;%f;%d;%d;%d;%d;%f;%f;%f;%f;%f;%f;%d;%d",
                      //"%d;%d;%d;%d;d",
                       countCarOfTheRoad,
                       countCar,
                       countMSGByCar,
                       timeSilence,
                       tamMsg,
                       msgLocate->idMSGSender,
                       msgLocate->idProcessoSender,
                       idProcesso,
                       countRelay,
                       timeSender,
                       timeReceive,
                       (timeReceive -timeSender),
                       timeDelivery,
                       (timeDelivery-timeSender),
                       timeBloqueio,
                       procLocate->countRetransmissionReceipt,
                       procLocate->isFault
                       //   timeRequestRelay,timeEndRelay,timeReceive,timeDelivery,
                       );
              countProc++;


           }

           fprintf(cfPtr,";=MÉDIA(F%d:F%d);=MÉDIA(H%d:H%d);=MÉDIA(I%d:I%d)",contMedia-2,contMedia,
              contMedia-2,contMedia,contMedia-2,contMedia);

           contMedia =countCar + 1;

         /*  for(j=0; j< msgLocate->listProcess.size(); j++ )
           {
                 procLocate = dynamic_cast<ControlProcessoSender*>(msgLocate->listProcess[j]);
                 cout<<"\n Processo= "<< procLocate->id
                     <<" Receive="<< procLocate->timeReceive
                     << " Delivery="<<procLocate->timeDelivery;
                 timeBloqueio= procLocate->timeDelivery - msgLocate->timeSender;
                 fprintf(cfPtr,"\n%d;%d;%d,%d;%d;%d;%d;%d;%d;%d \n", msgLocate->idMSGSender, msgLocate->idProcessoSender,
                    msgLocate->timeSender,procLocate->id,procLocate->timeReceive, procLocate->timeDelivery, timeBloqueio,
                    procLocate->countRelay,procLocate->timeRequestRelay, procLocate->timeEndRelay);

                  countProc++;
            }

            // sprintf(text, "%f",getTimeInMiliSeconds(msgLocate->timeSender))
             *           */
           countMSG++;
         }

         totalReceive = totalReceive/countCar;
         totalDelivery = totalDelivery/countCar;
         totalBloqueio = totalBloqueio/countCar;
         fprintf(cfPtr,"\n\n Media Receive;MediaDelivery;MediaBloqueio \n%d;%d;%d",totalReceive, totalDelivery, totalBloqueio);
         fprintf(cfPtr,"\n\n =MÉDIA(D5-D9-D13-D15-D21-D25);MÉDIA(H5-H9-H13-H15-H21-H25);MÉDIA(I5-I9-I13-I15-I21-I25)");
         fclose(cfPtr);
         cout <<"\n MediaReceive = "<<totalReceive <<" Media Delivery="<<totalDelivery<< " MediaBloqueio="<<totalBloqueio;
     }



     cout<<"-------- Módulo Estatístico---------<<"
       <<"TotalMSG"<< listMSGSender.size() <<"\n"<<text;
     return text;

}

char * ControlStatistic::generateInfoForText(){
  char* text=NULL;
  int countMSG=0;
  int countProc = 0;
  int i=0;
  int j=0;
  int index;
  ControlMessage* msgLocate = NULL;
  ControlProcessoSender* procLocate=NULL;
  long timeReceive=0;
  long timeDelivery=0;
  long timeBloqueio=0;
  long timeSender=0;
  long idProcesso=0;
  long countRelay=0;
  long timeRequestRelay=0;
  long timeEndRelay = 0;
  double totalReceive=0;
  double totalDelivery=0;
  double totalBloqueio=0;
  int contMedia=countCar+1;

  //Processa as msg com falhas para vincula-las ao arquivo
  processDataInListControlMessageFailed();

  FILE *cfPtr;
  if ( ( cfPtr = fopen( "clients.dat", "w" ) ) == NULL ) {
      puts( "File could not be opened" );
      } // end if

  if ( ( cfPtr = fopen( "simulacao.txt", "w" ) ) == NULL ) {
      cout<< "File could not be opened";
  }
  else
  {
      fprintf(cfPtr,"%s%s%s", "IdMSG;IdRemetente;TimeSender;IdProcessoDestinatario;",
        "TimeReceive;Receive(s);TimeDelivery;Delivery(s);TimeBloqueio;countRelay;TimeRequestRelay;TimeEndRelay;",
        "TotalEntrega; TotalDelivery, TotalBloqueio, TotalReceivedRelay");

      for(i=0; i< this->listMSGSender.size(); i++ )
      {


        msgLocate = dynamic_cast<ControlMessage*>(listMSGSender[i]);
        cout<<"\n=>>>>>>MSGID(dMSGSender)="<< msgLocate->idMSGSender
          << "Processo Remetente="<< msgLocate->idProcessoSender
          <<"Qtd. Processos Destinatarios = "<<msgLocate->listProcess.size()
          <<"TempoEnvio="<<msgLocate->timeSender;

           for(int j=0;j<countCar;j++)
        {
           if (j<msgLocate->listProcess.size())
           {
                     procLocate = dynamic_cast<ControlProcessoSender*>(msgLocate->listProcess[j]);
                     timeReceive=procLocate->timeReceive;
                     timeDelivery=procLocate->timeDelivery;
                     timeBloqueio=procLocate->timeDelivery - timeReceive;
                     timeSender=msgLocate->idMSGSender;
                     idProcesso = procLocate->id;
                     timeSender=0;
                     countRelay =procLocate->countRelay;
                     timeRequestRelay =  procLocate->timeRequestRelay;
                     timeEndRelay = procLocate->timeEndRelay;

                     totalReceive =totalReceive + (timeReceive - msgLocate->idMSGSender);
                     totalDelivery = totalDelivery + (timeDelivery  - msgLocate->idMSGSender);
                     totalBloqueio = totalBloqueio + timeBloqueio;
                     if (countRelay==0)
                     {
                         timeRequestRelay=0;
                         timeEndRelay =0;
                     }
            }
           else{
                      timeReceive=0;
                      timeDelivery=0;
                      timeBloqueio=0;
                      timeSender=0;
                      countRelay =0;
                      timeRequestRelay = 0;
                      timeEndRelay = 0;
                      idProcesso = -1;
           }
           cout<<"\n Processo= "<< idProcesso
               <<" Receive="<< timeReceive
               << " Delivery="<<timeDelivery;

           fprintf(cfPtr,"\n%d;%d;%d,%d;%d;%d;%d;%d;%d;%d;%d;%d;%d;%d;%d,%d",
                    msgLocate->idMSGSender,
                    msgLocate->idProcessoSender,
                    msgLocate->timeSender,
                    idProcesso,
                    timeReceive,
                    timeReceive -msgLocate->timeSender,
                    timeDelivery,
                    timeDelivery- msgLocate->timeSender,
                    timeBloqueio,
                    countRelay,
                    timeRequestRelay,
                    timeEndRelay,
                    timeReceive,
                    timeDelivery,
                    timeBloqueio,
                    procLocate->countRetransmissionReceipt);
           countProc++;


        }

        fprintf(cfPtr,"\n\ =MÉDIA(F%d:F%d);=MÉDIA(H%d:H%d);=MÉDIA(I%d:I%d)",contMedia-2,contMedia,
           contMedia-2,contMedia,contMedia-2,contMedia);

        contMedia =countCar + 1;

      /*  for(j=0; j< msgLocate->listProcess.size(); j++ )
        {
              procLocate = dynamic_cast<ControlProcessoSender*>(msgLocate->listProcess[j]);
              cout<<"\n Processo= "<< procLocate->id
                  <<" Receive="<< procLocate->timeReceive
                  << " Delivery="<<procLocate->timeDelivery;
              timeBloqueio= procLocate->timeDelivery - msgLocate->timeSender;
              fprintf(cfPtr,"\n%d;%d;%d,%d;%d;%d;%d;%d;%d;%d \n", msgLocate->idMSGSender, msgLocate->idProcessoSender,
                 msgLocate->timeSender,procLocate->id,procLocate->timeReceive, procLocate->timeDelivery, timeBloqueio,
                 procLocate->countRelay,procLocate->timeRequestRelay, procLocate->timeEndRelay);

               countProc++;
         }

         // sprintf(text, "%f",getTimeInMiliSeconds(msgLocate->timeSender))
          *           */
        countMSG++;
      }

      totalReceive = totalReceive/countCar;
      totalDelivery = totalDelivery/countCar;
      totalBloqueio = totalBloqueio/countCar;
      fprintf(cfPtr,"\n\n Media Receive;MediaDelivery;MediaBloqueio \n%d;%d;%d",totalReceive, totalDelivery, totalBloqueio);
      fprintf(cfPtr,"\n\n =MÉDIA(D5-D9-D13-D15-D21-D25);MÉDIA(H5-H9-H13-H15-H21-H25);MÉDIA(I5-I9-I13-I15-I21-I25)");
      fclose(cfPtr);
      cout <<"\n MediaReceive = "<<totalReceive <<" Media Delivery="<<totalDelivery<< " MediaBloqueio="<<totalBloqueio;
  }



  cout<<"-------- Módulo Estatístico---------<<"
    <<"TotalMSG"<< listMSGSender.size() <<"\n"<<text;
  return text;
}

void ControlStatistic::addStartRelayInMSG(int pIdMSG, time_t pTime, double pTimeSimulator, int pIdProcReceptor){
  ControlMessage* msg= NULL;
  ControlProcessoSender* proc=NULL;
  msg = getMSG(pIdMSG);

  if (msg!=NULL)
  {  msg->addtimeStartRelayInProcess(pIdProcReceptor,pTime, pTimeSimulator);  }
}

ControlStatistic::~ControlStatistic() {
    // TODO Auto-generated destructor stub
}

