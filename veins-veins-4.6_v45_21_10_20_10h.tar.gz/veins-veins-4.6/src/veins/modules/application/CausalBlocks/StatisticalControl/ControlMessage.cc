//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlMessage.h>
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlProcessoSender.h>

#include <iostream>
#include <time.h>

using namespace std;

ControlMessage::ControlMessage(int pIdMSGSender, int pIdProcessoSender,  time_t pTimeSender, double pTimeSenderOfSimulator, int pSize) {
    // TODO Auto-generated constructor stub
  this->idMSGSender = pIdMSGSender;
  this->idProcessoSender= pIdProcessoSender;
  this->timeSender= pTimeSender;
  this->timeSenderOfSimul=pTimeSenderOfSimulator;
  this->size= pSize;
}

ControlProcessoSender* ControlMessage::getProcesso(int pID)
{  ControlProcessoSender* procLocate = NULL;
   ControlProcessoSender* procAtual = NULL;

   for(int index=0;index<listProcess.size();index++)
   {
      //c = dynamic_cast<Channel*>(&channels[index]);
      procAtual = dynamic_cast<ControlProcessoSender*>(listProcess[index]);
      if (procAtual->id == pID)
      {
          procLocate = procAtual;
          cout<<"Modulo estatistico: Get o processo "<<pID;
          break;
      }
    }
   return procLocate;

}

ControlProcessoSender* ControlMessage::addProcesso(int pIdprocesso, time_t pTimeReceive)
{
    ControlProcessoSender* proc= NULL;
    proc = getProcesso(pIdprocesso);

    if (proc==NULL)
    {   proc = new ControlProcessoSender(pIdprocesso, pTimeReceive);
        listProcess.push_back(proc);
        proc = dynamic_cast<ControlProcessoSender*>(listProcess[listProcess.size()-1]);

    }
    return proc;

}

ControlProcessoSender* ControlMessage::addProcesso(int pIdprocesso)
{
    ControlProcessoSender* proc= NULL;
    proc = getProcesso(pIdprocesso);

    if (proc==NULL)
    {   proc = new ControlProcessoSender(pIdprocesso, 0);
        proc->id = pIdprocesso;
        listProcess.push_back(proc);
        proc = dynamic_cast<ControlProcessoSender*>(listProcess[listProcess.size()-1]);

    }
    return proc;

}



void ControlMessage:: addTimeReceiveInProcess(int pIdprocesso, time_t pTimeReceive,int pContReplay,
        time_t pTimeRequestRelay, time_t pTimeEndRelay, double pTimeReceiveSimulator,
        double pTimepTimeRequestRelaySimulator,
        double pTimeEndRelaySimulator){
   ControlProcessoSender* proc=NULL;

   proc = getProcesso(pIdprocesso);

   if(proc==NULL)
   {


     proc= addProcesso(pIdprocesso, pTimeReceive);
    // cout<<"\n   => Modulo Estatístico:=>addTimeReceiveInProcess  Processo = "<<pIdprocesso;

   }
   proc->timeReceive = pTimeReceive;
   proc->countRelay = pContReplay;
   proc->timeRequestRelay = pTimeRequestRelay;
   proc->timeEndRelay=pTimeEndRelay;

   proc->timeReceiveOfSimulator = pTimeReceiveSimulator;
   proc->timeRequestRelayOfSimulator = pTimepTimeRequestRelaySimulator;
   proc->timeEndRelayOfSimulator = pTimeEndRelaySimulator;

  // cout <<"\n   =>Modulo Estatístico:Adicinanado o tempo para o processo "<< pIdprocesso;
 }

void ControlMessage:: addFaultyMessageInProcess(int pIdprocesso){
   ControlProcessoSender* proc=NULL;

   proc = getProcesso(pIdprocesso);

   if(proc==NULL)
   {
     proc= addProcesso(pIdprocesso);
    // cout<<"\n   => Modulo Estatístico:=>addTimeReceiveInProcess  Processo = "<<pIdprocesso;

   }
   proc->isFault=1;
  // cout <<"\n   =>Modulo Estatístico:Adicinanado o tempo para o processo "<< pIdprocesso;
 }

void ControlMessage::addTimeDeliveryInProcess(int pIdprocesso, time_t pTimeDelivery, double pTimeDeliverySimulator)
{
    ControlProcessoSender* proc=NULL;
    proc = getProcesso(pIdprocesso);

    if (proc!=NULL)
    {
      proc->timeDelivery = pTimeDelivery;
      proc->timeDeliveryOfSimulator = pTimeDeliverySimulator;
    }
    else{ cout<<"\n   =>Modulo Estatístico: Processo("<<pIdprocesso <<") não encontrado para add o Delivery tempo="
      << pTimeDeliverySimulator;
    }
}

void ControlMessage::incrementRelayInProcess(int pIdprocesso)
{  ControlProcessoSender* proc=NULL;
   proc = getProcesso(pIdprocesso);

   if (proc!=NULL)
   { proc->countRelay++;
   //  cout <<"\n  =>Modulo Estatístico:Incrementando o Relay "<< pIdprocesso;
   }
}

void ControlMessage::addtimeStartRelayInProcess(int pIdprocesso, time_t pTime, double pTimeSimulator)
{
    ControlProcessoSender* proc=NULL;
    proc = getProcesso(pIdprocesso);

    if (proc!=NULL)
    { proc->timeRequestRelay = pTime;
      proc->timeRequestRelayOfSimulator = pTimeSimulator;
   //   cout <<"\n  =>Modulo Estatístico:Adicinanado o addtimeStartRelayInProcess para o processo "<<
    //    pIdprocesso;
      incrementRelayInProcess(pIdprocesso);
    }

}

void ControlMessage::addtimeEndRelayInProcess(int pIdprocesso, time_t pTime, double pTimeSimulator)
{
    ControlProcessoSender* proc= NULL;
    proc = getProcesso(pIdprocesso);

    if (proc!=NULL)
    { proc->timeEndRelay = pTime;
      proc->timeEndRelayOfSimulator = pTimeSimulator;
      //cout <<"\n  =>Modulo Estatístico:Adicinanado o addtimeEndRelayInProcess para o processo "<<
      //  pIdprocesso;
    }
}

ControlMessage::~ControlMessage() {
    // TODO Auto-generated destructor stub
}
