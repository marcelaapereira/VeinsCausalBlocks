//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_STATISTICALCONTROL_CONTROLSTATISTIC_H_
#define SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_STATISTICALCONTROL_CONTROLSTATISTIC_H_
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlMessage.h>
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlProcessoSender.h>
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlMessageFailed.h>
#include <iostream>
#include <time.h>
#include <vector>

class ControlStatistic {
public:
    vector<ControlMessage*> listMSGSender;
    int countMSG;
    int countMSGByCar;
    int countCarOfTheRoad;
    int timeSilence;
    int countCar;
    float tamMsg;
    bool ClickSimulator;
    bool clockSistem;
    ControlStatistic();
    int incrementCountMSG();
    vector <ControlMessageFailed*> listControlMessageFailed;
    int generatedBeacons;
    int receivedBeacons;
    int numTotalRelay;
    double periodBecon=0;
    ControlMessage* getMSG(int pID);
    virtual ~ControlStatistic();

    void addMSG(int pID, int pTam, time_t pTimeSender, double pTimeSenderOfSimulator, int pIdProcSender);
    void addTimeReceiveInMSG(int pIdMSG, time_t pTime,int pIdProcReceptor,int pContReplay, time_t pTimeRequestRelay,
         time_t pTimeEndRelay, double pTimeReceiveSimulator, double pTimepTimeRequestRelaySimulator,
         double pTimeEndRelaySimulator);
    void addTimeDeliveryInMSG(int pIdMSG, time_t pTime,double pTimeDelivery,int pIdProcReceptor);
    void addNewRelayInMSG(int pIdMSG, time_t pTime,int pIdProcReceptor);


    void addStartRelayInMSG(int pIdMSG, time_t pTime, double pTimeSimulator,int pIdProcReceptor);
    void addEndRelayInMSG(int pIdMSG, time_t pTime, double pTimeSimulator,int pIdProcReceptor);
    char *generateInfoForText();
    char *generateInfoForTextWithClockSimulator();
    void addCountRetransmissionReceipt(int pIdMSG,int pIdProcReeptor, double pTimepTime);
    void addFaultyMessageInProcess(int pIdMSG, int pIdProcReceptor);
    void addMessageInListControlMessageFailed(int pIdMSG, int pIdProcSender, int pIdProcReceptor,
        int pBC, int pNumberDisseminadOnChannel);
    void processDataInListControlMessageFailed();

};

#endif /* SRC_VEINS_MODULES_APPLICATION_CAUSALBLOCKS_STATISTICALCONTROL_CONTROLSTATISTIC_H_ */
