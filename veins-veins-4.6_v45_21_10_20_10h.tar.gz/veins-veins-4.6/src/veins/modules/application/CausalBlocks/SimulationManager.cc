//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/SimulationManager.h>
#include "veins/modules/messages/WaveShortMessage_m.h"

using namespace std;

SimulationManager::SimulationManager() {
    // TODO Auto-generated constructor stub
    this->countMsgWithfailure = 0;;
    this->countMSGsTotalToSend = 0;
    this->countpercentageMsgWithfailure = 0;
    this->totalMsgToDisseminate = 0;
    this->countCar=0;
    this->isComplete = false;
    this->countMsgAlreadySent = 0;
    this->countMSGsByProcesso = 0;
    this->periodMSGSend =0;
    this->intervalSendMSGByProcess=0;
    this->countMsgToDisseminateWithfailure = 0;
    this->countMsgToDisseminate=0;
}

bool SimulationManager:: existsMsgInlistMsgWithfailure(int pIdMSg)
{   bool result = false;

    for(int i=0;i<listMsgWithfailure.size(); i++)
    {
        MessageBlock *msgAtual = dynamic_cast<MessageBlock*>(listMsgWithfailure[i]);
        if (msgAtual->getId() == pIdMSg)
       {
            result = true;
            break;
        }

    }


    return result;
}

void SimulationManager::printListRandomOfFailure()
{   char *result="";
    cout<<"\n   -Vetor(int) de falhas de disseminação";
    for(int i=0;i<listNumRandomOffailure.size(); i++)
    {
       cout<<listNumRandomOffailure[i]<<";";
    }

}


bool SimulationManager:: existsMsgInlistNumRandomOffailure(int pValue)
{   bool result = false;

    for(int i=0;i<listNumRandomOffailure.size(); i++)
    {
        if (pValue == listNumRandomOffailure[i])
       {
            result = true;
            cout<< "\n   @@@PesqRand in listValueFailure="<< pValue <<"Encontrado";
            break;
        }

    }


    return result;
}

bool exists(int vetor[], int tam, int valor)
    {
      for (int i=0; i<tam; i++)
      {
        if(vetor[i]==valor)
          return true;
      }
      return false;
    }


void  SimulationManager:: loadListRandomOfFailure()
{    bool continueRang= false;
     int numRand;
     bool isValidRange = false;
     int totalFailure=0;

    //totalMsgToDisseminate corresponde a numero de mensagens por carro* o número de canais (carros-1)
    this->totalMsgToDisseminate= this->countMSGsTotalToSend * (countCar -1) + 1;
    totalFailure = (this->totalMsgToDisseminate*countpercentageMsgWithfailure)/100;
    this->countMsgToDisseminateWithfailure = totalFailure;

    cout<<"\n   -Total MsgDisseminacao="<<countMsgToDisseminateWithfailure<<" total de Falhas"<<totalFailure
        <<totalFailure<< " Total MsgGeral="<<countMSGsTotalToSend;
     //Limpa o buffer para gerar números aleatórios diferentes
    srand((unsigned) time(NULL));

    cout<< "\n ====>>iteraçãoRandom (sucesso)"
        << "Total de Falhas a Disseminar= "<<totalFailure
        <<"CountMsg a disseminar="<<this->totalMsgToDisseminate;
    srand(time(NULL));
    for (int countFalha=0; countFalha< totalFailure; countFalha++)
    {
        numRand = 1+ rand() %(totalMsgToDisseminate);
       while(existsMsgInlistNumRandomOffailure(numRand))
       {
           numRand =  1 + rand() %(totalMsgToDisseminate/2);
       }
       listNumRandomOffailure.push_back(numRand);
       cout<< "   \n => i="<<countFalha<< " MSGFalha(NumAleatório)= "<<numRand;

    }

    /*

    for(int countFalha=0; countFalha< totalFailure; countFalha++)
    {
        continueRang = true;
        while(continueRang)
        {   continueRang = true;
            numero_randomico = 1+(rand() % (countMSGsTotalToSend));
            isValidRange =(numero_randomico > 0 && numero_randomico<=countMSGsTotalToSend);
            cout<< "\n       - random = "<< numero_randomico<<"isValidRange("<< isValidRange;
            cout    << "\n       -exists ="<<existsMsgInlistMsgWithfailure(numero_randomico);
            if (isValidRange)
            {
                if (!existsMsgInlistNumRandomOffailure(numero_randomico))
                {
                    continueRang = false;
                    break;
                }

            }
        }
        if ( (numero_randomico-1>=0) &&(numero_randomico-1 <listMsgBlock.size()))
        {
            listNumRandomOffailure.push_back(numero_randomico);
            //numero_randomico-1 listMsgWithfailure.push_back(listMsgBlock[numero_randomico-1]);
            cout<< "\n       - Vetor(in)= "<< numero_randomico;

        }

        cout<< "\n ====>>iteraçãoRandom (sucesso) = "<<countFalha<< " MSGFalha(NumAleatório)= "<<numero_randomico
            << "CountMsgFalhas Add=" <<listNumRandomOffailure.size() << "Total de Falhas a Disseminar= "<<totalFailure
            <<"CountMsg a disseminar="<<this->totalMsgToDisseminate;

    }

    */

}

void  SimulationManager:: LoadListMsgToSendOfApp(int pKind)
{   char* name;

    MessageBlock *msg = NULL;
    bool isValidRange = false;
    bool continueRang= false;
    int numero_randomico;
    this->isComplete = true;
    int numFalha=-1;
    this->countMsgWithfailure = (this->countMSGsTotalToSend *this->countpercentageMsgWithfailure)/100;
    cout<<"\n cria Lista com as mensagem simuladas para enviar total= "<< this->countMSGsTotalToSend
        <<" Falhas="<< this->countMsgWithfailure
        <<" Percentual="<< this->countpercentageMsgWithfailure;


    for(int i=0; i<this->countMSGsTotalToSend;i++)
    {
       name = "Msg";

       msg = new MessageBlock(name);
       msg->setId(i+1);
       msg->setKind(pKind);
       msg->setIsFailure(false);
       msg->setText(textMsgToSend);
       listMsgBlock.push_back(msg);
    }



    //Limpa o buffer para gerar números aleatórios diferentes
    srand((unsigned) time(NULL));
    //srand(countMSGsTotalToSend);

    for(int countFalha=0; countFalha< countMsgWithfailure; countFalha++)
    {
        continueRang = true;
        while(continueRang)
        {   continueRang = true;
            numero_randomico = 1+(rand() % (countMSGsTotalToSend));
            isValidRange =(numero_randomico > 0 && numero_randomico<=countMSGsTotalToSend);
            cout<< "\n       - random = "<< numero_randomico<<"isValidRange("<< isValidRange;
            cout    << "\n       -exists ="<<existsMsgInlistMsgWithfailure(numero_randomico);
            if (isValidRange)
            {  if (!existsMsgInlistMsgWithfailure(numero_randomico))
               {
                continueRang = false;
                break;
               }

            }
        }
        if ( (numero_randomico-1>=0) &&(numero_randomico-1 <listMsgBlock.size()))
        {
            MessageBlock *msgRand = dynamic_cast<MessageBlock*>(listMsgBlock[numero_randomico-1]);
            msgRand->setIsFailure(true);
            listMsgWithfailure.push_back(msgRand);
         //numero_randomico-1 listMsgWithfailure.push_back(listMsgBlock[numero_randomico-1]);
            cout<< "\n       - Adicionado a Lista random= "<< numero_randomico;

        }

        cout<< "\n ====>>iteração (sucesso) = "<<countFalha<< " MSGFalha(NumAleatório)= "<<numero_randomico
            << "CountMsgFalhas Add=" <<listMsgWithfailure.size();

    }
    //Gera um vetor com os códigos das falhas
    loadListRandomOfFailure();

}

MessageBlock* SimulationManager:: nextMsgToSend()
{  MessageBlock* msg = NULL;
   if (countMsgAlreadySent< listMsgBlock.size())
   {
       msg = dynamic_cast<MessageBlock*>(listMsgBlock[countMsgAlreadySent]);
       countMsgAlreadySent++;
   }
   return msg;
}

SimulationManager::~SimulationManager() {
    // TODO Auto-generated destructor stub
}

