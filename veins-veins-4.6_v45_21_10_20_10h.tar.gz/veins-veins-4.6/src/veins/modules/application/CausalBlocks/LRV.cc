//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <veins/modules/application/CausalBlocks/LRV.h>
#include <veins/modules/application/CausalBlocks/Block.h>
#include <veins/modules/application/CausalBlocks/Process.h>
#include<iostream>

using namespace std;

LRV::LRV() {
    // TODO Auto-generated constructor stub

}

void LRV::updateLRV(vector<Block*> plistBlocks, vector<Process*> plistProcess)
{ Block *blockLocate = NULL;
  Process * processLocate= NULL;
  MsgByProcess* msgLocate = NULL;
  int maxBloco=0;
  cout <<"\n---> Update LRV =";
  for (int indexP=0; indexP < plistProcess.size();indexP++)
  {   maxBloco=0;
      processLocate = dynamic_cast<Process*>(plistProcess[indexP]);
      for(int indexB=0; indexB<plistBlocks.size();indexB++)
      {
          blockLocate = dynamic_cast<Block*>(plistBlocks[indexB]);
          msgLocate = blockLocate->getMsg(processLocate->id);
          if (msgLocate!=NULL)
          {
             maxBloco = blockLocate->idBlockCount;
          }
      }
      listLRV_BC.push_back(maxBloco);
      cout<<maxBloco<<" ;";
  }

   maxValueInLRV = getMaxValue(listLRV_BC);
   cout<<" Max= "<< maxValueInLRV;
   minValueInLRV = getMinValue(listLRV_BC);
   cout<<" Min= "<< minValueInLRV;


}

int LRV::getMinValue(vector<int> pVetor)
{ int  minValue= 100000;
  for(int i=0;i< pVetor.size();i++)
  {
    if (minValue >pVetor[i])
    {  minValue = pVetor[i];}


  }
  return minValue;
}

int LRV::getMaxValue(vector<int> pVetor)
{ int  maxValue= -1;
  for(int i=0;i< pVetor.size();i++)
  {
    if (maxValue< pVetor[i])
    {  maxValue = pVetor[i];}


  }
  return maxValue;
}



LRV::~LRV() {
    // TODO Auto-generated destructor stub
}

