//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __VEINS_CAUSALBLOCKS_H_
#define __VEINS_CAUSALBLOCKS_H_

#include <omnetpp.h>
#include <veins/modules/application/CausalBlocks/ManagerBlocks.h>
#include "veins/modules/application/ieee80211p/BaseWaveApplLayer.h"
#include "veins/modules/application/CausalBlocks/Message/MessageBlock_m.h"
#include "veins/modules/application/CausalBlocks/Message/MessageBeaconCausalBlock_m.h"
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlStatistic.h>
#include <veins/modules/application/CausalBlocks/SimulationManager.h>
#include <veins/modules/application/CausalBlocks/ManagerBlocksWithAbsentMSGRelay.h>
#include <time.h>

using namespace omnetpp;

/**
 * TODO - Generated class
 */
class CausalBlocks : public BaseWaveApplLayer
{
public:
  enum WaveApplMessageKinds {
    SHEDULE_SEND_MSG_BLOCK = 2,
    SEND_MSG_BLOCK,
    RECEIVE_MSG_BLOCK,
    SEND_MSG_BLOCK_REQUEST,
    SEND_MSG_BLOCK_REPLY,
    TIME_SILENCE,
    SEND_NULL,
    SHEDULE_SEND_MSG_BLOCK_REQUEST,
    SHEDULE_SEND_MSG,
    SHEDULE_START_COMUNICATION,
    SHEDULE_TIME_SILENCE_PERIODIC,
    SHEDULE_SEND_NULL,
    SCHEDULE_SEND_BEACON_EVT
  };

  enum EventBCUpdateMaxBloco {
      EVENT_DELIVERY = 1,
      EVENT_RECEIVE
    };

  virtual void receiveSignal(cComponent* source, simsignal_t signalID, cObject* obj, cObject* details);

  protected:
    cMessage* scheduleSendBeaconEvt;
    simtime_t lastDroveAt;
    uint32_t generatedBeacons;
    uint32_t receivedBeacons;
    int BCUpdateMaxBloco;
    bool startSentMessage = false;
    int currentSubscribedServiceId;
    int id;
    int idProcesso;
    int totalProcesso=0;
    int timesilence;
    int timesilencePeriodoIncrement;
    int countMsgAlreadySend=0;
    int countScheduledMSGByProcess = 0;
    double periodTranmission;
    double periodBeacon;
    int numMSGsByProcesso;
    int sizeMSGsByProcesso;
    int numMSGsTotalToSend;
    int numTotalRelay;
    int countMsgWithfailure;
    int countpercentageMsgWithfailure;
    int countMsgReceived = 0;
    bool deliveryRobustProtocol = true;
    double timeSilencePeriodicOfApllication;
    double timeSheduleProcessRequestRelay;
    Process *processResearchedWithFaulty= NULL;
    MLDV *MLDVFind= NULL;
    MLDVWithFaulty *MLDVFindWithFaulty= NULL;
    char* text;
    ManagerBlocksWithAbsentMSGRelay *listCausalBlocks;
    bool insertFailsByInterference =false;
    vector<MessageBlock*> listEvents;
    vector<MessageBlock*> listReplay;
    bool deliveryByBlockComplete = false;
  protected:
    virtual void initialize();
    virtual void initialize(int stage);
    virtual void finish();

    virtual void handleMessage(cMessage *msg);
    virtual void onWSM(WaveShortMessage* wsm);
    virtual void onBSM(BasicSafetyMessage* bsm);
    virtual void onWSA(WaveServiceAdvertisment* wsa);
    virtual void handleSelfMsg(cMessage* msg);
    virtual void loadApp(cMessage *msg);
    virtual void handleLowerMsg(cMessage* msg);
    /** @brief this function is called every time the vehicle receives a position update signal */
    virtual void handlePositionUpdate(cObject* obj);

    /** @brief this function is called every time the vehicle parks or starts moving again */

    void sendMsgBeaconApp(cMessage* msg);
    void receiveMsgBeaconApp(cMessage* msg);
    void sendMsgApplWithCausalBlocks(cMessage *msg, unsigned int pMsgType);
    void receiveMsgApplWithCausalBlocks(cMessage *msg, unsigned int pMsgType);
    MessageBlock* addEventTimeSilence(Block* pBlock, int pTime);
    void processesseTimeSilence(cMessage *msg);
    void sendMsgNULL(cMessage *msg);
    bool isMessageLocal(MessageBlock* msg);
    void updateMaxBC(int pReceiveValue, int pCurrentvalue);
    int getNewIdMSG();
    void send( MessageBlock * pacoteMsgBlockAEnviar);
    bool* existsMsgInListReply(int pIdBlock, int pIdProcess, int pKind);
    ControlStatistic *getControlStatistic();
    MessageBlock *createPackageToSend(MsgByProcess *pMSGFromProcess, char *pNameMSG, unsigned int pMsgType,
       int pNumTotalOfMSg, int pIdProcessoRemetente, int pIdProcessReplay);
    MessageBlock *createPackageToSend(MessageBlock* pMsgSchedule,unsigned int pMsgType);
    time_t getCurrentTime();
    void InicializeParameters();
    void resetEventTimeSilence(Block* pBlock, int pTime);
    void scheduleEventsBlocksApp(simtime_t pTime, MessageBlock *pMsg);
    MessageBlock* getMsgEventBlock(Block* pBlock, int pKind);
    int getIndexMsgEventBlock(Block* pBlock, int pKind);
    int getIndexMsgEventTimeOutMessage(int pIdProcesso, int pIdMessage, int pKind);
    int getIndexMsgEventTimeOutPreviousMsg(int pIdProcesso, int pIdMessage,int pIdBlock,  int pKind);
    SimulationManager * getSimulationManager();
    void scheduleMsgToSendOfApp();
    int getCountProcess();
    int incrementProcesss();
    void processRelay();
    void processesRequestRelay(cMessage *msg);
    void scheduleProcessRequestRelay(cMessage *msg,MsgByProcess *pMsg, double pTimeOut);
    MessageBlock* getMsgEventBlock(int pIdBlock, int pIdProcesso,int pKind);
    bool cancelEventSheduleofRelay(int pIdBlock, int pIdProcess, int pKind);
    void StartComunicationSchedule();
    void managerDeliveryaAllBlocksInControlesStatistic(char *pNameFunction);
    bool isMsgFailureRandom(MessageBlock * pPacoteMSGRecebida, unsigned int pMsgType);
    void printDateOfMsgReceived(MessageBlock * pPacoteMSGRecebida);
    void managerCountDisseminatiosOfChannel( MessageBlock * pPacoteMSGRecebida, unsigned int pMsgType);
    void cancelTimeOutScheduleProcessMessageRetransmission(int pIdProcessoSender, int pIdMessage,int pIdBlock,  int pKind);
    void scheduleTimeSilencePeriodic(double pTime);
    void messageRecovery();
    void processTimeSilencePeriodic(cMessage *msg);
    void receiveMsgNULLWithCausalBlocks(cMessage *msg, unsigned int pMsgType);
    bool relayConditionIsValid(int pBlockCount, int pIdProcessFind,int pIdProcMarkedAsReceived, int pIdMesg);
    bool relayConditionIsValid(MLDV* pCurrentMLDVI, int pBlockCount, int pIdProcessoSender);
    bool isMsgLocal(MsgByProcess *pMsg);
    void insertLDViInPacoteMsgBlock(vector<int> LDVi, MessageBlock * pacoteMsgBlock);
    void insertLDViInBeacon(vector<int> LDVi, MessageBeaconCausalBlock * pMsgBeacon);
    Block *managerDeliveryBlocksInControlesStatistic(char *pNameFunction, Block *pBlock, MessageBlock * pPacoteMSGRecebida);
    vector<int> getLDViInPacoteMsgBlock(vector<int> LDVi, MessageBlock * pacoteMsgBlock, int pKindVector);
    vector<int> getVectorInBeacon(vector<int> pVector, MessageBeaconCausalBlock * pMsgBeacon, int pKindVector);
    void deliveryWithRobustProtocol(MsgByProcess *pMsg, bool isReplay, int pIdBlockCount,Process *pProcSender, vector<int>pLdv,
         MLDV* pNewMLDV, bool pIsPrintLDVI, double pTimeDelivery, double pTimeDeliverySimulator);
    void updateMLDVByBlockCount(int pIdProcessSender, int pIdBlockCount);
    void printMLDViAllProcess();
    bool lvdReceiveIsLastLdvReceived(vector<int> pLdvi, int pIdProcess);
    void updateMLDVByBlockCountOfLDVi(vector<int> pLdv, Process* pIdProcSender);
    MessageBlock* addMsgWithCausalBlocks(cMessage *msg, unsigned int pMsgType);
    simtime_t computeAsynchronousSendingTime(simtime_t interval, t_channel chan);
    void findAndUpdateLDVInMLDVWithFaulty(int pIdProcessoSender, vector <int> pLDVi, int pBlockCount, int pIdMsg);
    bool existslEventSheduleOfRelay(int pIdMessage,int pIdBlock, int pIdProcessSender);
    void insertLDVRecoverdMessagesInBeacon(vector<int> pLDVRecoveredMessages, MessageBeaconCausalBlock * pMsgBeacon);
    void insertLDVRecoverdMessagesInPackage(vector<int> pLDVRecoveredMessages, MessageBlock * pacoteMsgBlock);
    void deliveryAllMsgWithRobustProtocol(double pTimeDelivery, double pTimeDeliverySimulator);


};

#endif
