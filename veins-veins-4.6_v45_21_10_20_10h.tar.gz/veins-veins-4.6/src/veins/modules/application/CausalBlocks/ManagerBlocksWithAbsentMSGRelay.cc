//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 


#include <veins/modules/application/CausalBlocks/ManagerBlocksWithAbsentMSGRelay.h>
#include <veins/modules/application/CausalBlocks/Block.h>
#include <iostream>
#include <string.h>
using namespace std;

ManagerBlocksWithAbsentMSGRelay::ManagerBlocksWithAbsentMSGRelay(int pIdProcessLocal, int pProcessCount) {
    // TODO Auto-generated constructor stub
    this->processCount= pProcessCount;
    this->blockCount=0;
    this->idProcessLocal=pIdProcessLocal;
    this->LRV_ = new LRV();
    this->relayMsg = false;
    this->countMsgAbsents = 0;
    this->countMsgRecovered =0;
    createLDVi();
    createMBVi();
    createLDViRecoveredMessages();
}


MLDV* ManagerBlocksWithAbsentMSGRelay:: createMLDVi(Process *pProcess, bool pInsertInList)
{
    MLDV* MLDVCurrente= new MLDV();

    if(pProcess !=NULL && (pInsertInList ==true))
    {

        pProcess->MLDVi.push_back(MLDVCurrente);
    }
    return MLDVCurrente;
}

void ManagerBlocksWithAbsentMSGRelay:: printMLDVi(Process *pProcess)
{
   cout<< "\n --->MLDVi do Processo="<<pProcess->id;
   for(int i=0;i< pProcess->MLDVi.size();i++)
   {
      cout<< " \n   -MLDVI ("<<i<<")BC="<<pProcess->MLDVi[i]->idBlockCount<<"\n";
      //imprime o LDVi corrente
      for(int k=0;k< pProcess->MLDVi[i]->LDVi.size();k++)
      {
          cout<< "["<<k<<"]="<<pProcess->MLDVi[i]->LDVi[k]<<"  ";
      }
      cout<<"\n";
   }


}


int ManagerBlocksWithAbsentMSGRelay:: getPosVectorOfBlock(Block *pBlock)
{  Block * blockCurrent= NULL;
   int result = -1;
   for(int i=0; i< listBlocks.size();i++)
   {   blockCurrent = dynamic_cast<Block*>(listBlocks[i]);
       if (blockCurrent->idBlockCount == pBlock->idBlockCount)
       {
          result = i;
          break;
       }
   }
   return result;

}

Block* ManagerBlocksWithAbsentMSGRelay:: getPreviousBlock(
  Block *pBlock)
{  Block * blockPrevious= NULL;
   Block *result = NULL;
   Block * blockCurrent= NULL;
   int posBlockCurrent = -1;

   posBlockCurrent= getPosVectorOfBlock(pBlock);
   if (posBlockCurrent>0)
   {
       blockPrevious = dynamic_cast<Block*>(listBlocks[posBlockCurrent-1]);
       if (blockPrevious->idBlockCount == (pBlock->idBlockCount-1))
       {
           result = blockPrevious;
       }
   }
   return blockPrevious;
}

bool ManagerBlocksWithAbsentMSGRelay::existsMsgOfProcessInBlock(Block *pBlock, int pIDProcess)
{
    MsgByProcess* msg= NULL;
    bool result = false;
    msg= pBlock->getMsg(pIDProcess);
    if (msg!=NULL)
    { result =true; }

    return  result;
}

void ManagerBlocksWithAbsentMSGRelay::processaRelay(MsgByProcess *pMsg, Block *pBlock)
{
    MsgByProcess *msgReplay= new MsgByProcess();

    pMsg->countRelay++;
    msgReplay->kind = SEND_MSG_BLOCK_REQUEST;
    msgReplay->idRemetente = pMsg->idProcess;
    msgReplay->idProcess = pMsg->idProcess;
    msgReplay->idBC=  pMsg->idBC;
    listMsgAbsent.push_back(msgReplay);


}

bool ManagerBlocksWithAbsentMSGRelay:: isSequentialBlock(Block* pBlock, Block* pBlockPrevious)
{
   if ( pBlock != NULL && ( pBlockPrevious != NULL) && (pBlockPrevious->idBlockCount!= (pBlock->idBlockCount -1)))
     return  true;
   else
     return  false;

}

MsgByProcess* ManagerBlocksWithAbsentMSGRelay:: MarkBlockPerMsgPerProcess(int pIdMsgRemetente,char* pText, int pIdBCRemetente, int pIdProcess,
        Block* pBloco, time_t timeReceive, double timeReceiveSimulator,bool pIsUpdateMAxBCInEventReceive, bool pDeliveryBlockComplete, bool pPrintBlockDelivery)
{   MsgByProcess* result = NULL;
    Block * blockPrevious= NULL;
    MsgByProcess* msg= NULL;
    MsgByProcess* msgPrevious= NULL;

    if ((!pBloco->getIsComplete()) &&(!pBloco->getIsDelivery()))
    {
      //Rotina para tratar as mensagens anteriores não recebidas


      //rotina para tratar as mensagens recebidas

      msg=findOrAddNewMSG(pIdMsgRemetente, pText, "+",pIdBCRemetente,pIdProcess, pBloco);
      if (msg!=NULL)
      {
          if(msg->status=="-")
            this->countMsgRecovered++;
          msg->id = pIdMsgRemetente;
          msg->status="+";
          msg->timeReceive=timeReceive;
          msg->text = pText;
         //Gerencia o Delivery das Mensagens

         if (pDeliveryBlockComplete)
         {
            // ManagerCheckblockComplete(pBloco, msg,,pPrintBlockDelivery);
            checkBlockComplete(pBloco, true, timeReceiveSimulator,true);

            //Após verificar a completude dopDeliveryBlockComplete bloco atual, o protocolo tb verifica os demais blocos da base.
            //porque pode existir blocos maiores que não foram completados porque dependiam de mensagens anteriores
            checkAllBlocksCompletes(true,timeReceiveSimulator, true);

            //Altera o BlockCount(BC) para o maior valor entre o recebido e o atual da base
           if (pIsUpdateMAxBCInEventReceive==true)
           {
              updateMaxBC(getBlockCount(),pIdBCRemetente);
           }

         }
         result = msg;

      }
    }
    return result;
}


void ManagerBlocksWithAbsentMSGRelay:: checkAllBlocksCompletes(bool pIsDelivery,
   double pTimeDeliverySimluador,
   bool updateMaxBlocoInDelivery)
{
  // cout<<"\n\n\n   =>------Verificando se  todos os Blocos estão completos checagem de todos os blocos---------------<=";
   Block* block = NULL;
   for (int i=0;i<listBlocks.size();i++)
   {
      block = dynamic_cast<Block*>(listBlocks[i]);
      if (!block->isComplete)
      {
          checkBlockComplete(block, pIsDelivery, pTimeDeliverySimluador, updateMaxBlocoInDelivery);
      }
   }

 //  cout<<"\n   =>-----------------------------------------------------------------------------------------------<=";

}

bool ManagerBlocksWithAbsentMSGRelay:: checkBlockComplete(Block* pBlock, bool pIsDelivery,
   double pTimeDeliverySimluador,
   bool updateMaxBlocoInDelivery)
{  int contMsgSucess=0;
   Block * blockPrevious= NULL;
   MsgByProcess* msg= NULL;
   MsgByProcess* msgPrevious= NULL;
   bool existsMsgAbsent=false;
   bool existsMsgAbsentInBlockPrevious=false;

  //  cout<< "\n\n   --->Verificando a completude do bloco(IDBC="<<pBlock->idBlockCount<<") numMSG="<<pBlock->ListMsgByProcess.size()
  //      << " TotalAReceber= "<<processCount;
    pBlock->isComplete =false;
    LRV_->updateLRV(listBlocks, listProcess);

    blockPrevious= getPreviousBlock(pBlock);


    for (int i=0;i<pBlock->ListMsgByProcess.size();i++)
    {
       msg = dynamic_cast<MsgByProcess*>(pBlock->ListMsgByProcess[i]);

       if(blockPrevious != NULL)
       {
           msgPrevious = blockPrevious->getMsg(msg->idRemetente);

         //Verifica se a msg do BlocoAnterior possui msg Ausente
         if ( (msgPrevious!=NULL) && (!blockPrevious->isDelivery)  && (strcmp(msgPrevious->status,"-")==0))
         {
           existsMsgAbsentInBlockPrevious =true;
         }
       }

       if ((!pBlock->isDelivery))
       {
          //Verifica se o Bloco Atual possui mensagem Ausente
          if((strcmp(msg->status,"-")==0) || (strcmp(msg->status,"")==0))
          {
             existsMsgAbsent =true;
          }
          else
            contMsgSucess++;

       }


      /* if (strcmp(msg->status,"+")==0 && (blockPrevious==NULL))
       {
           contMsgSucess++;
       }

       if((blockPrevious!=NULL) &&(msgPrevious!=NULL) && (strcmp(msgPrevious->status,"+")))
       {
          contMsgSucess++;
       }
       if ((blockPrevious!=NULL) &&(msgPrevious!=NULL) && (strcmp(msgPrevious->status,"-"))
         || (strcmp(msg->status,"-")==0))
         existsMsgAbsent =true;
      */
    }


    if (!existsMsgAbsent && !existsMsgAbsentInBlockPrevious && (contMsgSucess ==processCount))
    { pBlock->isComplete=true;
  //    cout<< "\n   --->Completo=True"<< "Total de MsgProcessadas ="<<contMsgSucess <<"Msg ausente="<<existsMsgAbsent
   //     <<" Msg ausente (BlocoAnterior)="<<existsMsgAbsentInBlockPrevious
    //    << "Block Delivery="<< pBlock->isDelivery;

      if (pIsDelivery==true)
      {
        deliveryBlock(pBlock->idBlockCount, pTimeDeliverySimluador, updateMaxBlocoInDelivery, false);
      }
    }
    else {
//      cout<< "\n   --->Completo=False"<< "Total de MsgProcessadas ="<<contMsgSucess <<" Existe Msg ausente?="<<existsMsgAbsent
  //        <<" Existe Msg ausente (BlocoAnterior)="<<existsMsgAbsentInBlockPrevious
  //      << "Block Delivery="<< pBlock->isDelivery;
      pBlock->isComplete=false;
      cout<<" \n   --->Mensagens do Bloco Anterior";
      if (blockPrevious!=NULL)
      {    //blockPrevious->printMsgs();

      }


    }

    return pBlock->isComplete;
}


void ManagerBlocksWithAbsentMSGRelay:: createLDViRecoveredMessages()
{
   if(this->LDViRecoveredMessages.size()==0)
   {
       for(int i=0;i<processCount;i++)
       { LDViRecoveredMessages.push_back(i);
         updateLDViRecoveredMessages(i, 0);
       }
   }
}

void ManagerBlocksWithAbsentMSGRelay:: createLDVi()
{
   if(this->LDVi.size()==0)
   {
       for(int i=0;i<processCount;i++)
       { LDVi.push_back(i);
         updateLDV(i, 0);
       }
   }
}

vector<int> ManagerBlocksWithAbsentMSGRelay:: createLDVi(bool pInitializeProcess)
{  vector<int> newLDVi;

       for(int i=0;i<processCount;i++)
       { newLDVi.push_back(i);
         newLDVi[newLDVi.size()-1] = 0;
       }

   return newLDVi;
}

void ManagerBlocksWithAbsentMSGRelay:: createMBVi()
{
    MBV* currentMBV = NULL;
    for(int i=0; i < this->processCount;i++)
    {
        currentMBV = new MBV();
        currentMBV->maxBlockCount=0;
        currentMBV->idProcesso= i;
        this->MBVi.push_back(currentMBV);
    }

}

MLDV* ManagerBlocksWithAbsentMSGRelay::findMLDVByBlock(int pBlockCount, int pProcessSender)
{   MLDV * currentMLDV = NULL;
    vector<MLDV*> listMLDV;

    Process *processSender = getProcess(pProcessSender);
    for (int i=0;i < processSender->MLDVi.size();i++)
    {
        if(processSender->MLDVi[i]->idBlockCount==pBlockCount)
        {  currentMLDV = dynamic_cast<MLDV*>(processSender->MLDVi[i]);
           break;
        }
    }
    return currentMLDV;


}


MLDV* ManagerBlocksWithAbsentMSGRelay:: addLDVInMLDV(vector <int> pLdvi, int pIdProcesso,
  int pIdBlockCount, bool pInsetNewItem, bool pUpdateMLDVOldWithSameBlockCount)
{  MLDV * currentMLDV = NULL;
   MLDV * MLDVByProcess = NULL;
   Process *proc = getProcess(pIdProcesso);

  if (pLdvi.size() >=0 )
  {
     currentMLDV = getMLDViByBlockCount(pIdProcesso, pIdBlockCount);
     if(currentMLDV == NULL || pInsetNewItem)
     {
         currentMLDV = createMLDVi(proc, true);
         currentMLDV->idBlockCount=pIdBlockCount;
     }
     if(currentMLDV !=NULL)
     {
       for(int i=0; i<pLdvi.size(); i++)
       {
          currentMLDV->LDVi.push_back(pLdvi[i]);
          MLDVByProcess= findMLDVByBlock(pIdBlockCount,pIdProcesso);
          if (pUpdateMLDVOldWithSameBlockCount && (MLDVByProcess!=NULL))
          {
              if (MLDVByProcess->LDVi[i]<pLdvi[i])
                  MLDVByProcess->LDVi[i]= pLdvi[i];

          }
       }
     }

  }

  return currentMLDV;


}





MLDV* ManagerBlocksWithAbsentMSGRelay:: addLDVInMLDV(int pLdvi, int pIdProcesso,
  int pIdBlockCount, bool pInsetNewItem)
{  MLDV * currentMLDV = NULL;
   vector<int> newLDVi;
   Process *proc = getProcess(pIdProcesso);


   if (pLdvi >=0 )
   {
      currentMLDV = getMLDViByBlockCount(pIdProcesso, pIdBlockCount);
      if(currentMLDV == NULL || pInsetNewItem)
      {
          currentMLDV = createMLDVi(proc, true);
          newLDVi = createLDVi(true);
          currentMLDV->LDVi= newLDVi;
          currentMLDV->idBlockCount=pIdBlockCount;

      }

      if (pIdProcesso<currentMLDV->LDVi.size())
        currentMLDV->LDVi[pIdProcesso] = pLdvi;

    }

   return currentMLDV;


}



vector<MLDV*> ManagerBlocksWithAbsentMSGRelay:: filterLDVIiInMLDV(vector<MLDV*> pMLDVi, int pIdProcesso)
{

   vector<MLDV*> listaLDVI;
  /*  int* currentLDV;

    MLDV* currentMLDVi;

    int result=0;

    for(int i=0; i< pMLDVi.size();i++)
       {   currentMLDVi = dynamic_cast<MLDV*>(pMLDVi[i]);
           if (currentMLDVi->idProcesso == pIdProcesso)
           {
               listaLDVI.push_back(currentMLDVi);
           }
       } */
   return listaLDVI;
}


void ManagerBlocksWithAbsentMSGRelay:: updateLDV(int pIdProcesso, int pValue)
{
   LDVi[pIdProcesso] = pValue;

}

void ManagerBlocksWithAbsentMSGRelay:: updateLDViRecoveredMessages(int pIdProcesso, int pValue)
{
    LDViRecoveredMessages[pIdProcesso] = pValue;

}




void ManagerBlocksWithAbsentMSGRelay:: updateMBVi(int pIdProcesso, int pValue)
{
    MBV* currentMBV;
    int minValueMBVOld=getMinValueMBV();
    int minValueMBVNew;

    for(int i=0; i< MBVi.size();i++)
    {   currentMBV = dynamic_cast<MBV*>(MBVi[i]);
        if (currentMBV->idProcesso == pIdProcesso)
        {
            currentMBV->maxBlockCount = pValue;
            minValueMBVNew=getMinValueMBV();
            if (minValueMBVNew != minValueMBVOld )
              isChangeMinMBVi= true;
        }
    }
}

Process * ManagerBlocksWithAbsentMSGRelay::getProcess(int pIdProcess)
{
   Process* processCurrent=NULL;
   processCurrent = listProcess[pIdProcess];
   return processCurrent;
}

MLDV* ManagerBlocksWithAbsentMSGRelay::getCurrentMLDVi(int pIdProcesso)
{  Process *procCurrent = NULL;
   MLDV* MLDVCurrent = NULL;
   procCurrent = listProcess[pIdProcesso];
   int tam=0;
   if(procCurrent !=NULL)
   {  tam = procCurrent->MLDVi.size();
       if (tam!=0)
         MLDVCurrent= procCurrent->MLDVi[tam-1];
   }

   return MLDVCurrent;


}


MLDV* ManagerBlocksWithAbsentMSGRelay::getMLDViByBlockCount(int pIdProcesso, int pBlockCount)
{  Process *procCurrent = NULL;
   MLDV* MLDVCurrent = NULL;
   procCurrent = listProcess[pIdProcesso];
      int tam=0;
   for(int i=0; i<procCurrent->MLDVi.size();i++)
   {
       if(procCurrent->MLDVi[i]->idBlockCount ==pBlockCount)
       {   MLDVCurrent = procCurrent->MLDVi[i];
           return MLDVCurrent;
           break;
       }

   }
   return MLDVCurrent;


}
int ManagerBlocksWithAbsentMSGRelay::getMinValueMBV()
{ int  minValue= 0;
  for(int i=0;i< MBVi.size();i++)
  {
      if (i==0)
      {
          minValue= MBVi[i]->maxBlockCount;
      }

      if (minValue > MBVi[i]->maxBlockCount)
      {  minValue = MBVi[i]->maxBlockCount;}


  }
  return minValue;
}

int ManagerBlocksWithAbsentMSGRelay:: getCurrentLDVi(){
int value = 0;
    if(this->LDVi.size()>0 )
    {
       value=  LDVi[idProcessLocal];
    }
  return value;
}

int ManagerBlocksWithAbsentMSGRelay:: getMaxBlockCountByProcess(int pIdProcess)
{   int result = 0;
    LRV_->updateLRV(listBlocks, listProcess);
    if (LRV_->listLRV_BC.size()>0)
    {
        result =LRV_->listLRV_BC[pIdProcess];
    }
    return result;
}

vector<int>  ManagerBlocksWithAbsentMSGRelay:: createNewVector(int pTam, int pValue)
{
   vector<int> newlistProcess;
  for (int i=0;i<pTam;i++)
  {
      newlistProcess.push_back(pValue);


  }

  return newlistProcess;

}

int ManagerBlocksWithAbsentMSGRelay::getValueLDVByPositionInMLDVi(int pPos,
   int pIdProcessSender)
{
  MLDV *MLDVCurrent;
  vector<int> LDVCurrent;
  Process *proc = getProcess(this->idProcessLocal);
  int value=0;
  MLDVCurrent = proc->MLDVi[pPos];
  if(MLDVCurrent!=NULL && (pIdProcessSender< MLDVCurrent->LDVi.size()))
  {
     value= proc->MLDVi[pPos]->LDVi[pIdProcessSender];
  }
  return value;

}

int ManagerBlocksWithAbsentMSGRelay::getValueLDVInMLDVi(MLDV *pCurrentMLDV,int pIdProcess)
{
  int valueReturn = 0;
  if (pCurrentMLDV!=NULL)
  {
    if (pCurrentMLDV->LDVi.size()>pIdProcess)
    {
        valueReturn = pCurrentMLDV->LDVi[pIdProcess];
    }
  }
  return valueReturn;
}


ManagerBlocksWithAbsentMSGRelay::~ManagerBlocksWithAbsentMSGRelay() {
    // TODO Auto-generated destructor stub
}

