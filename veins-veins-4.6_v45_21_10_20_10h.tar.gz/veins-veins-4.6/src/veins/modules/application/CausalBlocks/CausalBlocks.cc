//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 
#include <veins/modules/application/CausalBlocks/StatisticalControl/ControlStatistic.h>
#include "CausalBlocks.h"
#include "CausalBlocks.h"
#include <veins/modules/application/CausalBlocks/SimulationManager.h>
#include <veins/modules/application/CausalBlocks/ManagerBlocksWithAbsentMSGRelay.h>
#include <time.h>


using namespace std;
#define EXCECAO  1001

//const simsignalwrap_t BaseWaveApplLayer::mobilityStateChangedSignal = simsignalwrap_t(MIXIM_SIGNAL_MOBILITY_CHANGE_NAME);
//const simsignalwrap_t BaseWaveApplLayer::parkingStateChangedSignal = simsignalwrap_t(TRACI_SIGNAL_PARKING_CHANGE_NAME);


Define_Module(CausalBlocks);


void CausalBlocks::initialize()
{  // long int tempoAtual=simTime();
    EV<<"\n\n\n Teste EV initialize nome" << getName()<<"\n\n\n";
    this->timesilence = 50;
    //scheduleAt(simTime(), new cMessage);
}

void CausalBlocks::finish()
{  char * nameFunction = "finish";

   if( this->idProcesso < this->totalProcesso)
   {
     cout<<"\nSimulação Concluída! QtdMensagens=" <<getControlStatistic()->listMSGSender.size();
     //getControlStatistic()->generateInfoForText();

     //Armazena os dados do Fechamento de Bloco
     managerDeliveryaAllBlocksInControlesStatistic(nameFunction);

     cout<< "\n\n-----> Numero de Beacons Transmitidos="<< generatedBeacons;
     cout<< "\n\n-----> Numero de Beacons recebidos="<< receivedBeacons;

     getControlStatistic()->generatedBeacons = this->generatedBeacons;
     getControlStatistic()->receivedBeacons = this->receivedBeacons;
     getControlStatistic()->countCar =  this->totalProcesso;
     getControlStatistic()->countMSG= this->numMSGsTotalToSend;
     getControlStatistic()->countMSGByCar = this->numMSGsByProcesso;
     getControlStatistic()->periodBecon =getSimulationManager()->intervalBeacon;
     getControlStatistic()->numTotalRelay =this->numTotalRelay;

     getControlStatistic()->generateInfoForTextWithClockSimulator();



   }

}

void CausalBlocks::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
    getDisplayString().setTagArg("id", 0, idProcesso);
    if( this->idProcesso < this->totalProcesso)
    {

        if (msg->getKind()==SHEDULE_START_COMUNICATION)
        {
            scheduleMsgToSendOfApp();
        }
        if (msg->getKind()==SHEDULE_SEND_MSG)
        {
           //Agenda as próximas mensagens para enviar
           scheduleMsgToSendOfApp();

        }
        if(msg->getKind()==SHEDULE_TIME_SILENCE_PERIODIC)
        {
         //  processTimeSilencePeriodic(msg);
           cout<< "processTimeSilencePeriodic";

        }
        if (msg->getKind()==SHEDULE_SEND_MSG_BLOCK)
        {
            //Envia as mensagens agendadas
            cout<< "\nEvento que realiza o envio das mensagens (HandleMessage)";
            sendMsgApplWithCausalBlocks(msg, SEND_MSG_BLOCK);
        }
        else if (msg->getKind()==SEND_MSG_BLOCK)
        {
            //Processa as mensagens recebidas através da rede
            cout<<"\n\n Recebendo msg ProcLocal="<< this->idProcesso;
            receiveMsgApplWithCausalBlocks(msg, RECEIVE_MSG_BLOCK);
        }
        else if(msg->getKind()==SEND_MSG_BLOCK_REPLY)
        {
            cout << "\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\nRecebendo um Replay";
            receiveMsgApplWithCausalBlocks(msg, SEND_MSG_BLOCK_REPLY);
        }
        else if(msg->getKind()==SEND_NULL)
        {
           cout << "\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\nRecebendo uma MSG NULL";
           receiveMsgNULLWithCausalBlocks(msg, SEND_NULL);
        }
        else if(msg->getKind()==SHEDULE_SEND_NULL){
          cout<<"\n Processando o agendamento do SenNULL";
         // sendMsgNULL(msg);
        }
        else if (msg->getKind()==TIME_SILENCE)
        {
            //Envia as mensagens agendadas
           // processesseTimeSilence(msg);
            //cout<< "\nEvento de processamento do TimeSilence";

        }
        else if(msg->getKind()==SEND_MSG_BLOCK_REQUEST)
        {
            cout<< "\nEvento de processamento do SEND_MSG_BLOCK_REQUEST";
            //processesRequestRelay(msg);
            scheduleProcessRequestRelay(msg,NULL, 0);
        } else if(msg->getKind()==SHEDULE_SEND_MSG_BLOCK_REQUEST)
        {
          processesRequestRelay(msg);
        }
        else if (msg->getKind()==SCHEDULE_SEND_BEACON_EVT)
        {
            //cout<< "\nteste Beacon  ProcAtual= "<< this->idProcesso <<" ProcSender="<< bsm->getSenderAddress() ;
            cout<< "\nEvento ="<< msg->getName();
            sendMsgBeaconApp(msg);
            cancelEvent(scheduleSendBeaconEvt);
            scheduleAt(simTime() + beaconInterval, scheduleSendBeaconEvt);
        }
        else if (msg->getKind()==SEND_BEACON_EVT)
        {
            //cout<< "\nteste Beacon  ProcAtual= "<< this->idProcesso <<" ProcSender="<< bsm->getSenderAddress() ;
            cout<< "\nEvento ="<< msg->getName();
            if (MessageBeaconCausalBlock* msgBeacon = dynamic_cast<MessageBeaconCausalBlock*>(msg))
            {

              receiveMsgBeaconApp(msg);
            }
        }
    }
}


int getCountProcess()
{
  static int countProcess = -1;
  return countProcess;
}

int incrementProcess()
{
    static int coutProcess;
    return coutProcess++;
}

void CausalBlocks:: initialize(int stage){
    BaseWaveApplLayer::initialize(stage);
    time_t rawtime = getCurrentTime();
    double timeStartSendBeacon = 0;
    if (stage==0)
    {
      cout<<"\n Teste(stage 0) initialize nome" << getName() << " id="<< idProcesso;
      EV<<"\n\n\n\n  Teste(stage) initialize nome" << getName()<< " id="<< idProcesso<<"\n\n\n";
      //Todos os Carros terão ,,inicialmente, processo igual a -1 até entrarem na estrutura de Blocos Causais
      //Configuração dos parametros da Aplicação
      //initialize pointers to other modules
      if (FindModule<TraCIMobility*>::findSubModule(getParentModule())) {
         mobility = TraCIMobilityAccess().get(getParentModule());
         traci = mobility->getCommandInterface();
         traciVehicle = mobility->getVehicleCommandInterface();
      }
      else {
         traci = NULL;
         mobility = NULL;
         traciVehicle = NULL;
      }

      annotations = AnnotationManagerAccess().getIfExists();
      ASSERT(annotations);

      mac = FindModule<WaveAppToMac1609_4Interface*>::findSubModule(
                     getParentModule());
      assert(mac);

      myId = getParentModule()->getId();
      InicializeParameters();


    }if (stage==1)
    {
        // cout<<"\n Teste(stage1) initialize Carro" << getName();
        // cout<<"\n => Cod Veiculo no Causal Blocks" << getName()
        //     << " idProcesso="<< this->idProcesso;
        //simulate asynchronous channel access

       timeStartSendBeacon = getSimulationManager()->periodMSGSend - beaconInterval.dbl();

       if (dataOnSch == true && !mac->isChannelSwitchingActive()) {
            dataOnSch = false;
            std::cerr << "App wants to send data on SCH but MAC doesn't use any SCH. Sending all data on CCH" << std::endl;
        }
        simtime_t firstBeacon = simTime() + getSimulationManager()->periodMSGSend;

        //simtime_t firstBeacon = simTime() + getSimulationManager()->periodMSGSend;

        if (par("avoidBeaconSynchronization").boolValue() == true) {

            simtime_t randomOffset = dblrand() * beaconInterval;
            firstBeacon = simTime() + randomOffset;

                if (mac->isChannelSwitchingActive() == true) {
                    if ( beaconInterval.raw() % (mac->getSwitchingInterval().raw()*2)) {
                        std::cerr << "The beacon interval (" << beaconInterval << ") is smaller than or not a multiple of  one synchronization interval (" << 2*mac->getSwitchingInterval() << "). "
                                << "This means that beacons are generated during SCH intervals" << std::endl;
                    }
                    firstBeacon = computeAsynchronousSendingTime(beaconInterval, type_CCH);
                }

                if (sendBeacons) {
                    cancelEvent(scheduleSendBeaconEvt);
                    scheduleAt(firstBeacon +timeStartSendBeacon, scheduleSendBeaconEvt);
                }

        }


        if( this->idProcesso < this->totalProcesso)
        {

            //Cria o gerenciador de Blocos Causais
            this->listCausalBlocks = new ManagerBlocksWithAbsentMSGRelay(this->idProcesso,this->totalProcesso);

            //Configuração do TimeSilence Periodic
            this->listCausalBlocks->activateTimesilencePeriodicOfApllication =true;
            this->listCausalBlocks->activateTimeSilenceByBlock =false;
            //Tempo para emissão do Timesilence a contar do inicio da transmissão(por exemplo= 37)
            this->listCausalBlocks->timesilencePeriodicOfApllication = 1.2;

            this->timeSilencePeriodicOfApllication=0.8;
            this->timesilencePeriodoIncrement =0.8;

            this->listCausalBlocks->relayMsg =true;
            this->listCausalBlocks->insertProcessInlist(this->totalProcesso);

            //Carrega os dados da SimulaçãoManager, caso a aplicação ainda não tenha feito isso com outro carro
            //SimulaçãoManager é estática, portanto só será carregada uma vez
            if (getSimulationManager()->isComplete == false)
            {
                getSimulationManager()->LoadListMsgToSendOfApp(SHEDULE_SEND_MSG_BLOCK);
                getSimulationManager()->intervalBeacon =  beaconInterval.dbl();
            }

            //Agenda as mensagens que devem ser enviadas por veículo
            StartComunicationSchedule();
        }

    }
}



//cria um evento para iniciar
void CausalBlocks::StartComunicationSchedule()
{   simtime_t timeNow = simTime();
    MessageBlock *msg = new MessageBlock("Msg");
    msg->setKind(SHEDULE_START_COMUNICATION);

    simtime_t timeSchedule = getSimulationManager()->periodMSGSend;
    //Faz o agendamento da MeNSsagem a Enviar
    scheduleAt(timeSchedule, msg);


    //Faz o agendamento do Envio do TimeSilence
   // scheduleTimeSilencePeriodic(timeSchedule.dbl() + this->listCausalBlocks->timesilencePeriodicOfApllication);
   // cout <<"\n\n ----Agendador da primeira msg a ser transmitida idProc ="<<this->idProcesso
  //       <<" tempo Atual= "<< timeNow  <<"Tempo agendado="<<timeSchedule;

}

void CausalBlocks::scheduleTimeSilencePeriodic(double pTime)
{
    MessageBlock *msg = new MessageBlock("TimeSilence");
    msg->setKind(SHEDULE_TIME_SILENCE_PERIODIC);

    //Faz o agendamento da Mesagem a Enviar
    scheduleAt(pTime, msg);
}

/* Essa função agenda a primeira mensagem a enviar para a rede. Após a ativação do evento, essa mensagem é chamada novamente */
void CausalBlocks::scheduleMsgToSendOfApp()
{
   double timeNow = simTime().dbl();
   double timeSchedule= 0.0;

   bool firstSchedule = false;


   cout <<"\n\n\n ----AGENDADOR DAS MENSAGENS TRANSMITIDAS idProc="<<this->idProcesso
      << " tempoAtual="<<timeNow
      <<"\n Total de MSG por Veiculo="<<getSimulationManager()->countMSGsByProcesso;


 if (getSimulationManager()->isComplete)
 {
     for(int i=0; i<getSimulationManager()->countMSGsByProcesso ; i++)
     {
         MessageBlock *msgAgendada = getSimulationManager()->nextMsgToSend();
         if (msgAgendada!=NULL)
         {

             MessageBlock *msg = new MessageBlock("Msg Enviada");

             //Copia os dados da mensagem original
             msg->setId(msgAgendada->getId());
             msg->setIsFailure(msgAgendada->getIsFailure());
             msg->setKind(SHEDULE_SEND_MSG_BLOCK);
             msg->setText(msgAgendada->getText());

             timeSchedule = timeSchedule + getSimulationManager()->intervalSendMSGByProcess + ((msg->getId()/2) * 0.001);
             scheduleAt(timeNow + timeSchedule,msg);
             //sendMsgApplWithCausalBlocks(msg,SHEDULE_SEND_MSG_BLOCK);

             cout<< "\n Msg= "<<msg->getId()<<"agendada no time= "<<(timeNow + timeSchedule);
             this->countMsgAlreadySend++;
             this->countScheduledMSGByProcess++;

         }
         else
         {
             cout<<"\n   ?????Erro=Simulador não está pegando a proxima mensagem a Enviar";
         }

     }

 }
 else{cout<<"\n   ?????Erro=SimuladorManager não Carregado";}

  // cout <<"\n\n\n ----FIMMM AGENDADOR DAS MENSAGENS TRANSMITIDAS idProc="<<this->idProcesso
    //    << " tempoAtual="<<timeNow
    //    <<" Total de MSG já disseminadas"<<getSimulationManager()->countMsgAlreadySent
    //    <<" totalMsgADisseminar ="<<getSimulationManager()->totalMsgToDisseminate;
 cout<< "\n Fim do Agendamento";
}
 /*

void CausalBlocks::scheduleMsgToSendOfApp()
{  double timeSend= 0;
   if (getSimulationManager()->isComplete)
   {
     timeSend = getSimulationManager()->periodMSGSend;
     for(int i=0; i< getSimulationManager()->countMSGsByProcesso; i++)
     {
       MessageBlock *msgAgendada = getSimulationManager()->nextMsgToSend();
       timeSend = timeSend + getSimulationManager()->intervalSendMSG;
       cout <<"\n   ===> MSgToSend Agendada="<<msgAgendada->getId()<< " tempo"<<timeSend ;
       if (msgAgendada!=NULL)
       {
           MessageBlock *msg = new MessageBlock(msgAgendada->getName());
           msg->setId(msgAgendada->getId());
           msg->setIsFailure(msgAgendada->getIsFailure());
           msg->setKind(SHEDULE_SEND_MSG_BLOCK);
           scheduleAt(simTime()+timeSend, msg);
          // scheduleEvetsBlocksApp(simTime() + timeSend, msg1);
       }
       else
       {
           cout<<"\n   ?????Erro=Simulador não está pegando a proxima mensagem a Enviar";
       }
       timeSend = timeSend + getSimulationManager()->intervalSendMSG;
     }
   }
   else{cout<<"\n   ?????Erro=SimuladorManager não Carregado";}
}

*/

simtime_t CausalBlocks::computeAsynchronousSendingTime(simtime_t interval, t_channel chan) {

    /*
     * avoid that periodic messages for one channel type are scheduled in the other channel interval
     * when alternate access is enabled in the MAC
     */

    simtime_t randomOffset = dblrand() * beaconInterval;
    simtime_t firstEvent;
    simtime_t switchingInterval = mac->getSwitchingInterval(); //usually 0.050s
    simtime_t nextCCH;

    /*
     * start event earlierst in next CCH  (or SCH) interval. For alignment, first find the next CCH interval
     * To find out next CCH, go back to start of current interval and add two or one intervals
     * depending on type of current interval
     */

    if (mac->isCurrentChannelCCH()) {
        nextCCH = simTime() - SimTime().setRaw(simTime().raw() % switchingInterval.raw()) + switchingInterval*2;
    }
    else {
        nextCCH = simTime() - SimTime().setRaw(simTime().raw() %switchingInterval.raw()) + switchingInterval;
    }

    firstEvent = nextCCH + randomOffset;

    //check if firstEvent lies within the correct interval and, if not, move to previous interval

    if (firstEvent.raw()  % (2*switchingInterval.raw()) > switchingInterval.raw()) {
        //firstEvent is within a sch interval
        if (chan == type_CCH) firstEvent -= switchingInterval;
    }
    else {
        //firstEvent is within a cch interval, so adjust for SCH messages
        if (chan == type_SCH) firstEvent += switchingInterval;
    }

    return firstEvent;
}


void CausalBlocks::scheduleEventsBlocksApp(simtime_t pTime, MessageBlock *pMsg)
{
    //Rever este código aqui
    if (pMsg->isScheduled())
    {
       cancelEvent(pMsg);
    }
    scheduleAt(pTime, pMsg);
    listEvents.push_back(pMsg);
}

void CausalBlocks::InicializeParameters()
{   /*
     *O número de carros deve ser inserido na variável totalProcesso e no arquivo erlangen.rou.xml, parametro number.
     */


    this->idProcesso = incrementProcess();
    //Números de Carros da Aplicação
    this->totalProcesso = 4;

    //Parametros carregados do arquivo INI
    headerLength = par("headerLength").longValue();
    sendBeacons = par("sendBeacons").boolValue();
    beaconLengthBits = par("beaconLengthBits").longValue();
    beaconUserPriority = par("beaconUserPriority").longValue();
    beaconInterval =  par("beaconInterval").doubleValue();

    dataLengthBits = par("dataLengthBits").longValue();
    dataOnSch = par("dataOnSch").boolValue();
    dataUserPriority = par("dataUserPriority").longValue();

    wsaInterval = par("wsaInterval").doubleValue();
    communicateWhileParked = par("communicateWhileParked").boolValue();
    currentOfferedServiceId = -1;

    isParked = false;

    findHost()->unsubscribe(mobilityStateChangedSignal, this);
    findHost()->unsubscribe(parkingStateChangedSignal, this);
    findHost()->subscribe(mobilityStateChangedSignal, this);
    findHost()->subscribe(parkingStateChangedSignal, this);

    //sendBeaconEvt = new cMessage("beacon evt", SEND_BEACON_EVT);
    scheduleSendBeaconEvt = new cMessage("Schedule beacon evt", SCHEDULE_SEND_BEACON_EVT);
    sendWSAEvt = new cMessage("wsa evt", SEND_WSA_EVT);

    generatedBeacons = 0;
    receivedBeacons = 0;


    if( (this->idProcesso >-1)&&(this->idProcesso < this->totalProcesso))
    {
        this->timesilence = 3;

        //foi preciso inicializar o valor do TimesilencePeriodic dentro do stage=0
        this->timeSilencePeriodicOfApllication=0.85;
        this->timesilencePeriodoIncrement =0.85;


        this->periodBeacon = par("beaconInterval").doubleValue();
        this->sizeMSGsByProcesso = 2;
        this->numMSGsByProcesso =80;//Cada carro é um processo
        this->countMsgAlreadySend = 0;
        this->numMSGsTotalToSend =this->numMSGsByProcesso * totalProcesso;
        this->numTotalRelay=30;
        this->BCUpdateMaxBloco = EVENT_DELIVERY;
        this->countpercentageMsgWithfailure = 0;
        this->countScheduledMSGByProcess = 0;

        this->timeSheduleProcessRequestRelay = 0.3;
        this->deliveryRobustProtocol = true;
        this->insertFailsByInterference = false;



        //Dados dos Carros
        getSimulationManager()->countCar=this->totalProcesso;

        //Dados das Mensagens
        getSimulationManager()->countMSGsTotalToSend = this->numMSGsTotalToSend;
        getSimulationManager()->countpercentageMsgWithfailure = this->countpercentageMsgWithfailure;

        getSimulationManager()->countMSGsByProcesso = this->numMSGsByProcesso;
        getSimulationManager()->periodMSGSend =80;
        getSimulationManager()->intervalSendMSGByProcess=1.0;
        getSimulationManager()->periodWaitingReplay =10;
        getSimulationManager()->countScheduledMSGByProcess=0;
        getSimulationManager()->textMsgToSend = "Msg testekkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk";

        //PArametros necessários para gravar os dados estatísticos
        getControlStatistic()->countCar=  this->totalProcesso;
        getControlStatistic()->countCarOfTheRoad = 2;
        getControlStatistic()->timeSilence = this->timesilence;
        getControlStatistic()->tamMsg =1;
        getControlStatistic()->countMSGByCar= this->numMSGsByProcesso;
        getControlStatistic()->numTotalRelay = this->numTotalRelay;


        //O período de retransmissão do timesilence esta configurado no stage = 1,0

    }

}

void CausalBlocks::receiveSignal(cComponent* source, simsignal_t signalID, cObject* obj, cObject* details) {
    Enter_Method_Silent();
    if (signalID == mobilityStateChangedSignal) {
        handlePositionUpdate(obj);
    }
    else if (signalID == parkingStateChangedSignal) {
        handleParkingUpdate(obj);
    }
}

void CausalBlocks::handlePositionUpdate(cObject* obj) {
    ChannelMobilityPtrType const mobility = check_and_cast<ChannelMobilityPtrType>(obj);
    curPosition = mobility->getCurrentPosition();
    curSpeed = mobility->getCurrentSpeed();
}

time_t CausalBlocks::getCurrentTime()
{
    time_t rawtime;
    time(&rawtime);
    return rawtime;
}

ControlStatistic * CausalBlocks::getControlStatistic()
{
  static ControlStatistic * moduleStatisctic = new ControlStatistic();
  //cout<<"Estatística QdtMSG="<<moduleStatisctic->listMSGSender.size();
  return moduleStatisctic;
}

SimulationManager * CausalBlocks::getSimulationManager()
{
  static SimulationManager * moduleSimulation = new SimulationManager();
  return moduleSimulation;
}



void CausalBlocks::loadApp(cMessage *msg)
{   const int kind = 1;

    sendMsgApplWithCausalBlocks(msg, kind);

}


MessageBlock* CausalBlocks::addEventTimeSilence(Block* pBlock, int pTime)
{  char* nome = "TIME_SILENCE";
   simtime_t timeNow = simTime();
   simtime_t timeSchedule = simTime() + pTime;

   //std:sprintf(nome, "%d",pBlock->idBlockCount);
   cout<< "\n   ->Event"<<nome;
   MessageBlock *msgTimeSilence = new MessageBlock(nome);
   try
   {
      msgTimeSilence->setKind(TIME_SILENCE);
      msgTimeSilence->setIdBC(pBlock->idBlockCount);
      msgTimeSilence->setName("TIME_SILENCE");
      //cancelAndDelete(msgTimeSilence);
      scheduleEventsBlocksApp(timeSchedule, msgTimeSilence);


      cout<< "Ativando o Timesilence="<<timeSchedule <<" tempo atual="<<timeNow <<" para o processo com o IDLocal: "<<idProcesso<<
         " IDBlocoCount="<<pBlock->idBlockCount;
   }
   catch (const std::exception& e)
   {cout<<"Erro ao ativar o evento de TimeSilence";}

    return msgTimeSilence;

}



bool* CausalBlocks::existsMsgInListReply(int pIdBlock, int pIdProcess, int pKind)
{   bool result = false;
    MessageBlock * msg = NULL;
    for (int i=0; i<listReplay.size();i++)
    {
        msg =dynamic_cast<MessageBlock*>(listReplay[i]);
        if ((msg->getIdRemetente()== pIdProcess) &&
           (msg->getIdBC()== pIdBlock))
        {
            result = true;
            break;

        }
    }

}

int CausalBlocks::getIndexMsgEventBlock(Block* pBlock, int pKind)
{
    MessageBlock *msgTimeSilence = NULL;
    int result = -1;
    for (int i=0; i<listEvents.size();i++)
    {
       msgTimeSilence =dynamic_cast<MessageBlock*>(listEvents[i]);
       if ( msgTimeSilence->isScheduled()  &&
            (msgTimeSilence->getKind()== pKind) &&
            (msgTimeSilence->getIdBC()== pBlock->idBlockCount))
       {
           result = i;
           break;

       }
    }

    return  result;
}

int CausalBlocks::getIndexMsgEventTimeOutMessage(int pIdProcesso, int pIdMessage, int pKind)
{
    MessageBlock *msgTimeSilence = NULL;
    int result = -1;
    for (int i=0; i<listEvents.size();i++)
    {
       msgTimeSilence =dynamic_cast<MessageBlock*>(listEvents[i]);
       if ( msgTimeSilence->isScheduled()  &&
            (msgTimeSilence->getKind()== pKind) &&
            (msgTimeSilence->getId()== pIdMessage)&&
            (msgTimeSilence->getIdRemetente()== pIdProcesso)
            )
       {
           result = i;
           break;

       }
    }

    return  result;
}

int CausalBlocks::getIndexMsgEventTimeOutPreviousMsg(int pIdProcesso, int pIdMessage, int pIdBlock, int pKind)
{
    MessageBlock *msgTimeSilence = NULL;
    int result = -1;
    for (int i=0; i<listEvents.size();i++)
    {
       msgTimeSilence =dynamic_cast<MessageBlock*>(listEvents[i]);
       if ( msgTimeSilence->isScheduled()  &&
            (msgTimeSilence->getKind()== pKind) &&
            (msgTimeSilence->getId() < pIdMessage)&&
            (msgTimeSilence->getIdBC()<= pIdBlock)&&
            (msgTimeSilence->getIdRemetente()== pIdProcesso)
            )
       {
           result = i;
           break;

       }
    }

    return  result;
}

MessageBlock* CausalBlocks::getMsgEventBlock(int pIdBlock, int pIdProcesso,int pKind)
{
    MessageBlock *msg = NULL;
    for (int i=0; i<listEvents.size();i++)
    {
       msg =dynamic_cast<MessageBlock*>(listEvents[i]);
       if ( msg->isScheduled()  &&
            (msg->getKind()== pKind) &&
            (msg->getIdBC()== pIdBlock)&&
            (msg->getIdRemetente()== pIdProcesso))
       {
         break;

       }
    }

    return  msg;
}

void CausalBlocks::resetEventTimeSilence(Block* pBlock, int pTime)
{  MessageBlock *msgTimeSilence = NULL;
   int posEvent;
   try
   {

      cout<< "\n===>resetEventTimeSilence Bloco="<< pBlock->idBlockCount;
      simtime_t timeShedule=0;
      simtime_t timeNow=simTime();
      posEvent = getIndexMsgEventBlock(pBlock, TIME_SILENCE);
      if ((posEvent >0) && (posEvent< listEvents.size()))
          msgTimeSilence = listEvents[posEvent];
      if (msgTimeSilence != NULL)
      {
        cancelAndDelete(msgTimeSilence);
      }

      cout <<"   \n%%%%%Evento do timesilence bloco= "<<pBlock->idBlockCount<<" cancelado com sucesso!";
      timeShedule = timeNow+ pTime;

      addEventTimeSilence(pBlock, pTime);
      cout<< "\n   Reativando o Timesilence=("<<timeShedule<<") timeAtual="<<timeNow <<" para o processo com o IDLocal: "<<idProcesso<<
                      " IDBlocoCount="<<pBlock->idBlockCount;



   }
   catch (const std::exception& e)
   {cout<<"Erro ao ativar o evento de TimeSilence";}


}

void CausalBlocks::processTimeSilencePeriodic(cMessage *msg)
{
    Block *causalBlock = NULL;
    MessageBlock *msgTimeSilencePeriodic = new MessageBlock("NULL");
    double time= simTime().dbl();
    double timeSheduleSendNULL;
    cout<<"\n   ==> Processa timesilence Periodico="<< time  <<" Processo Local = "<< idProcesso;
    try
    {
       //Envia uma MSG null
        msgTimeSilencePeriodic->setKind(SHEDULE_SEND_NULL);
        msgTimeSilencePeriodic->setIdRemetente(this->idProcesso);
       //timeSheduleSendNULL = time;
       timeSheduleSendNULL = time + (idProcesso/100);
       //timeSheduleSendNULL = time + this->idProcesso/10000;
       scheduleAt(timeSheduleSendNULL, msgTimeSilencePeriodic);

       //sendMsgNULL(msg);

       time = time + listCausalBlocks->timesilencePeriodicOfApllication;
       scheduleTimeSilencePeriodic(time);
   }
   catch(const std::exception& e)
   {cout<<"Erro na função processTimeSilencePeriodic";}
}


void CausalBlocks::processesseTimeSilence(cMessage *msg)
{   MessageBlock * pacoteMsgBlockRecebido = dynamic_cast<MessageBlock*>(msg);
    Block *causalBlock = NULL;
    bool isUpdateMAxBC = true;
    double timeDelivery= simTime().dbl();
    cout<<"\n   ==> Processa timesilence do bloco="<<pacoteMsgBlockRecebido->getIdBC()
        <<"Processo Local = "<< idProcesso;
    try
    {
       //Envia uma MSG null
       sendMsgNULL(msg);

       if (listCausalBlocks!=NULL)
       {
          causalBlock = listCausalBlocks->getBlock(pacoteMsgBlockRecebido->getIdBC());
          if (causalBlock->isDelivery==false)
          { listCausalBlocks->deliveryBlock(pacoteMsgBlockRecebido->getIdBC(), timeDelivery, isUpdateMAxBC, true);
            managerDeliveryBlocksInControlesStatistic("ProcessTimeSilence",causalBlock, pacoteMsgBlockRecebido);
          }
       }

   }
   catch(const std::exception& e)
   {cout<<"Erro na função processesseTimeSilence";}

}

void CausalBlocks::sendMsgNULL(cMessage *msg)
{
    int idNewBC =0;
    double timeDelivery= simTime().dbl();
    MessageBlock * pacoteMsgBlockRecebido = dynamic_cast<MessageBlock*>(msg);
    MessageBlock * pacoteMsgBlockAEnviar = new MessageBlock();
    Block* causalBlock;
    int countMsgs;
    char* textmsg;

    if(isMessageLocal(pacoteMsgBlockRecebido))
    {

        try
        {
            this->populateWSM(pacoteMsgBlockAEnviar);

            //Incrementa um novo BlockCount
            this->listCausalBlocks->incrementaBlockCount();
            idNewBC = this->listCausalBlocks->getBlockCount();

            causalBlock = this->listCausalBlocks->findOrAddNewBlock(idNewBC);
            causalBlock->isSendMsg=true;
            causalBlock->isValid=true;

            //Só ativa o timesilence ByBloco se o mesmo foi configurado previamente
            if (listCausalBlocks->activateTimeSilenceByBlock)
                addEventTimeSilence(causalBlock, this->timesilence);
            textmsg = "NULL";
            countMsgs = causalBlock->ListMsgByProcess.size()+1;
            causalBlock->markMsg(countMsgs, textmsg, "+",causalBlock->idBlockCount, idProcesso, true);


            //Configuração dos Dados do Bloco Causal da msg
            pacoteMsgBlockAEnviar->setText("NULL");
            pacoteMsgBlockAEnviar->setIdBC(idNewBC);
            insertLDViInPacoteMsgBlock(this->listCausalBlocks->LDVi,pacoteMsgBlockAEnviar);
            this->listCausalBlocks->addLDVInMLDV(this->listCausalBlocks->LDVi, this->idProcesso,idNewBC, true, false);

            this->listCausalBlocks->updateMBVi(this->idProcesso, idNewBC);

            pacoteMsgBlockAEnviar->setKind(SEND_NULL);

            pacoteMsgBlockAEnviar->setIdRemetente(this->idProcesso);
            pacoteMsgBlockAEnviar->setId(-1);
            pacoteMsgBlockAEnviar->setNomeRemetente(getName());
            pacoteMsgBlockAEnviar->setName("NULL");




            //Envia mensagem para a rede AdHoc
            sendDown(pacoteMsgBlockAEnviar);

            cout<<"\n Envio da Mensagem NULL Proceso Local="<<idProcesso;
            cout<<"\n BC="<<idNewBC<< "Total de Blocos de MSG="<<this->listCausalBlocks->listBlocks.size();

        }
        catch (const std::exception& e)
        {cout<<"Erro função sendMsgNULL";}
    }

}

void CausalBlocks:: send( MessageBlock * pacoteMsgBlockAEnviar)
{
    //getControlStatictic()->addMSG(pacoteMsgBlockAEnviar->id, 70,25, pacoteMsgBlockAEnviar->idRemetente);
   sendDown(pacoteMsgBlockAEnviar);

}


bool CausalBlocks::isMessageLocal(MessageBlock* msg)
{
    bool resultado = false;
    if (msg->getIdRemetente()==idProcesso)
        resultado =  true;
    else
        resultado= false;

    return resultado;

}

void CausalBlocks::scheduleProcessRequestRelay(cMessage *msg, MsgByProcess *pMsg,double pTimeOut)
{

   // simtime_t time = simTime() + timeSheduleProcessRequestRelay + (this->idProcesso/1000);
    time_t  timeCurrent = getCurrentTime();
    time_t  timeSend = timeCurrent+ pTimeOut;
    double timeSimulator = SIMTIME_DBL(simTime());
    MessageBlock * pacoteMsgReceived = dynamic_cast<MessageBlock*>(msg);
    MessageBlock * msgShedule = new MessageBlock("SheduleProcessReplay");

    cout <<"\   -->Agendando a Retransmissão da solicitação do Bloco"<<pacoteMsgReceived->getIdBC()
         <<"\n  -ProcessoRem="<< pacoteMsgReceived->getIdRemetente()
         <<"\n  - ProcessoSolici="<< pacoteMsgReceived->getIdRemetenteRequest();
    cout<< "\n  - timeSheduleProcessRequestRelay =" <<time;
    msgShedule->setIdBC(pacoteMsgReceived->getIdBC());
    msgShedule->setIdRemetente(pacoteMsgReceived->getIdRemetente());
    msgShedule->setIdRemetente(pacoteMsgReceived->getIdRemetente());
    //Algoritmo de George
    //time = timeSheduleProcessRequestRelay + this->idProcesso;
    msgShedule->setKind(SHEDULE_SEND_MSG_BLOCK_REQUEST);
    msgShedule->setName("SheduleProcessReplay");
    scheduleEventsBlocksApp(timeSimulator+ pTimeOut, msgShedule);
    if(pMsg!=NULL)
      pMsg->isSchedule =true;
    // addStartRelayInMSG(int pIdMSG, time_t pTime, double pTimeSimulator, int pIdProcReceptor)
   // addStartRelayInMSG(int pIdMSG, time_t pTime, double pTimeSimulator,int pIdProcReceptor);

    getControlStatistic()->addStartRelayInMSG(pacoteMsgReceived->getId(), timeCurrent, timeSimulator, this->idProcesso);
    cout <<"\n   -->Finalizando o agendamento\n ";

}

void CausalBlocks::processesRequestRelay(cMessage *msg)
{
   MessageBlock * pacoteMsgReceived = dynamic_cast<MessageBlock*>(msg);
   MessageBlock * pacoteToSend = NULL;
   MessageBlock * msgSchedule=NULL;
   MsgByProcess *msgReplay = NULL;
   MLDV* newMLDV= new MLDV();
   Block *causalBlock = NULL;
   bool isUpdateMAxBC = true;
   double timeSimulator,time;


   timeSimulator = SIMTIME_DBL(simTime());
   time = getCurrentTime();



   cout<<"\n---------Respondendo a solicitação de Retransmissao-----------";
   cout<<"\n   - ProcessoLocal="<<idProcesso;
   cout<<"\n   - EhMensagemLocal="<<isMessageLocal(pacoteMsgReceived);
   cout<<"\n   - Kind(msg)="<<msg->getKind();
   //&&

   //SHEDULE_SEND_MSG_BLOCK_REQUESt
   causalBlock = listCausalBlocks->getBlock(pacoteMsgReceived->getIdBC());
   //causalBlock->printMsgs();
   msgReplay = causalBlock->getMsg(pacoteMsgReceived->getIdRemetente());

   //e a msg for nula e não for ausente, pode ser reenviada
   if((msgReplay!=NULL)&&(strcmp(msgReplay->status,"-")!=0))
   {
       //Cria o pacote a ser enviado
       pacoteToSend = createPackageToSend(msgReplay, "MSG Replay", SEND_MSG_BLOCK_REPLY,
         causalBlock->ListMsgByProcess.size(),pacoteMsgReceived->getIdRemetente(), this->idProcesso);

     //Configura o texto do Pacote
     pacoteToSend->setText(msgReplay->text);
     cancelEventSheduleofRelay(pacoteMsgReceived->getIdBC(),pacoteMsgReceived->getIdRemetente(), SHEDULE_SEND_MSG_BLOCK_REQUEST);
     //Configura o LSV entregue nomomento do envio da mensagem
     insertLDViInPacoteMsgBlock(msgReplay->ldvAllProcess,pacoteToSend);
     msgReplay->countRelay++;
     msgReplay->isSchedule = false;

     send(pacoteToSend);



     cout<<"\n   - IdMsg="<< msgReplay->id <<" replay enviado com sucesso!";
    /*  cout<< "\n   => Procurando o Evento Shedule "<<SHEDULE_SEND_MSG_BLOCK_REQUEST<<" IdBlock="<<pacoteMSGRecebida->getIdBC()
                                           <<" IdProc =" <<pacoteMSGRecebida->getIdRemetente();
                       if (cancelEventSheduleofRelay(msg,pacoteMSGRecebida->getIdBC(),pacoteMSGRecebida->getIdRemetente(),SHEDULE_SEND_MSG_BLOCK_REQUEST))
                       {

                           cout<<"\n   => agendamento encontrado SHEDULE_SEND_MSG_BLOCK_REQUEST e cancelado";
                       }
                       */
   }

   cout<<"\n\n---------Fim Respondendo.-------------------------------------";
}


void CausalBlocks:: processRelay()
{
    MsgByProcess *msgReplay = NULL;
    MessageBlock *pacoteMsgBlock = NULL;
    Block* blockCurrent = NULL;
    cout<<"\n   ----------Solicitação de Retransmissão-------------";
    if((this->listCausalBlocks!=NULL))
    {
       for(int i=0;i<listCausalBlocks->listMsgAbsent.size(); i++)
       {
           msgReplay = dynamic_cast<MsgByProcess*>(listCausalBlocks->listMsgAbsent[i]);
           blockCurrent = listCausalBlocks->getBlock(msgReplay->idBC);
           if (blockCurrent !=NULL && (msgReplay->countRelay < this->numTotalRelay))
           {

              msgReplay->countRelay++;
              msgReplay->timeRequestReplaySimulator = SIMTIME_DBL(simTime());
              cout<< "\n   ->Idbloco= "<< msgReplay->idBC
                  << " idProcesso="<<msgReplay->idRemetente
                  <<"\n IdProcessoSolicitante="<< this->idProcesso
                  <<"\n coutRetransmissao="<<msgReplay->countRelay;
              pacoteMsgBlock = createPackageToSend(msgReplay, msgReplay->text, SEND_MSG_BLOCK_REQUEST,
                 blockCurrent->ListMsgByProcess.size(), msgReplay->idRemetente, this->idProcesso);
              pacoteMsgBlock->setIdRemetenteRequest(this->idProcesso);

              //resetEventTimeSilence(blockCurrent, this->timesilence + getSimulationManager()->periodWaitingReplay);
              resetEventTimeSilence(blockCurrent, getSimulationManager()->periodWaitingReplay);
              send(pacoteMsgBlock);

           }
           else
           {cout<<"\n   Atenção! Bloco não locaizado na função Replay";}


       }
       cout<<"\n   Qtd. Falhas="<<listCausalBlocks->listMsgAbsent.size();

      // listCausalBlocks->listMsgAbsent.clear();


    }
    cout<<"\n   ---------------------------------------------------";

}

bool CausalBlocks:: existslEventSheduleOfRelay(int pIdMessage, int pIdBlock, int pIdProcessSender)
{
    MessageBlock *msgFind = NULL;
    vector<MessageBlock*> listEventCancel;

    int i=0;

    bool result = false;

    for (int i=0;i<listEvents.size();i++)
    {
        msgFind =dynamic_cast<MessageBlock*>(listEvents[i]);

        if ( (msgFind->getKind()== SHEDULE_SEND_MSG_BLOCK_REQUEST) &&
           (msgFind->getIdBC()== pIdBlock)&&
           (msgFind->getIdRemetente()== pIdProcessSender)==
             (msgFind->getId()== pIdMessage) )
         {
           return true;
         }

    }
    return result;
}


bool CausalBlocks:: cancelEventSheduleofRelay(int pIdBlock, int pIdProcess, int pKind)
{
    MessageBlock *msgFind = NULL;
    vector<MessageBlock*> listEventCancel;
    auto it = listEvents.begin();
    int i=0;

    bool result = false;

    cout << "Pesquisar e cancelar o evento com idBC="<< pIdBlock<< " Remetente="<<pIdProcess
         << " kind= "<<pKind;


    for (int i=0;i<listEvents.size();i++)
       { msgFind =dynamic_cast<MessageBlock*>(listEvents[i]);
         //cout<< "\n   ->ListEventoAntesCancelamento= "<< msgFind->getKind()<<"Bloco="
                // <<msgFind->getIdBC()<<" ProcRem.="<<msgFind->getIdRemetente()<< " isScheduled()="<<msgFind->isScheduled();

       }


    while(it != listEvents.end())
    {
        msgFind = listEvents[i];

        if ( (msgFind->getKind()== pKind) &&
             (msgFind->getIdBC()== pIdBlock)&&
             (msgFind->getIdRemetente()== pIdProcess))
        {
            cout<< "\n Lista de Eventos Cancela "<< i<<"evento = "<< msgFind->getKind()<<"Bloco="
                        <<msgFind->getIdBC()<<" ProcRem.="<<msgFind->getIdRemetente()<< " isScheduled()="<<msgFind->isScheduled();
            if (msgFind->isScheduled())
            {
               cancelAndDelete(msgFind);
            }

            listEvents.erase(it);
            result = true;

        }
        else ++it;

    }

    cout<< "\n\n";
   // for (int i=0;i<listEvents.size();i++)
   // { msgFind =dynamic_cast<MessageBlock*>(listEvents[i]);
      //cout<< "\n   ->ListEventoApósCancelamento= "<< msgFind->getKind()<<"Bloco="
            //  <<msgFind->getIdBC()<<" ProcRem.="<<msgFind->getIdRemetente()<< " isScheduled()="<<msgFind->isScheduled();

    //}

    return  result;
}

void CausalBlocks:: printDateOfMsgReceived(MessageBlock * pPacoteMSGRecebida)
{
    cout<<"\n\n\n -----------Recebendo mensagens-------------------"<<
          " \n- Processo Local = "<< this->idProcesso <<
          " \n- BC="<<pPacoteMSGRecebida->getIdBC()<<
          " \n- Remetente="<< pPacoteMSGRecebida->getIdRemetente()<<
          " \n- IdMensagem="<<pPacoteMSGRecebida->getId()<<
          " \n- NomeRemetente="<< (char*)pPacoteMSGRecebida->getNomeRemetente()<<
          " \n- MensagemLocal="<< isMessageLocal(pPacoteMSGRecebida)<<
          " \n- totalBlocos(bufferLocal)="<<  this->listCausalBlocks->listBlocks.size();

}

bool CausalBlocks::isMsgFailureRandom(MessageBlock * pPacoteMSGRecebida, unsigned int pMsgType)
{
    bool isFailure=false;
    //(getSimulationManager()->existsMsgInlistNumRandomOffailure(idMsgRemetente)
    if (pMsgType!=SEND_MSG_BLOCK_REPLY &&  (this->countpercentageMsgWithfailure>0) && (insertFailsByInterference) &&
        (getSimulationManager()->existsMsgInlistNumRandomOffailure(getSimulationManager()->countMsgToDisseminate)))

     // ((getSimulationManager()->countMsgToDisseminate == 18)
     // (getSimulationManager()->countMsgToDisseminate == 2)  ||
    //  (getSimulationManager()->countMsgToDisseminate == 12)
      // (getSimulationManager()->countMsgToDisseminate == 4)||
     // (getSimulationManager()->countMsgToDisseminate == 5)||
     // (getSimulationManager()->countMsgToDisseminate == 6)||  //||
      //(getSimulationManager()->countMsgToDisseminate == 7)||
      // (getSimulationManager()->countMsgToDisseminate == 8) //||
    //  (getSimulationManager()->countMsgToDisseminate == 9 )||
    //  (getSimulationManager()->countMsgToDisseminate == 10)||
      //(getSimulationManager()->countMsgToDisseminate == 10)
      //(getSimulationManager()->countMsgToDisseminate == 11)
    //  (getSimulationManager()->countMsgToDisseminate == 12)||
    //  (getSimulationManager()->countMsgToDisseminate == 13)||
      //(getSimulationManager()->countMsgToDisseminate == 14)
      //(getSimulationManager()->countMsgToDisseminate == 15)
     // (getSimulationManager()->countMsgToDisseminate == 16)||
    //  (getSimulationManager()->countMsgToDisseminate == 17)
      //|| (getSimulationManager()->countMsgToDisseminate == 5)||
      // (getSimulationManager()->countMsgToDisseminate == 6)

         //  if (getSimulationManager()->existsMsgInlistNumRandomOffailure(getSimulationManager()->countMsgToDisseminate))
     {
       isFailure = true;
       cout << "\n\n  --> Inserção de uma Falha na iteração = "
            <<getSimulationManager()->countMsgToDisseminate
            <<"não recebida"  ;

       //Insere os dados da Falha no móodulo estatístic

       getControlStatistic()->addMessageInListControlMessageFailed(pPacoteMSGRecebida->getId(),
          pPacoteMSGRecebida->getIdRemetente() ,
          this->idProcesso,
          pPacoteMSGRecebida->getIdBC(),
          getSimulationManager()->countMsgToDisseminate);
     }
    return isFailure;

}

void CausalBlocks:: managerCountDisseminatiosOfChannel(MessageBlock * pPacoteMSGRecebida, unsigned int pMsgType){
    //Controla o número de disseminação simulação excluindo as mensagens de retransmissão
    if (pMsgType==RECEIVE_MSG_BLOCK)
    {
       getSimulationManager()->countMsgToDisseminate++;
       cout<<"\n -->countMsgToDisseminate="<<getSimulationManager()->countMsgToDisseminate
           <<" totalMsgADisseminar ="<<getSimulationManager()->totalMsgToDisseminate
           <<" ListaDeFalhas =" <<getSimulationManager()->listNumRandomOffailure.size();
       getSimulationManager()->printListRandomOfFailure();
       cout<<"\n  -->QtdMSgAusentes =" << this->listCausalBlocks->countMsgAbsents
           <<"\n  -->QtdMSgAusentes = "<<this->listCausalBlocks->countMsgRecovered;
     }

}

void CausalBlocks:: cancelTimeOutScheduleProcessMessageRetransmission(int pIdProcessoSender, int pIdMessage,int pIdBlock,  int pKind)
{


   cancelEventSheduleofRelay(pIdBlock,pIdProcessoSender,pKind);


}



void CausalBlocks:: receiveMsgApplWithCausalBlocks(cMessage *msg, unsigned int pMsgType)
{
    MessageBlock * pacoteMSGRecebida = dynamic_cast<MessageBlock*>(msg);
    MessageBlock *msgSchedule= NULL;
    MsgByProcess *msgBlock = NULL;
    bool isldvRecoveredMessagesAdded =false;

    char* textmsg= NULL;
    char* nomeRemetente= NULL;
    int idRemetente= -1;
    int idRemetenteReplay= -1;
    int idBCRemetente =-1;
    int idMsgRemetente;
    Block* blockLocate=NULL;
    Process* processSender = NULL;
    Process* processCurrent = NULL;
    time_t timeReceive;
    time_t timeRequestReplay;
    time_t timeEndReplay;
    vector<int> ldv;
    vector<int> ldvRecoveredMessages;
    double timeRequestReplaySimulator;
    double timeReceiveSimulator;
    double timeEndReplaySimulator;
    bool isFailure=false;
    bool isMsgadded = false;
    MLDV* newMLDV = new MLDV();
    bool isReplay= false;



    try
    {


        if(!isMessageLocal(pacoteMSGRecebida))
        {
            timeReceive = getCurrentTime();
            timeReceiveSimulator = SIMTIME_DBL(simTime());

            timeEndReplaySimulator=timeReceiveSimulator;
            textmsg = (char*)pacoteMSGRecebida->getText();
            nomeRemetente= (char*)pacoteMSGRecebida->getNomeRemetente();
            idRemetente = pacoteMSGRecebida->getIdRemetente();
            idMsgRemetente=pacoteMSGRecebida->getId();
            idRemetenteReplay = pacoteMSGRecebida->getIdSenderReplay();
            idBCRemetente = pacoteMSGRecebida->getIdBC();
            ldv =  getLDViInPacoteMsgBlock(ldv ,pacoteMSGRecebida, listCausalBlocks->vectorLVD);
            ldvRecoveredMessages =  getLDViInPacoteMsgBlock(ldvRecoveredMessages ,pacoteMSGRecebida, listCausalBlocks->vectorLVDReceivedMessages);
            isReplay = pMsgType==SEND_MSG_BLOCK_REPLY;

            printDateOfMsgReceived(pacoteMSGRecebida);
            //Gerencia a qtd de msg recebidas no Canal
            managerCountDisseminatiosOfChannel(pacoteMSGRecebida, pMsgType);
            //Verifica se a msg é uma falha randomica gerada para o canal
            isFailure = isMsgFailureRandom(pacoteMSGRecebida, pMsgType);
            processCurrent= listCausalBlocks->getProcess(this->idProcesso);
            //Testar o timeOut de Retransmissão, caso exista
            cancelTimeOutScheduleProcessMessageRetransmission(idRemetente, idMsgRemetente, idBCRemetente,SHEDULE_SEND_MSG_BLOCK_REQUEST);

            if (isFailure==true)
            {
                cout<<"\n -----------------Recebendo uma falha da msg ="<<idMsgRemetente
                    <<" Proc Local = "<< this->idProcesso<<"ProcRemetente="<<idRemetente
                    <<" contDisseminacao="<<getSimulationManager()->countMsgToDisseminate;
                cout<<"?????";
                getSimulationManager()->countMsgToDisseminate++;


            }

            if (this->idProcesso==0 &&  ldv[0]==2 && idRemetente==1)
             cout<<"Teste";


            //Configura o Bloco Causal, antes do envio da Mensagem
            if (!isFailure)
            {

                if((this->listCausalBlocks!=NULL))
                {
                    //Adiciona um processo
                    processSender = listCausalBlocks->findOrAddNewProcess(idRemetente,nomeRemetente);
                    blockLocate = listCausalBlocks->findOrAddNewBlock(idBCRemetente);
                    if(blockLocate!=NULL)
                    {
                        if(pMsgType==SEND_MSG_BLOCK_REPLY)
                        {
                            cout<< "Relay recebido!!";
                        }


                        listCausalBlocks->updateMBVi(idRemetente,idBCRemetente);
                        newMLDV = listCausalBlocks->addLDVInMLDV(ldv, processSender->id, idBCRemetente, true, true);
                        newMLDV = listCausalBlocks->addLDVInMLDV(ldvRecoveredMessages, processSender->id, idBCRemetente, true, true);
                        msgBlock = blockLocate->findMsgReceived(processSender->id);

                        if ((!blockLocate->getIsComplete()) &&(!blockLocate->getIsDelivery() &&
                                msgBlock==NULL))
                        {
                            //Só ativa o timesilence do Bloco se o mesmo foi configurado previamente
                            if (listCausalBlocks->activateTimeSilenceByBlock)
                            {
                                resetEventTimeSilence(blockLocate, this->timesilence);
                            }

                            //Regras de atualização do MLDV e do MBV, conforme descrito no artigo 1
                            //cout<<"\n ---->Listagem MLVi procSender ("<< processSender->id<<") antes de receber a mensagem\n";
                            //printMLDViAllProcess();

                            findAndUpdateLDVInMLDVWithFaulty(processSender->id,ldv, idBCRemetente, idMsgRemetente);
                            msgBlock =  listCausalBlocks->MarkBlockPerMsgPerProcess(idMsgRemetente,textmsg, idBCRemetente,
                                    processSender->id, blockLocate,timeReceive,timeReceiveSimulator, false, false,true);
                            msgBlock->ldv = ldv[processSender->id];
                            msgBlock->ldvAllProcess=ldv;
                            cout << "?????Msg Adicionada id="<<msgBlock;

                            //Dados Estatisticos
                            getControlStatistic()->addTimeReceiveInMSG(idMsgRemetente,
                               timeReceive,idProcesso,msgBlock->countRelay,timeRequestReplay, timeReceive,
                               timeReceiveSimulator, msgBlock->timeRequestReplaySimulator, timeReceiveSimulator);
                            if(pMsgType==SEND_MSG_BLOCK_REPLY)
                            {
                               cout<<" \n- Replay processado com sucesso!";
                               getControlStatistic()->addEndRelayInMSG(idMsgRemetente,
                                 timeReceive, timeReceiveSimulator, this->idProcesso);
                            }
                                //Processa as Retransmissões, caso exista alguma na lista
                                // processRelay();


                            /* Se após marcar a mensagem como recebida, o bloco ficar completo e for entregue(delivery),
                                      deve-se guardar no controle Estatístico, a lista das mensagens recebidas
                             managerDeliveryBlocksInControlesStatistic("Receive", blockLocate,pacoteMSGRecebida);
                             */
                            //Reseta o TimeSilence do Bloco
                            if (listCausalBlocks->activateTimeSilenceByBlock)
                            {
                                resetEventTimeSilence(blockLocate, this->timesilence + this->timesilencePeriodoIncrement);
                            }

                            //processa retransmissão das mensagens ausentes enfileiradas
                            //messageRecovery();

                        }
                        deliveryWithRobustProtocol(msgBlock,isReplay, idBCRemetente,
                            processSender, ldv, newMLDV, false, timeReceive,timeReceiveSimulator);
                    }
                    else {cout<<"======>Bloco já Completo ou já entregue!";}
                    //Inclui as respostas de retransmissão em uma lista para não reenviar algo que já foi transmitido
                    if(pMsgType==SEND_MSG_BLOCK_REPLY)
                    {
                        //Caso o nó tenha agendado uma resposta de ret"ransmissão, ao receber esta resposta de outro veiculo, deve cancelar o evento
                        getControlStatistic()->addCountRetransmissionReceipt(idMsgRemetente, this->idProcesso, timeReceiveSimulator);
                        listReplay.push_back(pacoteMSGRecebida);
                        if (!isldvRecoveredMessagesAdded)
                        {
                          listCausalBlocks->addLDVInMLDV(ldvRecoveredMessages, processSender->id, idBCRemetente, true, true);
                          cancelTimeOutScheduleProcessMessageRetransmission(idRemetente, idMsgRemetente, idBCRemetente,SHEDULE_SEND_MSG_BLOCK_REQUEST);

                        }
                    }
                } else {cout<<"========>listCausalBlocks não criado!";}
            }
            else
            {
                //getControlStatistic()->addFaultyMessageInProcess(idMsgRemetente,this->idProcesso);
            }
            cout<<"\n\ ----------------------------------------";
        }
    }

    catch (const std::exception& e)
    {cout<<"Erro função receiveMsgApplWithCausalBlocks";}

}

void CausalBlocks:: deliveryWithRobustProtocol(MsgByProcess *pMsg, bool isReplay, int pIdBlockCount, Process *pProcSender,
    vector<int>pLdv, MLDV* pNewMLDV, bool pIsPrintLDVI, double pTimeDelivery, double pTimeDeliverySimulator)
{
    //De acordo com o protocolo, somente as mensagens recebidas pertencentes a MAtriz deve passar pela rotina de entrega
    if(!pMsg->delivery  && ((pLdv[pProcSender->id] >= listCausalBlocks->LDVi[this->idProcesso]) || isReplay))
    {   cout<<"\n deliveryWithRobustProtocol  idMensagem= "<<pMsg->id<<" ProcSender = "<<pProcSender->id<<
          " BC="<<pIdBlockCount;
        pMsg->delivery= true;
        listCausalBlocks->updateMaxBC(listCausalBlocks->getBlockCount(),pIdBlockCount);
        listCausalBlocks->updateLDV(pProcSender->id, pIdBlockCount);

        getControlStatistic()->addTimeDeliveryInMSG(pMsg->id,
                pTimeDelivery, pTimeDeliverySimulator, this->idProcesso);

        if(pIsPrintLDVI)
        {
           cout<<"MLVi procAtual=("<< this->idProcesso<<")\n";
           listCausalBlocks->printMLDVi(listCausalBlocks->getProcess(this->idProcesso));

           cout<<"MLVi procSender ("<< pProcSender->id<<")\n";
           //listCausalBlocks->printMLDVi(pProcSender);
        }
        //Atualiza os MLDVi anteriores que solicitaram a retransmissão a partir do BlockCount
        updateMLDVByBlockCount(pProcSender->id, pIdBlockCount);

    }
    if (pMsg->delivery && isReplay)
    {
       listCausalBlocks->updateLDViRecoveredMessages(pProcSender->id, pIdBlockCount);
    }
    deliveryAllMsgWithRobustProtocol(pTimeDelivery, pTimeDeliverySimulator);
}

void CausalBlocks:: deliveryAllMsgWithRobustProtocol(double pTimeDelivery, double pTimeDeliverySimulator)
{   MsgByProcess *pMsg = NULL;
    Block *causalBlock = NULL;


    for(int contB=0; contB< this->listCausalBlocks->listBlocks.size(); contB++)
    {
         causalBlock  = dynamic_cast<Block*>(this->listCausalBlocks->listBlocks[contB]);
         for(int contProc=0; contProc< causalBlock->ListMsgByProcess.size(); contProc++)
         {

             pMsg= causalBlock->ListMsgByProcess[contProc];
             if(!pMsg==NULL && !pMsg->delivery  && (pMsg->ldv >= listCausalBlocks->LDVi[this->idProcesso]))
             {  pMsg->delivery= true;
               listCausalBlocks->updateMaxBC(listCausalBlocks->getBlockCount(),pMsg->idBC);
               listCausalBlocks->updateLDV(pMsg->idRemetente, pMsg->idBC);
               getControlStatistic()->addTimeDeliveryInMSG(pMsg->id,
                  pTimeDelivery, pTimeDeliverySimulator, this->idProcesso);
               //Atualiza os MLDVi anteriores que solicitaram a retransmissão a partir do BlockCount
               updateMLDVByBlockCount(pMsg->idRemetente, pMsg->idBC);

             }



        }



    }

}


void CausalBlocks::updateMLDVByBlockCount(int pIdProcessSender, int pIdBlockCount)
{
    MLDV * currentMLDV= NULL;
    for (int k=0; k< this->listCausalBlocks->listProcess[pIdProcessSender]->MLDVi.size(); k++)
    {
        currentMLDV = this->listCausalBlocks->listProcess[pIdProcessSender]->MLDVi[k];
        if (currentMLDV->idBlockCount ==pIdBlockCount)
        {
            currentMLDV->setValueLDVByProcess(pIdProcessSender, pIdBlockCount);
        }
    }

}

bool CausalBlocks:: lvdReceiveIsLastLdvReceived(vector<int> pLdvi, int pIdProcess)
{
    MLDV *mldv=NULL;
    bool result = true;
    mldv = listCausalBlocks->getCurrentMLDVi(pIdProcess);
    for (int i=0; i< mldv->LDVi.size();i++)
    {
       if(mldv->LDVi[i]!=pLdvi[i])
       {
         result = false;
         break;

       }
    }
    return result;

}

void CausalBlocks:: receiveMsgNULLWithCausalBlocks(cMessage *msg, unsigned int pMsgType)
{
    MessageBlock * pacoteMSGRecebida = dynamic_cast<MessageBlock*>(msg);
    MessageBlock *msgSchedule= NULL;
    MsgByProcess *msgBlock = NULL;
    MLDV* newMLDV = new MLDV();
    char* textmsg= NULL;
    char* nomeRemetente= NULL;
    int idRemetente= -1;
    int idBCRemetente =-1;
    int idMsgRemetente;
    Block* blockLocate=NULL;
    Process* process = NULL;
    vector<int> ldv;
    vector<int> ldvRecoveredMessages;
    double timeReceive, timeReceiveSimulator;

    try
        {

        textmsg = (char*)pacoteMSGRecebida->getText();
        nomeRemetente= (char*)pacoteMSGRecebida->getNomeRemetente();
        idRemetente = pacoteMSGRecebida->getIdRemetente();
        idBCRemetente = pacoteMSGRecebida->getIdBC();
        idMsgRemetente = pacoteMSGRecebida->getId();
        ldv= getLDViInPacoteMsgBlock(ldv ,pacoteMSGRecebida,listCausalBlocks->vectorLVD);
        process = listCausalBlocks->getProcess(idRemetente);
        timeReceive = getCurrentTime();
        timeReceiveSimulator = SIMTIME_DBL(simTime());
        ldvRecoveredMessages = getLDViInPacoteMsgBlock(ldvRecoveredMessages ,pacoteMSGRecebida, listCausalBlocks->vectorLVDReceivedMessages);


        cout <<"\n receive msg NULL idProcessoRemetente= "<<idRemetente;

        //Configura o Bloco Causal, antes do envio da Mensagem
        if(!isMessageLocal(pacoteMSGRecebida))
        {

            if((this->listCausalBlocks!=NULL))
            {
                blockLocate = this->listCausalBlocks->findOrAddNewBlock(idBCRemetente);
                listCausalBlocks->MarkBlockPerMsgPerProcess(idMsgRemetente,textmsg, idBCRemetente,
                process->id, blockLocate,timeReceive,timeReceiveSimulator, false, false,false);

                //Atualiza o MBVi
                listCausalBlocks->updateMBVi(idRemetente,idBCRemetente);
                //cout<< "MLDV OLD";
                //printMLDViAllProcess();

                listCausalBlocks->addLDVInMLDV(ldv, process->id, idBCRemetente, true, true);
                //updateMLDVByBlockCount(process->id, idBCRemetente);
                //updateMLDVByBlockCountOfLDVi(ldv, process);

                //cout<< "MLDV New";
                //printMLDViAllProcess();



                //Faz a verificação da necessidade de retransmissão
                messageRecovery();
                cout<<"\n\ ----------------------------------------";
            }
        }
    }
    catch (const std::exception& e)
    {cout<<"Erro função receiveMsgApplWithCausalBlocks";}

}

void CausalBlocks::updateMLDVByBlockCountOfLDVi(vector<int> pLdv, Process* pIdProcSender)
{
    MLDV * currentMLDV= NULL;
    for (int k=0; k< pIdProcSender->MLDVi.size(); k++)
    {
        currentMLDV = pIdProcSender->MLDVi[k];
        for(int p=0;p<currentMLDV->LDVi.size();p++)
        {
           if (currentMLDV->idBlockCount ==pLdv[p])
           {
              currentMLDV->setValueLDVByProcess(p, pLdv[p]);
           }
        }
    }

}


Block *CausalBlocks:: managerDeliveryBlocksInControlesStatistic(char * pNameFunction, Block *pBlock, MessageBlock * pPacoteMSGRecebida)
{
    MsgByProcess *msgAtual=NULL;
    Block *causalBlock=NULL;

    if (pBlock->getIsDelivery())
    {
        cout<< "\n====>Função ("<<pNameFunction<<") Delivery bloco= "<< pBlock->idBlockCount
            << " Processo Local="<< idProcesso;

        ////
        for(int i=0; i< pBlock->ListMsgByProcess.size(); i++)
        {
          msgAtual = dynamic_cast<MsgByProcess*>(pBlock->ListMsgByProcess[i]);
          getControlStatistic()->addTimeDeliveryInMSG(msgAtual->id,
          pBlock->timeDelivery, pBlock->timeDeliverySimulator, idProcesso);
          cout<<"\n entrega do Bloco ==timeDelivery="<<pBlock->timeDeliverySimulator;
        }
    }

}

MessageBlock *CausalBlocks:: createPackageToSend(MsgByProcess *pMSGFromProcess, char *pNameMSG,
   unsigned int pMsgType, int pNumTotalOfMSg, int pIdProcessoRemetente, int pIdProcessReplay)
{
    MessageBlock * pacoteMsgBlock = new MessageBlock();

    this->populateWSM(pacoteMsgBlock);


    //Configura o contador Global de envio daMensagem

    //this->countMSGSend++

    pacoteMsgBlock->setIdRemetente(pIdProcessoRemetente);
    pacoteMsgBlock->setIdSenderReplay(pIdProcessReplay);
    pacoteMsgBlock->setId(pMSGFromProcess->id);
    pacoteMsgBlock->setIdBC(pMSGFromProcess->idBC);
    pacoteMsgBlock->setNomeRemetente(getName());
    pacoteMsgBlock->setName(pNameMSG);
    pacoteMsgBlock->setText(pMSGFromProcess->text);
    insertLDViInPacoteMsgBlock(this->listCausalBlocks->LDVi,pacoteMsgBlock);
    pacoteMsgBlock->setKind(pMsgType);

    return pacoteMsgBlock;

}

MessageBlock *CausalBlocks:: createPackageToSend(MessageBlock* pMsgSchedule, unsigned int pMsgType )
{
    MessageBlock * pacoteMsgBlock = new MessageBlock();

    this->populateWSM(pacoteMsgBlock);


    //Configura o contador Global de envio daMensagem

    //this->countMSGSend++

    pacoteMsgBlock->setIdRemetente(pMsgSchedule->getIdRemetente());
    pacoteMsgBlock->setId(pMsgSchedule->getId());
    pacoteMsgBlock->setIdBC(pMsgSchedule->getIdBC());
    pacoteMsgBlock->setNomeRemetente(getName());
    pacoteMsgBlock->setName(pMsgSchedule->getName());
    pacoteMsgBlock->setText(pMsgSchedule->getText());
    insertLDViInPacoteMsgBlock(this->listCausalBlocks->LDVi,pacoteMsgBlock);
    pacoteMsgBlock->setKind(pMsgType);
    insertLDVRecoverdMessagesInPackage(this->listCausalBlocks->LDViRecoveredMessages,pacoteMsgBlock);

    return pacoteMsgBlock;
}


void CausalBlocks::insertLDViInPacoteMsgBlock(vector<int> LDVi, MessageBlock * pacoteMsgBlock)
{

  pacoteMsgBlock->setLdvArraySize(LDVi.size());
  for(int i=0; i<LDVi.size();i++)
  {
    pacoteMsgBlock->setLdv(i,LDVi[i]);

  }
}

void CausalBlocks::insertLDViInBeacon(vector<int> LDVi, MessageBeaconCausalBlock * pMsgBeacon)
{

    pMsgBeacon->setLdvArraySize(LDVi.size());
  for(int i=0; i<LDVi.size();i++)
  {
      pMsgBeacon->setLdv(i,LDVi[i]);

  }
}

void CausalBlocks::insertLDVRecoverdMessagesInBeacon(vector<int> pLDVRecoveredMessages, MessageBeaconCausalBlock * pMsgBeacon)
{

    pMsgBeacon->setLdvRecoveredMessagesArraySize(pLDVRecoveredMessages.size());
    for(int i=0; i<pLDVRecoveredMessages.size();i++)
    {
       pMsgBeacon->setLdvRecoveredMessages(i,pLDVRecoveredMessages[i]);

    }
}

void CausalBlocks::insertLDVRecoverdMessagesInPackage(vector<int> pLDVRecoveredMessages, MessageBlock * pacoteMsgBlock)
{

    pacoteMsgBlock->setLdvRecoveredMessagesArraySize(pLDVRecoveredMessages.size());
    for(int i=0; i<pLDVRecoveredMessages.size();i++)
    {
        pacoteMsgBlock->setLdvRecoveredMessages(i,pLDVRecoveredMessages[i]);

    }
}


vector<int> CausalBlocks::getLDViInPacoteMsgBlock(vector<int> LDVi, MessageBlock * pacoteMsgBlock, int pKindVector)
{
  if (pKindVector ==this->listCausalBlocks->vectorLVD)
  {
    for(int i=0; i<pacoteMsgBlock->getLdvArraySize();i++)
    {
        LDVi.push_back(pacoteMsgBlock->getLdv(i));
    }
    return LDVi;
  }
  if (pKindVector==this->listCausalBlocks->vectorLVDReceivedMessages)
  {
     for(int i=0; i<pacoteMsgBlock->getLdvArraySize();i++)
     {
        LDVi.push_back(pacoteMsgBlock->getLdv(i));
     }
     return LDVi;
  }
}

vector<int> CausalBlocks::getVectorInBeacon(vector<int> pVector, MessageBeaconCausalBlock * pMsgBeacon, int pKindVector)
{
  if (pKindVector == this->listCausalBlocks->vectorLVD)
  {
    for(int i=0; i<pMsgBeacon->getLdvArraySize();i++)
    {
        pVector.push_back(pMsgBeacon->getLdv(i));
    }
  }
  else if (pKindVector == this->listCausalBlocks->vectorLVDReceivedMessages)
  {
     for(int i=0; i<pMsgBeacon->getLdvRecoveredMessagesArraySize();i++)
     {
          pVector.push_back(pMsgBeacon->getLdvRecoveredMessages(i));
     }
   }


   return pVector;
}




void CausalBlocks::printMLDViAllProcess()
{  Process *process= this->listCausalBlocks->getProcess(this->idProcesso);

Process *proPesq;
    cout<<"\n   ----Process Atual---------\n";
    listCausalBlocks->printMLDVi(process);
    cout<<"\n Demais Processos do Grupo Atual\n";
    for(int i=0; i<this->listCausalBlocks->listProcess.size();i++)
    {
       if (i!= process->id)
       {
         proPesq = listCausalBlocks->getProcess(i);
         listCausalBlocks->printMLDVi(proPesq);
       }


    }


}

MessageBlock * CausalBlocks::addMsgWithCausalBlocks(cMessage *msg, unsigned int pMsgType)
{

      MessageBlock * pacoteMsgBlock = new MessageBlock();
      MessageBlock *msgSchedule = dynamic_cast<MessageBlock*>(msg);

      Block *causalBlock = NULL;
      MsgByProcess *msglBlock;
      char* textmsg= " MSG BC";
      int countMsgs;
      int idNewBC=-1;
      time_t timeSend = getCurrentTime();
      time_t timeRequestReplay, timeEndReplay;
      double timeOfSimulator;
      int qtdProcess=0;
      Process *process = listCausalBlocks->getProcess(this->idProcesso);
      Process *proPesq=NULL;

      try
      {
        //Configura o Bloco Causal, antes do envio da Mensagem
        if(this->listCausalBlocks!=NULL)
        {  qtdProcess= listCausalBlocks->listProcess.size();
           int arrayLdviOld[qtdProcess];
           //Incrementa um novo BlockCount
           this->listCausalBlocks->incrementaBlockCount();
           idNewBC = this->listCausalBlocks->getBlockCount();

           //Cria um novo Bloco Causal dentro do bloco causal recém criado
           causalBlock = this->listCausalBlocks->findOrAddNewBlock(idNewBC);
           causalBlock->isSendMsg=true;
           causalBlock->isValid=true;

           textmsg = (char*)msgSchedule->getText();
           countMsgs = causalBlock->ListMsgByProcess.size()+1;
           msglBlock = causalBlock->markMsg(countMsgs, textmsg, "+",causalBlock->idBlockCount, idProcesso, true);

           //Configuração dos Dados do Bloco Causal da msg
           msglBlock->text= textmsg;
           msglBlock->idBC = causalBlock->idBlockCount;
           msglBlock->id = msgSchedule->getId();

           pacoteMsgBlock = createPackageToSend(msglBlock, "New MSG" , pMsgType, causalBlock->ListMsgByProcess.size(), this->idProcesso,this->idProcesso);
           pacoteMsgBlock->setText(textmsg);

         }
         else
         {cout<<"listCausalBlocks não criado!";}
       cout<<"\n--------------------------------------";
       }
       catch (const std::exception& e)
       {cout<<"Erro função SendMsgApplWithCausalBlocks";}

       return pacoteMsgBlock;

}



void CausalBlocks::sendMsgApplWithCausalBlocks(cMessage *msg, unsigned int pMsgType)
{
  MessageBlock * pacoteMsgBlock = new MessageBlock();
  MessageBlock *msgSchedule = dynamic_cast<MessageBlock*>(msg);
  MsgByProcess *msgByProcess=NULL;

  Block *causalBlock = NULL;
  char* textmsg= " MSG BC";
  time_t timeSend = getCurrentTime();
  time_t timeRequestReplay, timeEndReplay;
  double timeOfSimulator=SIMTIME_DBL(simTime());




  try
  {
    //Configura o Bloco Causal, antes do envio da Mensagem
    if(this->listCausalBlocks!=NULL)
    {  cout<<"\n\n--------------Enviando time= "<< SIMTIME_DBL(simTime())<<"----------------";
       cout<<"\n\n proc="<<this->idProcesso<<" BC="<<msgSchedule->getIdBC()<<" idMensagem=" <<msgSchedule->getId();

       //Adiciona os dados do bloco Causal (SEND_MSG_BLOCK = Tipo para demarcar que a msg foi enviada e poderá ser recebida
       pacoteMsgBlock = addMsgWithCausalBlocks(msgSchedule,SHEDULE_SEND_MSG_BLOCK);

       //cout<<"\n\nMLDV Old \n";
       //printMLDViAllProcess();
       //Após montar o pacote de envio, atualiza a o LDVI da Matriz de Blocos Causais
       msgByProcess = this->listCausalBlocks->getBlock(pacoteMsgBlock->getIdBC())->getMsg(this->idProcesso);
       msgByProcess->ldvAllProcess = this->listCausalBlocks->LDVi;

       pacoteMsgBlock = createPackageToSend(pacoteMsgBlock, SEND_MSG_BLOCK);

       //cout<<"MLDV atualizado \n";
       //printMLDViAllProcess();


       //multicast m
       sendDown(pacoteMsgBlock);

       this->listCausalBlocks->updateLDV(this->idProcesso, pacoteMsgBlock->getIdBC());
       this->listCausalBlocks->addLDVInMLDV(this->listCausalBlocks->getCurrentLDVi(), this->idProcesso,pacoteMsgBlock->getIdBC(), false);


       if (this->countMsgAlreadySend >0)
           startSentMessage=true;


       //Preenche o Pacote com as Informações statisticas
       getControlStatistic()->addMSG(msgSchedule->getId(),
         this->sizeMSGsByProcesso,timeSend,timeOfSimulator,idProcesso);
       // Preenche o Pacote com as Informações statisticas sobre o Recebimento
       getControlStatistic()->addTimeReceiveInMSG(msgSchedule->getId(), timeSend, idProcesso, 0,
         timeRequestReplay, timeEndReplay,timeOfSimulator,0,0);
       getControlStatistic()->addTimeDeliveryInMSG(msgSchedule->getId(),
               timeSend, timeOfSimulator, this->idProcesso);

       //Gerencia o Delivery das Mensagens
      // this->listCausalBlocks->checkBlockComplete(causalBlock, true,timeOfSimulator,true);
      // managerDeliveryBlocksInControlesStatistic("Send",causalBlock);

     }
     else
     {cout<<"listCausalBlocks não criado!";}
   cout<<"\n--------------------------------------";
   }
   catch (const std::exception& e)
   {cout<<"Erro função SendMsgApplWithCausalBlocks";}
}

//Verifica a Regra 5.0 do artigo Um Robust Protocol
bool CausalBlocks:: relayConditionIsValid(MLDV* pCurrentMLDVI, int pBlockCount, int pIdProcessoSender)
{
  vector<MLDV*> ListaMLDVI;
  MsgByProcess *msgAtual=NULL;
  cout <<"\n      -> relayConditionIsValid ("<<this->idProcesso<<")"<< " BC= "<<pBlockCount<<" ProcessoSender="<<pIdProcessoSender;
  Block* currentBlock;
  int currentLDVIOfProcess= 0;
  bool result = false;
  int minValueMBVi = this->listCausalBlocks->getMinValueMBV();



  if (pCurrentMLDVI->LDVi.size()>=0)
  {
      currentLDVIOfProcess = pCurrentMLDVI->getValueLDV(pIdProcessoSender);
      //Regra 5.0 do artigo Um Robust Protocol
      if ( currentLDVIOfProcess <pBlockCount &&
          (pBlockCount < minValueMBVi) && (pCurrentMLDVI->idBlockCount == pBlockCount))
          result = true;
  }

  return result;

}

//Verifica a Regra 5.0 do artigo Um Robust Protocol
bool CausalBlocks:: relayConditionIsValid(int pBlockCount, int pIdProcessFind,int pIdProcMarkedAsReceived, int pIdMesg)
{
  vector<MLDV*> ListaMLDVI;
  MsgByProcess *msgAtual=NULL;
  cout <<"relayConditionIsValid ("<<this->idProcesso<<")"<< " BC= "<<pBlockCount<<" ProcessoSender="<<pIdProcessFind;
  Block* currentBlock;
  int currentLDVIOfProcess= 0;
  bool result = false;
  bool findTheBlockInProcess =false;
  Process * procLocate = NULL;
  MLDV * currentMLDV = NULL;

  int minValueMBVi = this->listCausalBlocks->getMinValueMBV();
  vector<MBV*> currentMBV;


      if (pIdProcessFind != this->idProcesso)
      {   /*int lastMLDVi= this->listCausalBlocks->listProcess[contP]->MLDVi.size()-1;
          currentMLDV = this->listCausalBlocks->listProcess[contP]->MLDVi[lastMLDVi];
          currentLDVIOfProcess = currentMLDV->getValueLDV(pIdProcessoSender);
          currentMBV = this->listCausalBlocks->MBVi;
          if ((currentLDVIOfProcess <pBlockCount &&
               pBlockCount <= minValueMBVi) )
             //    pBlockCount < minValueMBVi) && (currentMLDV->idBlockCount == pBlockCount))
          {
            result = true;
            cout <<"\n ----> relayConditionIsValid = true. BC= "<< pBlockCount<< "  Mg não recebida em "
                 << pIdProcessoSender<< " do Processo"<< contP;
            break;
          }*/

          //K começa de 1 porque todo processo é inicializado com um MLDV vazio
          for (int k=0; k< this->listCausalBlocks->listProcess[pIdProcessFind]->MLDVi.size(); k++)
          {
            currentMLDV = this->listCausalBlocks->listProcess[pIdProcessFind]->MLDVi[k];
            currentLDVIOfProcess = currentMLDV->getValueLDV(pIdProcMarkedAsReceived);

            /*//Regra 5.0 do artigo Um Robust Protocol
             * if ((currentLDVIOfProcess <pBlockCount &&
             * pBlockCount < minValueMBVi) && (currentMLDV->idBlockCount == pBlockCount))
             * //    pBlockCount < minValueMBVi) && (MLDVFind->idBlockCount!=1))
              {
                this->processResearchedWithFaulty = dynamic_cast<Process*>(this->listCausalBlocks->listProcess[contP]);
                cout <<"\n ----> relayConditionIsValid = true. BC= "<< pBlockCount<< " não recebido no processo "<< contP
                   <<" IdMsg="<<pIdMesg;
                this->MLDVFind=currentMLDV;
                return true;
                break;
              }


            */
            if (currentLDVIOfProcess == pBlockCount)
            {
              findTheBlockInProcess = true;
              break;
            }


         }
         if (!findTheBlockInProcess)
         {
           this->processResearchedWithFaulty = dynamic_cast<Process*>(this->listCausalBlocks->listProcess[pIdProcessFind]);
           return true;
         }

     }


  return result;

}

bool CausalBlocks:: isMsgLocal(MsgByProcess* pMsg)
{
   if (pMsg->idRemetente == this->idProcesso)
   {
     return true;
   }
   else
     return false;
}


void CausalBlocks::messageRecovery()
{
    /*messageRecovery analisa os ultimos LDVs recebidos pelos outros processos.
     * Ele so é executado caso o módulo esteja configurado para tolerar um percentual de falhas maior que zero,
     *
     *
     *  */

   MsgByProcess* currentMsg;
   Block* causalBlock;
   Process* processLocal = NULL;
   Process *processWithFaulty= NULL;
   int blocoTeste = 1;
   this->processResearchedWithFaulty= NULL;
   double timeReceive = 0;
   double timeReceiveSimulator =0;


   MessageBlock * pacoteMsgToSend = new MessageBlock();
   vector<int> newListProcess =listCausalBlocks->createNewVector(listCausalBlocks->listProcess.size(), 0);
   if (this->listCausalBlocks->isChangeMinMBVi)
   {
       //bool CausalBlocks:: RelayConditionIsValid(MLDV* pCurrentMLDVI, int pBlockCount, int pIdProcessoSender)
      cout<<"\n messageRecovery() ProcessoLocal"<<this->idProcesso;
      cout<<"   --->Listagem dos MLDVis";
      timeReceive = getCurrentTime();
      timeReceiveSimulator = SIMTIME_DBL(simTime());
      this->MLDVFind = NULL;
      this->MLDVFindWithFaulty =NULL;
      //printMLDViAllProcess();

      for(int contB=0; contB< this->listCausalBlocks->listBlocks.size(); contB++)
      {
          causalBlock  = dynamic_cast<Block*>(this->listCausalBlocks->listBlocks[contB]);
          for(int contProcAsMarcked=0; contProcAsMarcked< causalBlock->ListMsgByProcess.size(); contProcAsMarcked++)
          {
            currentMsg = dynamic_cast<MsgByProcess*>(causalBlock->ListMsgByProcess[contProcAsMarcked]);
            if ((currentMsg->id >0) && currentMsg->isSchedule==false /*&&(strcmp(currentMsg->status,"+")!=0)*/)
            {
                cout<<"status="<<currentMsg->status;
                if (currentMsg->id ==1 && contProcAsMarcked==0 &&  causalBlock->idBlockCount==2)
                  cout <<"teste";
                for(int contMsgFaultProcess=0; contMsgFaultProcess< causalBlock->ListMsgByProcess.size(); contMsgFaultProcess++)
                {
                    this->MLDVFind = NULL;
                    this->MLDVFindWithFaulty =NULL;
                    if (currentMsg->countRelay >2)
                      cout<<"teste";
                    if ( relayConditionIsValid(causalBlock->idBlockCount, contMsgFaultProcess,contProcAsMarcked,
                            currentMsg->id) &&  (this->numTotalRelay > 0) && (currentMsg->countRelay <  this->numTotalRelay)) //Essa ultima premissa verifica se já existe uma msg retransmitida, se houver, espera
                        //atualizar o MBVi para enviar a proxima
                    {
                        //Cancela TimeOutsanteriores para essa mesma mensagem
                        if (!existslEventSheduleOfRelay(currentMsg->idRemetente,
                                currentMsg->idBC, currentMsg->idRemetente))
                        {

                           // causalBlock->printMsgs();
                            cout<<"\n Inicia o Procedimento de Retransmissão da MSG= "<<currentMsg->id
                                    <<" BC="<<currentMsg->idBC<<" ProcFalho="<<contMsgFaultProcess << " Proc Origem="<<this->idProcesso;

                            cout<<"\n\n  ";
                            //causalBlock->printMsgs();

                            cout<<"\n MLDVi do processo Local\n ";
                            processLocal = listCausalBlocks->getProcess(this->idProcesso);
                            processWithFaulty =listCausalBlocks->getProcess(contMsgFaultProcess);
                            pacoteMsgToSend = createPackageToSend(currentMsg, "MSG Replay",SHEDULE_SEND_MSG_BLOCK_REQUEST,
                                    causalBlock->ListMsgByProcess.size(),currentMsg->idRemetente, this->idProcesso);
                            scheduleProcessRequestRelay(pacoteMsgToSend,currentMsg, timeSheduleProcessRequestRelay+ (this->idProcesso/1000) );
                            newListProcess[contMsgFaultProcess] = currentMsg->id;
                            //  MLDVFindWithFaulty =processLocal->findMLDVByProcessWithFaulty(processResearchedWithFaulty->id,
                            ///          processWithFaulty->id,contB);
                            //  if (MLDVFindWithFaulty==NULL)
                            //  {
                            ///     processLocal->addMLDVByProcessWithFaulty(processResearchedWithFaulty->id,
                            //          processWithFaulty->id,MLDVFind, fcontB);

                            //   }
                            break;

                        }//fim do ifExists
                    }//fim do if Relay


                }  //fim do for contMsgFaultProcess
            }// fim do if
          }//fim do for contProcAsMarcked

      }//fim do For
      deliveryAllMsgWithRobustProtocol(timeReceive, timeReceiveSimulator);
   }

}


void CausalBlocks:: managerDeliveryaAllBlocksInControlesStatistic(char *pNameFunction)
{
    MsgByProcess *msgAtual=NULL;

    Block *causalBlock = NULL;

    if (this->listCausalBlocks!=NULL)
    {

        for(int contB=0; contB < this->listCausalBlocks->listBlocks.size(); contB++)
        {
            causalBlock  = dynamic_cast<Block*>(this->listCausalBlocks->listBlocks[contB]);
            if (causalBlock->getIsDelivery())
            {
                cout<< "\n====>Função ("<<pNameFunction<<") Delivery bloco= "<< causalBlock->idBlockCount
                        << " Processo Local="<< idProcesso;

                for(int i=0; i< causalBlock->ListMsgByProcess.size(); i++)
                {
                    msgAtual = dynamic_cast<MsgByProcess*>(causalBlock->ListMsgByProcess[i]);
                    getControlStatistic()->addTimeDeliveryInMSG(msgAtual->id,
                            causalBlock->timeDelivery, causalBlock->timeDeliverySimulator, idProcesso);
                    cout<<"\n entrega do Bloco ==timeDelivery="<<causalBlock->timeDeliverySimulator;
                }
            }
        }
    }
}


void CausalBlocks::handleLowerMsg(cMessage* msg) {

    WaveShortMessage* wsm = dynamic_cast<WaveShortMessage*>(msg);
    ASSERT(wsm);

    if (BasicSafetyMessage* bsm = dynamic_cast<BasicSafetyMessage*>(wsm)) {
        receivedBeacons++;
        onBSM(bsm);
    }

    delete(msg);
}


void CausalBlocks:: sendMsgBeaconApp(cMessage* msg)
{
    //Gera um novo Block Count para demarcar este envio
    //Incrementa um novo BlockCount
    this->listCausalBlocks->incrementaBlockCount();
    int idNewBC = this->listCausalBlocks->getBlockCount();
    this->listCausalBlocks->updateMBVi(this->idProcesso, idNewBC);
    //Gera um novo Block Count

    generatedBeacons++;
    MessageBeaconCausalBlock* bsm = new MessageBeaconCausalBlock("BeaconCausalBlocks", SEND_BEACON_EVT);
    if (this->idProcesso==1)
      cout<<"Teste";
    insertLDViInBeacon(this->listCausalBlocks->LDVi,bsm);
    insertLDVRecoverdMessagesInBeacon(this->listCausalBlocks->LDViRecoveredMessages,bsm);

    bsm->setIdRemetente(this->idProcesso);
    bsm->setIdBC(idNewBC);
    populateWSM(bsm);
    sendDown(bsm);
}

void CausalBlocks:: receiveMsgBeaconApp(cMessage* msg)
{   int idRemetente= -1;
    int idBCRemetente =-1;
    vector<int> ldv;
    vector<int> ldvRecoveredMessages;
    Process* processSender = NULL;
    Process* processLocal = NULL;
    MLDVWithFaulty* MLDVWithFaultyLocated= NULL;

    try
      {
          MessageBeaconCausalBlock* msgBeacon = dynamic_cast<MessageBeaconCausalBlock*>(msg);
          cout<< "\n Receive Beacon proc="<<this->idProcesso<<" time="<<simTime().dbl()
                  <<" ProcSender="<<msgBeacon->getIdRemetente();

          receivedBeacons++;

           idRemetente = msgBeacon->getIdRemetente();
           idBCRemetente = msgBeacon->getIdBC();

           //Recebe o último vetor entregue e  o ultimo vetor da mensagem recuperada. Este último serve para demarcar o recebimento
           //de um processo que foi definido com falha
           ldv= getVectorInBeacon(ldv ,msgBeacon, listCausalBlocks->vectorLVD);
           ldvRecoveredMessages = getVectorInBeacon(ldvRecoveredMessages ,msgBeacon, listCausalBlocks->vectorLVDReceivedMessages);
           processSender = listCausalBlocks->getProcess(idRemetente);
           processLocal= listCausalBlocks->getProcess(this->idProcesso);

           if (this->idProcesso==0 &&  idRemetente==1)
             cout<<"Teste";

           //Atualiza o MBVi
           listCausalBlocks->updateMBVi(idRemetente,idBCRemetente);
           /* O códigoabaixo atualiza o último vetor recebido(MBVi) e matriz de LDV de cada processo
            *
            * */
           //cout<< "MLDV OLD";
           //printMLDViAllProcess();
           listCausalBlocks->addLDVInMLDV(ldv, processSender->id, idBCRemetente, true, true);
           listCausalBlocks->addLDVInMLDV(ldvRecoveredMessages, processSender->id, idBCRemetente, true, true);

           //cout<< "MLDV New";
           //printMLDViAllProcess();

           /* //VErifica de há na matriz de LDV com falhas, algum processo que deveria demarcar o recebimento
            *de uma msg ausente. Se houver, atualiza este vetor, informando que já recebeu a msg.
            *  */
           findAndUpdateLDVInMLDVWithFaulty(idRemetente, ldv, idBCRemetente, -1);

           messageRecovery();

           cout <<"\n receive msg NULL idProcessoRemetente= "<<idRemetente;
       }
       catch (const std::exception& e)
       {cout<<"Erro função receiveMsgApplWithCausalBlocks";}
}

void CausalBlocks::findAndUpdateLDVInMLDVWithFaulty(int pIdProcessoSender, vector <int>pLDVi, int pBlockCount,
     int pIdMsg)
{
    MLDVWithFaulty* MLDVWithFaultyLocated= NULL;
    Process *processSender= listCausalBlocks->getProcess(pIdProcessoSender);

    for (int i=0;i< pLDVi.size();i++ )
    {
        MLDVWithFaultyLocated = processSender->findMLDVByProcessWithFaulty(pIdProcessoSender,
                i,pLDVi[i]);
       if (MLDVWithFaultyLocated !=NULL)
       {
          processSender->updateMLDVOfProcessWithFaulty(pIdProcessoSender,i, MLDVWithFaultyLocated, pLDVi[i], pIdMsg);
       }
    }

}



void CausalBlocks::handleSelfMsg(cMessage* msg) {
    switch (msg->getKind())
    {
      case SEND_BEACON_EVT:
      {
        BasicSafetyMessage* bsm = new BasicSafetyMessage();
        populateWSM(bsm);
        sendDown(bsm);
        scheduleAt(simTime() + beaconInterval, sendBeaconEvt);
        break;
      }

    }
}



void CausalBlocks::onWSA(WaveServiceAdvertisment* wsa) {

}

void CausalBlocks::onBSM(BasicSafetyMessage* bsm) {
    //Your application has received a beacon message from another car or RSU
    //code for handling the message goes here
}

void CausalBlocks::onWSM(WaveShortMessage* wsm) {
    //Your application has received a data message from another car or RSU
    //code for handling the message goes here, see TraciDemo11p.cc for examples
  //  ICMessage * icm;
//    if (icm = dynamic_cast<ICMessage*>(wsm)) onWSM(icm);
    cout<<"\n Teste onWSM id"<< wsm->getId();
    this-> sendDown(wsm);
}


