//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "TimelinessChannel.h"

TimelinessChannel::TimelinessChannel(Channel *c, double dataValidity) {
    // TODO Auto-generated constructor stub
    this->c = c;
    update(dataValidity);
}


TimelinessChannel::~TimelinessChannel() {
    // TODO Auto-generated destructor stub
    delete(this);
}



/*double TimelinessChannel::calcValidity(double dataValidity){
    double validity=0;
    double maxRelativeSpeed;
    double vslr;
    Coord s, d;

     if (c->isNeighbors()) // && (s.x!=0.0 && s.y!=0.0 && d.x!=0.0 && d.y!=0.0)
    {
        s = c->getAgentS()->getMobilityInfo()->getMove()->getCurrentPosition();
        d = c->getAgentD()->getMobilityInfo()->getMove()->getCurrentPosition();

        vslr = fabs(c->getCalcRadius() - this->c->getChannelMobility()->getDistancelr(c->getAgentS()->getMobilityInfo()->getMove(), c->getAgentD()->getMobilityInfo()->getMove()));
        this->setSlr(vslr);
        maxRelativeSpeed = c->getAgentS()->getMobilityInfo()->getMaxSpeed() + c->getAgentD()->getMobilityInfo()->getMaxSpeed();

        this->validityNeighbor = vslr/maxRelativeSpeed;

       //std::ostringstream ost;
        //ost << "  slr: " << slr
        //     << "  STL - " << dlr << maxRelativeSpeed;
        //DBG << std::endl << ost <<  std::endl;

    }else
    {
         // value from the message - when is not neighbor

        if (validity != -1){
            this->setSlr(0);
           this->validityNeighbor = dataValidity;
        }
        //std::cout << " validity msg = " << dataValidity << endl;

    }

     if (c->getPeriodApplication()>0 && this->validityNeighbor > c->getPeriodApplication())
         this->validity = c->getPeriodApplication();
     else this->validity = this->validityNeighbor;

    return validity;

}*/

double TimelinessChannel::calcValidity(double dataValidity){
    double validity=0;

    double vslr, vslr250;
    Coord s, d, sLast, dLast;

     if (c->isNeighbors()) // && (s.x!=0.0 && s.y!=0.0 && d.x!=0.0 && d.y!=0.0)
    {
        s = c->getAgentS()->getMobilityInfo()->getMove()->getCurrentPosition();
        d = c->getAgentD()->getMobilityInfo()->getMove()->getCurrentPosition();
        sLast= c->getAgentS()->getMobilityInfo()->getLastMove()->getCurrentPosition();
        dLast =  c->getAgentD()->getMobilityInfo()->getLastMove()->getCurrentPosition();

        this->distancialr = this->c->getChannelMobility()->getDistancelr(c->getAgentS()->getMobilityInfo()->getMove(), c->getAgentD()->getMobilityInfo()->getMove());
        vslr = fabs(c->getCalcRadius() - this->distancialr);
        this->setSlr(vslr);

        //this->sense = c->getAgentS()->getMobilityInfo()->isSameSense( sLast,s, dLast,d);
        this->sense = 1;
        if ( this->sense == 1)
        {
            relativeSpeed = fabs(c->getAgentS()->getMobilityInfo()->getMove()->getSpeed() - c->getAgentD()->getMobilityInfo()->getMove()->getSpeed());
        }else{
            relativeSpeed = (c->getAgentS()->getMobilityInfo()->getMove()->getSpeed() + c->getAgentD()->getMobilityInfo()->getMove()->getSpeed());
        }

        if (relativeSpeed <1) relativeSpeed = 1; //normatizando a velocidade relativa

        maxRelativeSpeed = c->getAgentS()->getMobilityInfo()->getMaxSpeed() + c->getAgentD()->getMobilityInfo()->getMaxSpeed();


        this->validityNeighborConserv = vslr/maxRelativeSpeed;
        this->validityNeighbor = vslr/relativeSpeed;

        vslr250 = fabs(250 - this->c->getChannelMobility()->getDistancelr(c->getAgentS()->getMobilityInfo()->getMove(), c->getAgentD()->getMobilityInfo()->getMove()));
        this->slr250=vslr250;
        this->validityNeighborConserv250 = vslr250/maxRelativeSpeed;
        this->validityNeighbor250 = vslr250/relativeSpeed;
        this->validity250 = this->validityNeighborConserv250;
       //std::ostringstream ost;
        //ost << "  slr: " << slr
        //     << "  STL - " << dlr << maxRelativeSpeed;
        //DBG << std::endl << ost <<  std::endl;

    }else
    {
        /*
         * value from the message - when is not neighbor
         */
        if (validity != -1){
            this->setSlr(0);
            this->validityNeighborConserv  = dataValidity;
            this->validityNeighbor = dataValidity;
            this->validity = dataValidity;
            this->slr250=0;
            this->validityNeighborConserv250  = dataValidity;
            this->validityNeighbor250 = dataValidity;
            this->validity250 = dataValidity;
        }
        //std::cout << " validity msg = " << dataValidity << endl;

    }

    //OBSERVAR DEPOIS ESTA REGRA
    // if (c->getPeriodApplication()>0 && this->validityNeighbor > c->getPeriodApplication())
    //     this->validity = c->getPeriodApplication();
    // else this->validity = this->validityNeighbor;

    return validity;

}


void TimelinessChannel::update(double dataValidity){
    this->calcValidity(dataValidity);
    this->timeStampUpdate = simTime();
    this->calcTimeoutValidity();
    //this->calcAge();

}

void TimelinessChannel::calcTimeoutValidity()
{
    if (this->getValidity() > 0)  this->timeoutValidity = this->timeStampUpdate + this->getValidity() + c->getMessageTTime();
    else  this->timeoutValidity = 0;
    //else  this->timeoutValidity = this->timeStampUpdate + c->getMessageTTime();
}

double TimelinessChannel::calcAge()
{
    //this->age = (simTime() - c->getCurrentTMsgReceiving()).dbl();
    this->age = (simTime() - timeStampUpdate).dbl();
    return this->age;
}

std::string TimelinessChannel::info(){
    std::ostringstream ost;
    ost << "  TIMELINESS: "
        << "  VALIDITY - " << this->validity
        << "  AGE - " << this->calcAge();
    return ost.str();

}
std::string TimelinessChannel::infoTrace(bool header){

    std::ostringstream ost;
    if (header)
       ost << ";age;ageNow;timeStampUpdate;distancialr;maxRelativeSpeed;relativeSpeed;sense;slr;neighborValidityConservador; timeOutConservador; neighborValidity; timeoutValidity;slr250;neighborValidityConservador250; timeOutConservador250; neighborValidity250; timeOut250";
    else
        ost  << ";"<< this->age << ";" << this->calcAge()
        <<";"<<this->timeStampUpdate
        << ";"<< distancialr
        <<";" << maxRelativeSpeed
        << ";" << relativeSpeed
        << ";" << this->sense
        << ";" << this->slr
        <<";" << validityNeighborConserv
        << ";" << 0 //simtime_t (this->timeStampUpdate.dbl() + validityNeighborConserv)
        << ";" << validityNeighbor
        << ";" << 0//simtime_t (this->timeStampUpdate.dbl() + validityNeighbor)
        << ";" << this->slr250
        <<";" << validityNeighborConserv250
        << ";" << 0//simtime_t (this->timeStampUpdate.dbl() + validityNeighborConserv250)
        << ";" << validityNeighbor250
        << ";" << 0; //simtime_t (this->timeStampUpdate.dbl() + validityNeighbor250);


    return ost.str();
}

TimelinessChannel::TimelinessChannel() {
}

/*double TimelinessChannel::getDlr(){
    return dlr;
}

void TimelinessChannel::setDlr(double dlr) {
    this->dlr = dlr;
}
*/
double TimelinessChannel::getSlr() {
    return this->slr;
}

void TimelinessChannel::setSlr(double slr) {
    this->slr = slr;
}

double TimelinessChannel::getAgeCommState(){
    return ageCommState;
}

void TimelinessChannel::setAgeCommState(double ageCommState) {
    this->ageCommState = ageCommState;
}

double TimelinessChannel::getAgeMobilityCondition(){
    return ageMobilityCondition;
}

void TimelinessChannel::setAgeMobilityCondition(double ageMobilityCondition) {
    this->ageMobilityCondition = ageMobilityCondition;
}

double TimelinessChannel::getAgeNeighberCondition(){
    return ageNeighberCondition;
}

void TimelinessChannel::setAgeNeighberCondition(double ageNeighberCondition) {
    this->ageNeighberCondition = ageNeighberCondition;
}

simtime_t TimelinessChannel::getTimeoutValidityCommState(){
    return timeoutValidityCommState;
}

void TimelinessChannel::setTimeoutValidityCommState(
        simtime_t timeoutValidityCommState) {
    this->timeoutValidityCommState = timeoutValidityCommState;
}

simtime_t TimelinessChannel::getTimeoutValidityMobilityCondition() {
    return timeoutValidityMobilityCondition;
}

void TimelinessChannel::setTimeoutValidityMobilityCondition(
        simtime_t timeoutValidityMobilityCondition) {
    this->timeoutValidityMobilityCondition = timeoutValidityMobilityCondition;
}

simtime_t TimelinessChannel::getTimeoutValidityNeighberCondition(){
    return timeoutValidityNeighberCondition;
}

void TimelinessChannel::setTimeoutValidityNeighberCondition(
        simtime_t timeoutValidityNeighberCondition) {
    this->timeoutValidityNeighberCondition = timeoutValidityNeighberCondition;
}

simtime_t TimelinessChannel::getTimeStampUpdateCommState(){
    return timeStampUpdateCommState;
}

void TimelinessChannel::setTimeStampUpdateCommState(
        simtime_t timeStampUpdateCommState) {
    this->timeStampUpdateCommState = timeStampUpdateCommState;
}

simtime_t TimelinessChannel::getTimeStampUpdateMobilityCondition() {
    return timeStampUpdateMobilityCondition;
}

void TimelinessChannel::setTimeStampUpdateMobilityCondition(
        simtime_t timeStampUpdateMobilityCondition) {
    this->timeStampUpdateMobilityCondition = timeStampUpdateMobilityCondition;
}

simtime_t TimelinessChannel::getTimeStampUpdateNeighberCondition(){
    return timeStampUpdateNeighberCondition;
}

void TimelinessChannel::setTimeStampUpdateNeighberCondition(
        simtime_t timeStampUpdateNeighberCondition) {
    this->timeStampUpdateNeighberCondition = timeStampUpdateNeighberCondition;
}

double TimelinessChannel::getValidityCommState(){
    return validityCommState;
}

void TimelinessChannel::setValidityCommState(double validityCommState) {
    this->validityCommState = validityCommState;
}

double TimelinessChannel::getValidityMobilityCondition(){
    return validityMobilityCondition;
}

void TimelinessChannel::setValidityMobilityCondition(
        double validityMobilityCondition) {
    this->validityMobilityCondition = validityMobilityCondition;
}

double TimelinessChannel::getValidityNeighberCondition() {
    return validityNeighberCondition;
}

void TimelinessChannel::setValidityNeighberCondition(double validityNeighberCondition) {
    this->validityNeighberCondition = validityNeighberCondition;
}

double TimelinessChannel::setDigits(double _number, int _digits)
{
    double tenth = pow((double)10,_digits);
    _number *= tenth;
    _number = floor(_number);
    _number /= tenth;

    return _number;
}
