//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Icarqoc.h"

Define_Module(Icarqoc);


void Icarqoc::initialize(int stage) {
    BaseWaveApplLayer::initialize(stage);

    if (stage == 0) {

        //Initializing members and pointers of your application goes here
        EV << "Initializing " << par("appName").stringValue() << std::endl;
        this->seqMsg=0;
        this->tempNode=-1;


        if (FindModule<KnownGlobal*>::findGlobalModule())
        {
            oKnownGlobal = FindModule<KnownGlobal*>::findGlobalModule();

            //agent name = vehicle creation order
            std::stringstream aName;
            aName << oKnownGlobal->knownVehicles.size();
            this->oVision = new Vision(TraCIMobilityAccess().get(getParentModule()), this->myId, aName.str(), this->oKnownGlobal);
            oKnownGlobal->knownVehicles.push_back(this->oVision->getMyData());

            //get configuration from physic layer module
            BasePhyLayer * x = FindModule<BasePhyLayer*>::findGlobalModule();
            oKnownGlobal->oRadiusEstimatorChannel->sensitivityPower_dbm = x->getAncestorPar("sensitivity").doubleValue();
        }

        //max velocity of vehicle in m/s
        this->oVision->getMyData()->getMobilityInfo()->setMaxSpeed(par("maxSpeed").doubleValue());

        //declared radius in meters
        this->oVision->getMyData()->setSetRadius(par("radiusSet").doubleValue());

        // period of communication performance measurement
        perforMesurementPeriod = par("perforMesurementPeriod").doubleValue();

        //schedule first to measure communication performance
        cMessage *msgPer = new cMessage("commperform", MEASURE_COMM_PERFORMANCE);
        scheduleLoadApp(oKnownGlobal->startSimulation, MEASURE_COMM_PERFORMANCE, "firstLoad", msgPer);


        // vehicle amount
        vehicleAmout = oKnownGlobal->vehicleAmout;


        // general type of application
        this->vfs = oKnownGlobal->oGeneralCommunicationService;

        // period to send application messages
        loadPeriodApp = oKnownGlobal->oGeneralCommunicationService.appPeriodLoadMsg;

        //schedule first load message
        cMessage *msg = new cMessage("firstLoad", SEND_ICM_EVT);
        scheduleLoadApp(oKnownGlobal->startSimulation, SEND_ICM_EVT, "firstLoad", msg );

        //initialize trace
        if (oKnownGlobal->simulationDataheaderLine)
             dataNetwork << ";vehicleAmout;loadPeriodApp;" <<  msgInfoTraceTransmitting(NULL, "", "", true);
        else dataNetwork << "";

    }
    else if (stage == 1) {
        //Initializing members that require initialized other modules goes here

    }
}

void Icarqoc::finish() {
        this->oKnownGlobal->fileMessages << dataNetwork.str();
        this->oKnownGlobal->fileAgents << oVision->dataAgent.str();
        this->oKnownGlobal->fileChannels << oVision->dataChannel.str();
        this->oKnownGlobal->fileChannelsMinslr << oVision->dataMinslr.str();
        this->oKnownGlobal->fileCommPerformance << oVision->dataCommPerformance.str();
        BaseWaveApplLayer::finish();
}

void Icarqoc::onBSM(BasicSafetyMessage* bsm) {
    //Your application has received a beacon message from another car or RSU
    //code for handling the message goes here

}

void Icarqoc::onWSM(WaveShortMessage* wsm) {
    //Your application has received a data message from another car or RSU
    //code for handling the message goes here, see TraciDemo11p.cc for examples
    ICMessage * icm;
    if (icm = dynamic_cast<ICMessage*>(wsm)) onWSM(icm);

}

void Icarqoc::onWSM(ICMessage * wsm) {
    //Your application has received a data message from another car or RSU
    //code for handling the message goes here, see TraciDemo11p.cc for examples
    double vtime;

    if (wsm->getSourceId()!=this->myId)
    {
        this->oVision->updateVision(wsm);
        dataNetwork << ";" << this->oKnownGlobal->vehicleAmout << ";" << this->oKnownGlobal->loadPeriodApp << ";" <<  msgInfoTraceTransmitting(wsm, "receiving", "rcv" ,false);

        if (wsm->getNextId()==this->myId && wsm->getDestinationId() != this->myId
                && wsm->getHopNumber()<4)
        {
            this->sendForwardMessage(wsm);
        }
    }

}

void Icarqoc::onWSA(WaveServiceAdvertisment* wsa) {
    //Your application has received a service advertisement from another car or RSU
    //code for handling the message goes here, see TraciDemo11p.cc for examples

}

void Icarqoc::handleSelfMsg(cMessage* msg) {
    //BaseWaveApplLayer::handleSelfMsg(msg);
    //this method is for self messages (mostly timers)
    //it is important to call the BaseWaveApplLayer function for BSM and WSM transmission
    //SEND_ICM_EVT, // general event of IC Message
    //SEND/-*--_ICAR_PROTOCOL, //Data dissemination
    //SEND_FORMATION_VEHIC, // vehicular formation
    //SEND_IMAGES_STREAMS // images streams
    // MEASURE_COMM_PERFORMANCE // event to measure the environment communication performance
    switch (msg->getKind()) {
    case MEASURE_COMM_PERFORMANCE:
        // update measurement
        if (msg->getName()=="firstLoad") this->oVision->calcCommPerformVision(true);
        else this->oVision->calcCommPerformVision(false);

        this->scheduleLoadApp(this->perforMesurementPeriod, MEASURE_COMM_PERFORMANCE, "commperform", msg);
        break;

    case SEND_ICM_EVT:
        loadApp(msg);
        this->scheduleLoadApp(this->loadPeriodApp, SEND_ICM_EVT, "appMessage", msg);
        break;


    case SEND_ICAR_PROTOCOL:
        loadApp(msg);
        this->scheduleLoadApp(1.75, SEND_ICAR_PROTOCOL, "appMessage", msg);
        //this->scheduleLoadApp(1.75, SEND_ICAR_PROTOCOL, "appMessage");
        //delete (msg);
        break;

    case SEND_FORMATION_VEHIC:
            loadApp(msg);
            this->scheduleLoadApp(0.1, SEND_FORMATION_VEHIC, "appMessage", msg);
//            this->scheduleLoadApp(0.1, SEND_FORMATION_VEHIC, "appMessage");
//            delete (msg);
            break;

    case SEND_IMAGES_STREAMS:
            loadApp(msg);
            this->scheduleLoadApp(1.5, SEND_IMAGES_STREAMS, "appMessage", msg);
            //delete (msg);
            break;
   default:
        if (msg)
            DBG_APP << "APP: Error: Got Self Message of unknown kind! Name: " << msg->getName() << endl;
        break;
    }
}


void Icarqoc::receptionMsg(ICMessage* msg){

}

/*****************************************************************************************************************************************************
 * APPLICATION LOAD IN NETWORK
 ****************************************************************************************************************************************************/

void Icarqoc::loadApp(cMessage *msg)
{
    int64_t destinyNode = vfs.getDestination(this->oKnownGlobal->knownVehicles, this->myId);
    //std::cout << endl<< " destiny node" << destinyNode << std::endl;
    ForwardingNode * foward = oVision->getRouting()->getFowardNode(this->oVision->getAgentGroup(), this->oVision->getChannelList(), destinyNode,
            oVision->getMyData()->getId(), -1, vfs.timeToLive, Coord(0,0,0), Coord(0,0,0));

    //std::cout << " teste routing" << foward->getRule() << std::endl;
    sendMessageApplication(foward, destinyNode, vfs.timeToLive, vfs.appTypeId, -1, -1);

}


/**
 * @brief Change the phy layer carrier sense threshold.
 *
 * @param ccaThreshold_dBm the cca threshold in dBm
 */
void Icarqoc::scheduleLoadApp(double appPeriod, int AppTypeId, char * name, cMessage *m1)
{
    //cMessage *m1 = new cMessage(name, AppTypeId);
    if (m1->isScheduled())
        cancelEvent(m1);

    m1->setName(name);
    m1->setKind(AppTypeId);
    simtime_t s = simTime() + calcDelaySendLoadApp() + appPeriod;
    scheduleAt(s , m1);
}


/*****************************************************************************************************************************************************
 * END  -- APPLICATION LOAD IN NETWORK
 ****************************************************************************************************************************************************/




void Icarqoc::handlePositionUpdate(cObject* obj) {
    BaseWaveApplLayer::handlePositionUpdate(obj);
    //the vehicle has moved. Code that reacts to new positions goes here.
    //member variables such as currentPosition and currentSpeed are updated in the parent class
}

// ==========================================


/*
 * Calcing delay to send application load message
 */
double Icarqoc::calcDelaySendLoadApp()
{
    return ((double(rand()%10)+1)/1000);
}


/*
 *  @brief send application message
 *  @param forwarding node
 *  @param  destiny node
 *  @param  message time (time to leave)
 *  @param  message type (see enum in baseapp)
 *  @param  last node forwarding node
 *  @param  number of monitoring message)
 */

void Icarqoc::sendMessageApplication(ForwardingNode * fowardNode, int64_t destination, double timetoLive,
        unsigned int pMsgType, int64_t lastNodeNext,
        int64_t numMonitoringMsg)
{
        //preparing transmition wsm message
        ICMessage * wsm = new ICMessage();

        this->populateWSM(wsm);
        wsm->setKind(pMsgType);


        //prepareing icmessage
        wsm->setMsgType(pMsgType);
        wsm->setNumMsg(seqMsg++);
        wsm->setName("data");

        // data transmitter
        wsm->setAntecessoPosTimeStamp(this->oVision->getMyData()->getMobilityInfo()->getMove()->getStartTime());
        wsm->setAntecessorMaxSpeed(this->oVision->getMyData()->getMobilityInfo()->getMaxSpeed());
        wsm->setAntecessorMsgTimeStamp(simTime());
        //wsm->setAntecessorRadius(this->oVision->getMyData()->getSetRadius());
        wsm->setAntecessorSpeed(this->oVision->getMyData()->getMobilityInfo()->getMove()->getSpeed());
        wsm->setAntecessorX(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().x);
        wsm->setAntecessorY(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().y);
        wsm->setAntecessorZ(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().z);

        // data source
        wsm->setSourceMaxSpeed(this->oVision->getMyData()->getMobilityInfo()->getMaxSpeed());
        wsm->setSourceMsgTimeStamp(simTime());
        wsm->setSourcePosTimeStamp(this->oVision->getMyData()->getMobilityInfo()->getMove()->getStartTime());
        //wsm->setSourceRadius(this->oVision->getMyData()->getSetRadius());
        wsm->setSourceSpeed(this->oVision->getMyData()->getMobilityInfo()->getMove()->getSpeed());
        wsm->setSourceX(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().x);
        wsm->setSourceY(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().y);
        wsm->setSourceZ(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().z);
        wsm->setSourceId(this->oVision->getMyData()->getId());
        wsm->setAntecessorId(this->oVision->getMyData()->getId());

        // data destination
        wsm->setDestinationId(destination);
        RemoteAgent * ra = this->oVision->getAgentGroup()->getRemoteAgent(destination);
        if (ra!=NULL)
            if (ra->getId()!=-1){
                wsm->setDestinationMaxSpeed(ra->getMobilityInfo()->getMaxSpeed());
                wsm->setDestinationPosTimeStamp(ra->getMobilityInfo()->getMove()->getStartTime());
                //wsm->setDestinationRadius(ra->getSetRadius());
                wsm->setDestinationSpeed(ra->getMobilityInfo()->getMove()->getSpeed());
                wsm->setDestinationX(ra->getMobilityInfo()->getMove()->getCurrentPosition().x);
                wsm->setDestinationY(ra->getMobilityInfo()->getMove()->getCurrentPosition().y);
                wsm->setDestinationZ(ra->getMobilityInfo()->getMove()->getCurrentPosition().z);
            }

        //wsm->setMsgLifeTime(timetoLive);
        wsm->setMsgLifeTime(simTime() + timetoLive);
        wsm->setWsmVersion(1);
        wsm->setTimestamp(simTime());
        //wsm->setHopNumber(0);
        wsm->setHopNumber(1);

         // next data
        std::string ruleRouting="";
        if (fowardNode!= NULL)
        {
            if (fowardNode->getFowardId() != -1)
            {
                wsm->setNextId(fowardNode->getFowardId());
                wsm->setValidityDataTimeStamp(fowardNode->getTimeoutValidity());
                wsm->setAnteNextValidityTimeStamp(fowardNode->getTimeoutValidity());
                ruleRouting = fowardNode->getRule();

                //std::cout << std::endl << ruleRouting << "  node forward - " << fowardNode->getFowardId() << "   local - " << this->myId << "   source- " << wsm->getSourceId() << "   destino- " << destination << endl;

                RemoteAgent * rm = this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId());

                if (rm != NULL){
                //wsm->setNextRadius(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getSetRadius());
                //std::cout << std::endl << "  aqui - ";
                wsm->setNextSpeed(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getSpeed());
                wsm->setNextMaxSpeed(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMaxSpeed());
                wsm->setNextPosTimeStamp(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getStartTime());
                wsm->setNextX(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getCurrentPosition().x);
                wsm->setNextY(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getCurrentPosition().y);
                wsm->setNextZ(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getCurrentPosition().z);
                }
            } else{
                wsm->setNextId(-1);

                ruleRouting = "-1";
            }

        }
        else {
            wsm->setNextId(-1);
            wsm->setValidityDataTimeStamp(-1);
            wsm->setAnteNextValidityTimeStamp(-1);
            ruleRouting = "-1";
        }

        wsm->addByteLength(((string)wsm->getWsmData()).size());
        wsm->setWsmLength(((string)wsm->getWsmData()).size());

        sendICMessage(wsm, "transmitting", ruleRouting ,false);
}



void Icarqoc::sendForwardMessage(ICMessage* pWsm)
{
    //ICMessage * wsm = pWsm;
    //preparing transmition wsm message
    //if (fowardNode->getTimeoutValidity() < simTime() || pWsm->getValidityDataTime()==-1 || pWsm->getMsgLifeTime() < simTime())
   // if (pWsm->getMsgLifeTime() < simTime())
   //     dataNetwork << ";" << this->oKnownGlobal->vehicleAmout << ";" << this->oKnownGlobal->loadPeriodApp << ";" <<   msgInfoTraceTransmitting(pWsm, "NOTforwarding", "99" ,false);
   //  else
    {

         // vtime = simTime().dbl()-wsm->getValidityDataTime().dbl();
          //if (vtime < 0) vtime = -1;

          //oVision->getRouting()->setValidityTime(vtime);
          ForwardingNode * fowardNode =  oVision->getRouting()->getFowardNode(oVision->getAgentGroup(), oVision->getChannelList(),
                  pWsm->getDestinationId(), oVision->getMyData()->getId(), pWsm->getAntecessorId(), pWsm->getMsgLifeTime().dbl(), Coord(0,0,0), Coord(0,0,0));

            ICMessage * wsm = new ICMessage();

            this->populateWSM(wsm);
            wsm->setKind(pWsm->getKind());
            wsm->setAntecessoPosTimeStamp(this->oVision->getMyData()->getMobilityInfo()->getMove()->getStartTime());
            wsm->setAntecessorMaxSpeed(this->oVision->getMyData()->getMobilityInfo()->getMaxSpeed());
            wsm->setAntecessorMsgTimeStamp(simTime());

            //wsm->setAntecessorRadius(this->oVision->getMyData()->getSetRadius());
            wsm->setAntecessorSpeed(this->oVision->getMyData()->getMobilityInfo()->getMove()->getSpeed());
            wsm->setAntecessorX(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().x);
            wsm->setAntecessorY(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().y);
            wsm->setAntecessorZ(this->oVision->getMyData()->getMobilityInfo()->getMove()->getCurrentPosition().z);
            wsm->setAntecessorId(this->oVision->getMyData()->getId());
            wsm->setHopNumber(pWsm->getHopNumber()+1);


            // forwarding data
            std::string ruleRouting="";
             if (fowardNode!= NULL)
             {
                 if (fowardNode->getFowardId() != -1)
                 {

                     wsm->setNextId(fowardNode->getFowardId());

                     if (fowardNode->getTimeoutValidity() < pWsm->getValidityDataTimeStamp() || pWsm->getValidityDataTimeStamp()==-1 )
                         wsm->setValidityDataTimeStamp(fowardNode->getTimeoutValidity());

                     wsm->setAnteNextValidityTimeStamp(fowardNode->getTimeoutValidity());
                     wsm->setNextId(fowardNode->getFowardId());

                     ruleRouting = fowardNode->getRule();
                     std::cout << endl << "rule sending" << ruleRouting << endl;
                     //wsm->setNextRadius(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getSetRadius());
                     wsm->setNextMaxSpeed(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMaxSpeed());
                     wsm->setNextSpeed(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getSpeed());
                     wsm->setNextPosTimeStamp(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getStartTime());
                     wsm->setNextX(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getCurrentPosition().x);
                     wsm->setNextY(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getCurrentPosition().y);
                     wsm->setNextZ(this->oVision->getAgentGroup()->getRemoteAgent(fowardNode->getFowardId())->getMobilityInfo()->getMove()->getCurrentPosition().z);
                 }else{
                     wsm->setNextId(-1); //melhorar esta condicional -- est� repetitiva
                     wsm->setAnteNextValidityTimeStamp(-1);
                 }
             }else {
                 wsm->setNextId(-1); // melhorar esta condicional -- est� repetitiva
                 wsm->setAnteNextValidityTimeStamp(-1);
                 ruleRouting = "-1";
             }



             // destination data
               RemoteAgent * rd = this->oVision->getAgentGroup()->getRemoteAgent(pWsm->getDestinationId());
               if (rd!=NULL)
                   if (rd->getId()!=-1 && wsm->getDestinationPosTimeStamp() < rd->getMobilityInfo()->getMove()->getStartTime()) {
                       wsm->setDestinationMaxSpeed(rd->getMobilityInfo()->getMaxSpeed());
                       wsm->setDestinationPosTimeStamp(rd->getMobilityInfo()->getMove()->getStartTime());
                       wsm->setDestinationSpeed(rd->getMobilityInfo()->getMove()->getSpeed());
                       wsm->setDestinationX(rd->getMobilityInfo()->getMove()->getCurrentPosition().x);
                       wsm->setDestinationY(rd->getMobilityInfo()->getMove()->getCurrentPosition().y);
                       wsm->setDestinationZ(rd->getMobilityInfo()->getMove()->getCurrentPosition().z);
                   }


               // source data
                 RemoteAgent * rs = this->oVision->getAgentGroup()->getRemoteAgent(wsm->getSourceId());
                 if (rs!=NULL)
                     if (rs->getId()!=-1 && pWsm->getSourcePosTimeStamp() < rs->getMobilityInfo()->getMove()->getStartTime()) {
                         wsm->setDestinationMaxSpeed(rs->getMobilityInfo()->getMaxSpeed());
                         wsm->setDestinationPosTimeStamp(rs->getMobilityInfo()->getMove()->getStartTime());
                         wsm->setDestinationSpeed(rs->getMobilityInfo()->getMove()->getSpeed());
                         wsm->setDestinationX(rs->getMobilityInfo()->getMove()->getCurrentPosition().x);
                         wsm->setDestinationY(rs->getMobilityInfo()->getMove()->getCurrentPosition().y);
                         wsm->setDestinationZ(rs->getMobilityInfo()->getMove()->getCurrentPosition().z);
                     }

                 //cout << ";AQUI" << this->oKnownGlobal->vehicleAmout << ";" << this->oKnownGlobal->loadPeriodApp << ";" <<   msgInfoTraceTransmitting(wsm, "forwarding", ruleRouting ,false);
                 sendICMessage(wsm, "forwarding", ruleRouting ,false);
        }
}

void Icarqoc::sendICMessage(ICMessage * wsm)
{
      sendDown(wsm);
}


void Icarqoc::sendICMessage(ICMessage * wsm, std::string evento, std::string ruleRoute, bool header)
{
    dataNetwork << ";" << this->oKnownGlobal->vehicleAmout << ";" << this->oKnownGlobal->loadPeriodApp << ";" << msgInfoTraceTransmitting(wsm, evento, ruleRoute ,header);
    sendICMessage(wsm);
}

void Icarqoc::receiveSignal(cComponent* source, simsignal_t signalID, cObject* obj, cObject* details){
    BaseWaveApplLayer::receiveSignal(source, signalID, obj, details);
    Enter_Method_Silent();
    if (signalID == mobilityStateChangedSignal)
    {
       // std::cout << endl<< "name="<< this->oVision->getMyData()->getAgentName()
       //         << "   id="<< this->oVision->getMyData()->getId() << "  pos: " << this->oVision->getMyData()->getLocalMobility()->getCurrentPosition();
        this->oVision->changeLocalMobility();
    }
}

/*
 *
 */

std::string Icarqoc::msgInfoTraceTransmitting(ICMessage * wsm, std::string evento, std::string ruleRoute, bool header)
{
    std::ostringstream ost;
    if (header){
        ost      << "event"
                 << ";printTime"
                 << ";timestampMSG"
                 << ";local id"
                 << ";local name"
                 //<< oVision->getMyData()->infoTrace(header)
                 << ";messageNumber"
                 << ";Name"
                 << ";MsgType"
                 << ";MsgLifeTime"

                 << ";RuleRoute"
                 << ";ValidityRouteTime"
                 << ";hopNumber"
                // << ";SourceName"
                 << ";SourceId"
                // << ";AntecessorName"
                 << ";AntecessorId"
                 //<< ";NextName"
                 << ";NextId"
                // << ";DestinationName"
                 << ";DestinationId"

                 << ";AntecessorMsgTimeStamp"
                 << ";AntecessorPostime"
                 << ";AntecessorMaxSpeed"
                 //<< ";AntecessorRadius"
                 << ";AntecessorSpeed"
                 << ";AntecessorX"
                 << ";AntecessorY"
                 << ";AntecessorZ"
                 << ";AnteNextValidityTimeStamp"

                 << ";SourceMsgTimeStamp"
                 << ";SourcePosTimeStamp"
                 << ";SourceMaxSpeed"
                 << ";SourceRadius"
                 //<< ";SourceSpeed"
                 << ";SourceX"
                 << ";SourceY"
                 << ";SourceZ"

                 << ";NextPosTimeStamp"
                 << ";NextMaxSpeed"
                 //<< ";NextRadius"
                 << ";NextSpeed"
                 << ";NextX"
                 << ";NextY"
                 << ";NextZ"


                 << ";DestinationPosTimeStamp"
                 << ";DestinationMaxSpeed"
                 //<< ";DestinationRadius"
                 << ";DestinationSpeed"
                 << ";DestinationX"
                 << ";DestinationY"
                 << ";DestinationZ"


                 << ";Msgdata" << std::endl;
    } else {
        ost     <<  evento
                << ";" << simTime()
                << ";" << wsm->getTimestamp()
                << ";" << oVision->getMyData()->getId()
                << ";" << oVision->getMyData()->getAgentName()
                //<< oVision->getMyData()->infoTrace(header)
                << ";" << wsm->getNumMsg()
                << ";" << wsm->getName()
                << ";" << wsm->getMsgType()
                << ";" << wsm->getMsgLifeTime()

                << ";" << ruleRoute
                << ";"<< wsm->getValidityDataTimeStamp()
                << ";" << wsm->getHopNumber()
               // << ";" << wsm->getSourceName()
                << ";" << wsm->getSourceId()
               // << ";" << wsm->getAntecessorName()
                << ";" << wsm->getAntecessorId()
               // << ";" << wsm->getNextName()
                << ";" << wsm->getNextId()
               // << ";" << wsm->getDestinationName()
                << ";" << wsm->getDestinationId()

                << ";" << wsm->getAntecessorMsgTimeStamp()
                << ";" << wsm->getAntecessoPosTimeStamp()
                << ";" << wsm->getAntecessorMaxSpeed()

                << ";" << wsm->getAntecessorSpeed()
                << ";" << wsm->getAntecessorX()
                << ";" << wsm->getAntecessorY()
                << ";" << wsm->getAntecessorZ()
                << ";" << wsm->getAnteNextValidityTimeStamp()

                << ";" << wsm->getSourceMsgTimeStamp()
                << ";" << wsm->getSourcePosTimeStamp()
                << ";" << wsm->getSourceMaxSpeed()
                //<< ";" << wsm->getSourceRadius()
                << ";" << wsm->getSourceSpeed()
                << ";" << wsm->getSourceX()
                << ";" << wsm->getSourceY()
                << ";" << wsm->getSourceZ()

                << ";" << wsm->getNextPosTimeStamp()
                << ";" << wsm->getNextMaxSpeed()
               // << ";" << wsm->getNextRadius()
                << ";" << wsm->getNextSpeed()
                << ";" << wsm->getNextX()
                << ";" << wsm->getNextY()
                << ";" << wsm->getNextZ()

                << ";" << wsm->getDestinationPosTimeStamp()
                << ";" << wsm->getDestinationMaxSpeed()
                //<< ";" << wsm->getDestinationRadius()
                << ";" << wsm->getDestinationSpeed()
                << ";" << wsm->getDestinationX()
                << ";" << wsm->getDestinationY()
                << ";" << wsm->getDestinationZ()

                << ";" << wsm->getWsmData() << ";"
                << std::endl;
    }

             return ost.str();
}
