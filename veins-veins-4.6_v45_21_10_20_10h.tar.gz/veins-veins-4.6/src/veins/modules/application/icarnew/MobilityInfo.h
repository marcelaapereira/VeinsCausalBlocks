//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef MOBILITYINFO_H_
#define MOBILITYINFO_H_

#include "veins/base/utils/Coord.h"
#include "veins/base/utils/Move.h"

class MobilityInfo {


private:

protected:

    /** @brief last time stamp before current time **/
    //simtime_t lastTime;

    /** @brief current position **/
    Move * actualMove= new Move();

    /** @brief last Position before current position **/
    //Coord lastPosition;
    Move * lastMove = new Move();


    // The sense between two coordinates
     Coord orientationSense(Coord cAtual, Coord cLast);

     // The max car speed
     double maxSpeed=0;

     void setLastMove(Move * pMove);
public:
    MobilityInfo();
    virtual ~MobilityInfo();
    std::string info();
    MobilityInfo(Move * mSrc);
    virtual Move * getMove();
    virtual Move * getLastMove();
    virtual void setMove(Move * pMove);
    /** @brief Returns a string with the value of the coordinate. */
    double getMaxSpeed();
    void setMaxSpeed(double maxSpeed);
    virtual double calcEuclideanDistancelr(Coord l, Coord r);
    virtual double calcEuclideanDistanceAgentMoving();
    virtual double calcRelativeSpeed();
    virtual std::string moveInfoTrace(bool header);
    std::string infoTrace(bool header);
    //virtual void  updateMobilityInfo(simtime_t tsCorrent, double x, double y, double speed, double maxSpeed);
    // ask about the sense between this Move and the Mobility Move
    int isSameSense(Coord cAtualLocal, Coord cLastLocal, Coord cAtualRemote, Coord cLastRemote);


};

#endif /* MOBILITYINFO_H_ */
