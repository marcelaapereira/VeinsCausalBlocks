//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef TIMELINESSCHANNEL_H_
#define TIMELINESSCHANNEL_H_

//#ifndef DBG
//#define DBG EV
//#endif
#define DBG std::cerr << "[" << simTime().raw() << "] " << getParentModule()->getFullPath() << " "
#include <omnetpp.h>
#include "Timeliness.h"
#include "Channel.h"
#include "math.h"
#include <iostream>
using namespace omnetpp;

class Channel;

class TimelinessChannel : public Timeliness {
private:


    Channel * c;
    void calcTimeoutValidity();
    double validityNeighbor;
    double slr;
    double validityNeighborConserv;
    double validityNeighberCondition;
    double ageNeighberCondition;
    double validityNeighbor250;
    double validity250;
    double slr250;
    double validityNeighborConserv250;
    double validityNeighberCondition250;
    int sense;
    double distancialr;
    double maxRelativeSpeed, relativeSpeed;

    simtime_t timeoutValidityNeighberCondition;
    simtime_t timeStampUpdateNeighberCondition;

    double validityMobilityCondition;
    double ageMobilityCondition;
    simtime_t timeoutValidityMobilityCondition;
    simtime_t timeStampUpdateMobilityCondition;

    double validityCommState;
    double ageCommState;
    simtime_t timeoutValidityCommState;
    simtime_t timeStampUpdateCommState;

    double setDigits(double _number, int _digits);
public:

    TimelinessChannel();
    TimelinessChannel(Channel* c, double dataValidity);
    std::string infoTrace(bool header);
    virtual ~TimelinessChannel();
    double calcValidity(double dataValidity);
    double calcAge();
    void update(double dataValidity);
    std::string  info();
   // double getDlr();
   // void setDlr(double dlr);
    double getSlr();
    void setSlr(double slr);

    double getAgeCommState();
    void setAgeCommState(double ageCommState);
    double getAgeMobilityCondition();
    void setAgeMobilityCondition(double ageMobilityCondition);
    double getAgeNeighberCondition();
    void setAgeNeighberCondition(double ageNeighberCondition);
    simtime_t getTimeoutValidityCommState();
    void setTimeoutValidityCommState(simtime_t timeoutValidityCommState);
    simtime_t getTimeoutValidityMobilityCondition();
    void setTimeoutValidityMobilityCondition(
            simtime_t timeoutValidityMobilityCondition);
    simtime_t getTimeoutValidityNeighberCondition();
    void setTimeoutValidityNeighberCondition(
            simtime_t timeoutValidityNeighberCondition);
    simtime_t getTimeStampUpdateCommState();
    void setTimeStampUpdateCommState(simtime_t timeStampUpdateCommState);
    simtime_t getTimeStampUpdateMobilityCondition();
    void setTimeStampUpdateMobilityCondition(
            simtime_t timeStampUpdateMobilityCondition);
    simtime_t getTimeStampUpdateNeighberCondition();
    void setTimeStampUpdateNeighberCondition(
            simtime_t timeStampUpdateNeighberCondition);
    double getValidityCommState();
    void setValidityCommState(double validityCommState);
    double getValidityMobilityCondition();
    void setValidityMobilityCondition(double validityMobilityCondition);
    double getValidityNeighberCondition();
    void setValidityNeighberCondition(double validityNeighberCondition);

};

#endif /* TIMELINESSCHANNEL_H_ */
