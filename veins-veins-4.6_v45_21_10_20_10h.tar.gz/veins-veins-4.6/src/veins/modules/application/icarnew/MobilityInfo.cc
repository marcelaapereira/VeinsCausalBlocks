//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "MobilityInfo.h"

MobilityInfo::MobilityInfo() {
    // TODO Auto-generated constructor stub
    //this->lastTime = 0.0;
    //this->maxSpeed = 0;
    //this->lastMove = new Move();
    //this->actualMove = new Move();

}

MobilityInfo::MobilityInfo(Move * mSrc) {
    // TODO Auto-generated constructor stub
    //this->lastTime = 0.0;
    this->lastMove = new Move();
    this->maxSpeed = 0;
    this->actualMove = mSrc;
}

Move * MobilityInfo::getMove(){
    return this->actualMove;
}


void MobilityInfo::setMove(Move * pMove){
    this->lastMove = actualMove;
    this->actualMove = pMove;
}

Move * MobilityInfo::getLastMove(){
    return this->lastMove;
}


void MobilityInfo::setLastMove(Move * pMove){
    this->lastMove = pMove;
}

MobilityInfo::~MobilityInfo() {
    // TODO Auto-generated destructor stub
    delete this;

}



Coord MobilityInfo::orientationSense(Coord cBefore, Coord cLast)
{
    Coord sense;
    if (cLast.x >=cBefore.x)
    {
        sense.x=1;
    }
    else{
        sense.x = -1;
    }


    if (cLast.y >=cBefore.y)
       {
           sense.y=1;
       }
       else{
           sense.y = -1;
       }

    if (cLast.z >=cBefore.z)
       {
           sense.z=1;
       }
       else{
           sense.z = -1;
       }

    return sense;

}


int MobilityInfo::isSameSense(Coord cBeforeLocal, Coord cLastLocal, Coord cBeforeRemote, Coord cLastRemote )
{
    Coord senseR, senseL;


    senseR = orientationSense(cBeforeRemote, cLastRemote);

    senseL = orientationSense(cBeforeLocal, cLastLocal);

    std::cout << endl << "L" << senseL.x << senseL.y << senseL.z << endl;
    std::cout << endl << "R" << senseR.x << senseR.y << senseR.z << endl;

    if ((senseL.x == senseR.x) && (senseL.y == senseR.y) && (senseL.z == senseR.z))
        return 1;
    else
        return -1;

}


double MobilityInfo::getMaxSpeed(){
    return maxSpeed;
}


void MobilityInfo::setMaxSpeed(double maxSpeed) {
    this->maxSpeed = maxSpeed;
}


double MobilityInfo::calcEuclideanDistanceAgentMoving() {
    //std::cout << "calcEuclideanDistancelr  - lastPosition=" <<this->getLastPosition() <<  "    -- startPos=" << this->startPos << std::endl;

    return  calcEuclideanDistancelr(this->lastMove->getCurrentPosition(), this->actualMove->getCurrentPosition());

}

double MobilityInfo::calcEuclideanDistancelr(Coord l, Coord r){
    return sqrt((r.x - l.x)*(r.x - l.x) + (r.y - l.y)*(r.y - l.y));
}

// entra com a do movimento local
double  MobilityInfo::calcRelativeSpeed(){
       // setRelativeSpeed(fabs(oL.getSpeed() -  (isSameSense(oL.getStartPos(), oL.getCurrentPosition(),
       //        this->getMove()->getStartPos(), this->getMove()->getCurrentPosition()) * this->getMove()->getSpeed())));
       //return this->relativeSpeed;
        return 0;
}

std::string MobilityInfo::info(){
    std::ostringstream ost;
    ost << "MobilityInfo"
        << ";maxSpeed;" << this->maxSpeed
        << ";last Move; " << lastMove->info()
        << ";actual Move; " << actualMove->info();
;
    return ost.str();
}



std::string MobilityInfo::infoTrace(bool header=false){
    std::ostringstream ost;
    if (header)
        ost << ";maxSpeed"
        << moveInfoTrace(true);
    else
        ost
            << ";" << this->maxSpeed
            << moveInfoTrace(false);

    return ost.str();
}

/**
 * @brief Returns information about the current state.
 */
    std::string MobilityInfo::moveInfoTrace(bool header=false) {
        std::ostringstream ost;
  /* ORIGINAL
        if (header)
            ost << ";CurrentUpdatePosTime"
                << ";currentPosx"
                << ";currentPosy"
                << ";currentPosz"
                << ";directionPosx"
                << ";directionPosy"
                << ";directionPosz"
                << ";orientaionPosx"
                << ";orientaionPosy"
                << ";orientaionPosz"
                << ";speed"
                << ";lastUpdatePosTime"
                     << ";lastPosx"
                     << ";lastPosy"
                     << ";lastPosz"
                     << ";lastDirectionPosx"
                     << ";lastDirectionPosy"
                     << ";lastDirectionPosz"
                     << ";lastOrientaionPosx"
                     << ";lastOrientaionPosy"
                     << ";lastOrientaionPosz"
                     << ";lastSpeed";
        else
            ost << ";" << this->actualMove->getStartTime()
                << ";" << this->actualMove->getCurrentPosition().x
                << ";" << this->actualMove->getCurrentPosition().y
                << ";" << this->actualMove->getCurrentPosition().z
                << ";" << this->actualMove->getDirection().x
                << ";"<< this->actualMove->getDirection().y
                << ";"<< this->actualMove->getDirection().z
                << ";" << this->actualMove->getOrientation().x
                << ";"<< this->actualMove->getOrientation().y
                << ";"<< this->actualMove->getOrientation().z
                << ";" << this->actualMove->getSpeed()

                << ";" << this->lastMove->getStartTime()
                << ";" << this->lastMove->getCurrentPosition().x
                << ";" << this->lastMove->getCurrentPosition().y
                << ";" << this->lastMove->getCurrentPosition().z
                << ";" << this->lastMove->getDirection().x
                << ";"<< this->lastMove->getDirection().y
                << ";"<< this->lastMove->getDirection().z
                << ";" << this->lastMove->getOrientation().x
                << ";"<< this->lastMove->getOrientation().y
                << ";"<< this->lastMove->getOrientation().z
                << ";" << this->lastMove->getSpeed();
*/
//APAGAR DEPOIS

        if (header)
            ost << ";speed"
                << ";CurrentUpdatePosTime"
                << ";currentPosx"
                << ";currentPosy"
                << ";lastUpdatePosTime";
        else
            ost
            << ";" << this->actualMove->getSpeed()
            << ";" << this->actualMove->getStartTime()
                << ";" << this->actualMove->getCurrentPosition().x
                << ";" << this->actualMove->getCurrentPosition().y
                << ";" << this->lastMove->getStartTime();

        return ost.str();
}




