//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "ChannelMobility.h"

ChannelMobility::ChannelMobility() {
    // TODO Auto-generated constructor stub

}

ChannelMobility::~ChannelMobility() {
    // TODO Auto-generated destructor stub
}

std::string ChannelMobility::info() {
    std::ostringstream ost;
    ost << "  l r agents distance: " << this->distancelr
        << "  l r relative speed : " << this->relativeSpeed;
     //   << "  l r agents movement time: " << this->movementCurrentTime;
    return ost.str();
}

std::string ChannelMobility::infoTrace(bool header)
{
    std::ostringstream ost;
    if (header)
       ost << ";distance_lr;relative_speed_lr";
    else
    {
        ost << ";" << this->distancelr
            << ";" << this->relativeSpeed;
    }
    return ost.str();
}



ChannelMobility::ChannelMobility(Move * l, Move * r)
{
    //this->movementCurrentTime = 0;

    updateChannelMobility(l, r);
}

void ChannelMobility::updateChannelMobility(Move * l, Move * r)
{
    //this->distancelr = l->getCurrentPosition().distance(r->getCurrentPosition());
    this->distancelr = this->calcEuclideanDistancelr(l->getCurrentPosition(), r->getCurrentPosition());
    this->relativeSpeed=this->calRelativeSpeed(l, r);
}

double ChannelMobility::calRelativeSpeed(Move * l, Move * r){

    return (l->getSpeed() + r->getSpeed());
}
double ChannelMobility::getDistancelr(Move * l, Move * r){
    updateChannelMobility(l, r);
    return distancelr;
}

/*void ChannelMobility::setDistancelr(double distancelr) {
//    this->distancelr = distancelr;
//}

simtime_t ChannelMobility::getMovementCurrentTime() {
    return movementCurrentTime;
}


void ChannelMobility::setMovementCurrentTime(simtime_t movementCurrentTime) {
    this->movementCurrentTime = movementCurrentTime;
}
*/
